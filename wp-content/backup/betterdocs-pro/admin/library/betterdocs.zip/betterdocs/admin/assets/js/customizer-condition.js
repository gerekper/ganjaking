(function ($) {
	'use strict';
	/**
	 * Run function when customizer is ready.
	 */
	function customizer_conditional_setting_return(setting,controler_name,controler_val){
		wp.customize.control( controler_name, function( control ) { 
			var visibility = function() {
				if ( controler_val !== setting.get() ) {                      
					control.container.slideUp( 180 );         
				} else {
					control.container.slideDown( 180 );
				}
			};           
			visibility();         
			setting.bind( visibility ); 
		});	
	}

	$(document).ready(function () {
		wp.customize.bind( 'ready', function() {
			wp.customize( 'betterdocs_docs_layout_select', function( setting ) {                  
				customizer_conditional_setting_return(setting,'betterdocs_doc_page_cat_icon_size_layout1','layout-1');
				customizer_conditional_setting_return(setting,'betterdocs_doc_page_cat_icon_size_layout2','layout-2');
				customizer_conditional_setting_return(setting,'betterdocs_doc_page_cat_title_border_color','layout-1');
				customizer_conditional_setting_return(setting,'betterdocs_doc_page_item_count_color','layout-1');
				customizer_conditional_setting_return(setting,'betterdocs_doc_page_item_count_color2','layout-2');
				customizer_conditional_setting_return(setting,'betterdocs_doc_page_item_count_bg_color','layout-1');
				customizer_conditional_setting_return(setting,'betterdocs_doc_page_item_counter_size','layout-1');
				customizer_conditional_setting_return(setting,'betterdocs_doc_page_article_list_settings','layout-1');
				customizer_conditional_setting_return(setting,'betterdocs_doc_page_article_list_color','layout-1');
				customizer_conditional_setting_return(setting,'betterdocs_doc_page_article_list_hover_color','layout-1');
				customizer_conditional_setting_return(setting,'betterdocs_doc_page_article_list_bg_color','layout-1');
				customizer_conditional_setting_return(setting,'betterdocs_doc_page_article_list_font_size','layout-1');
				customizer_conditional_setting_return(setting,'betterdocs_doc_page_list_icon_color','layout-1');
				customizer_conditional_setting_return(setting,'betterdocs_doc_page_list_icon_font_size','layout-1');
				customizer_conditional_setting_return(setting,'betterdocs_doc_page_article_list_margin','layout-1');
				customizer_conditional_setting_return(setting,'betterdocs_doc_page_article_list_margin_top','layout-1');
				customizer_conditional_setting_return(setting,'betterdocs_doc_page_article_list_margin_right','layout-1');
				customizer_conditional_setting_return(setting,'betterdocs_doc_page_article_list_margin_bottom','layout-1');
				customizer_conditional_setting_return(setting,'betterdocs_doc_page_article_list_margin_left','layout-1');
				customizer_conditional_setting_return(setting,'betterdocs_doc_page_explore_btn','layout-1');
				customizer_conditional_setting_return(setting,'betterdocs_doc_page_explore_btn_bg_color','layout-1');
				customizer_conditional_setting_return(setting,'betterdocs_doc_page_explore_btn_color','layout-1');
				customizer_conditional_setting_return(setting,'betterdocs_doc_page_explore_btn_border_color','layout-1');
				customizer_conditional_setting_return(setting,'betterdocs_doc_page_explore_btn_font_size','layout-1');
				customizer_conditional_setting_return(setting,'betterdocs_doc_page_explore_btn_padding','layout-1');
				customizer_conditional_setting_return(setting,'betterdocs_doc_page_explore_btn_padding_top','layout-1');
				customizer_conditional_setting_return(setting,'betterdocs_doc_page_explore_btn_padding_right','layout-1');
				customizer_conditional_setting_return(setting,'betterdocs_doc_page_explore_btn_padding_bottom','layout-1');
				customizer_conditional_setting_return(setting,'betterdocs_doc_page_explore_btn_borderr','layout-1');
				customizer_conditional_setting_return(setting,'betterdocs_doc_page_explore_btn_borderr_topleft','layout-1');
				customizer_conditional_setting_return(setting,'betterdocs_doc_page_explore_btn_borderr_topright','layout-1');
				customizer_conditional_setting_return(setting,'betterdocs_doc_page_explore_btn_borderr_bottomright','layout-1');
				customizer_conditional_setting_return(setting,'betterdocs_doc_page_explore_btn_borderr_bottomleft','layout-1');
				customizer_conditional_setting_return(setting,'betterdocs_doc_page_explore_btn_padding_left','layout-1');
				customizer_conditional_setting_return(setting,'betterdocs_doc_page_explore_btn_hover_bg_color','layout-1');
				customizer_conditional_setting_return(setting,'betterdocs_doc_page_explore_btn_hover_color','layout-1');
				customizer_conditional_setting_return(setting,'betterdocs_doc_page_explore_btn_hover_border_color','layout-1');
			});
			wp.customize( 'betterdocs_single_layout_select', function( setting ) {
				customizer_conditional_setting_return(setting,'betterdocs_doc_single_content_area_padding','layout-1');
				customizer_conditional_setting_return(setting,'betterdocs_doc_single_content_area_padding_top','layout-1');
				customizer_conditional_setting_return(setting,'betterdocs_doc_single_content_area_padding_right','layout-1');
				customizer_conditional_setting_return(setting,'betterdocs_doc_single_content_area_padding_bottom','layout-1');
				customizer_conditional_setting_return(setting,'betterdocs_doc_single_content_area_padding_left','layout-1');
				customizer_conditional_setting_return(setting,'betterdocs_doc_single_2_content_area_padding','layout-2');
				customizer_conditional_setting_return(setting,'betterdocs_doc_single_2_content_area_padding_top','layout-2');
				customizer_conditional_setting_return(setting,'betterdocs_doc_single_2_content_area_padding_right','layout-2');
				customizer_conditional_setting_return(setting,'betterdocs_doc_single_2_content_area_padding_bottom','layout-2');
				customizer_conditional_setting_return(setting,'betterdocs_doc_single_2_content_area_padding_left','layout-2');
				customizer_conditional_setting_return(setting,'betterdocs_doc_single_3_content_area_padding','layout-3');
				customizer_conditional_setting_return(setting,'betterdocs_doc_single_3_content_area_padding_top','layout-3');
				customizer_conditional_setting_return(setting,'betterdocs_doc_single_3_content_area_padding_right','layout-3');
				customizer_conditional_setting_return(setting,'betterdocs_doc_single_3_content_area_padding_bottom','layout-3');
				customizer_conditional_setting_return(setting,'betterdocs_doc_single_3_content_area_padding_left','layout-3');
			});
		});
	});
})(jQuery);