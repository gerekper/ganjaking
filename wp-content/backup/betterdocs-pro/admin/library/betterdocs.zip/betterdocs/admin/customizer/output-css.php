<?php
/**
 * BetterDocs Theme Customizer outout for layout settings
 *
 * @package BetterDocs
 */

/**
 * This function adds some styles to the WordPress Customizer
 */
function betterdocs_customizer_styles() { ?>
	<style type="text/css">

		.betterdocs-customize-control-separator {
			display: block;
			margin: 0 -12px;
			border: 1px solid #ddd;
			border-left: 0;
			border-right: 0;
			padding: 15px;
			font-size: 11px;
			font-weight: 600;
			letter-spacing: 2px;
			line-height: 1;
			text-transform: uppercase;
			color: #555;
			background-color: #fff;
		}
		.customize-control.customize-control-dimension,
		.customize-control-betterdocs-select {
			width: 25%;
			float: left;
			clear: none;
		}
		.customize-control.customize-control-dimension .customize-control-title,
		.customize-control-betterdocs-select .customize-control-title{
			font-size: 11px;
			font-weight: normal;
			color: #888b8c;
		}
	</style>
	<?php

}
add_action( 'customize_controls_print_styles', 'betterdocs_customizer_styles', 999 );

function betterdocs_customize_css() {
	$defaults = betterdocs_generate_defaults();
	$column_number = BetterDocs_DB::get_settings('column_number');
	$doc_page_column_space = $defaults['betterdocs_doc_page_column_space'];
	$total_margin = $column_number * $doc_page_column_space;
    ?>
	<style type="text/css">
		.betterdocs-wraper{
			<?php if(!empty($defaults['betterdocs_doc_page_background_color'])) { ?>
			background-color: <?php echo $defaults['betterdocs_doc_page_background_color'] ?>;
			<?php } ?>
			<?php if(!empty($defaults['betterdocs_doc_page_background_image'])) { ?>
			background-image: url(<?php echo $defaults['betterdocs_doc_page_background_image'] ?>);
			<?php } ?>
			<?php if(!empty($defaults['betterdocs_doc_page_background_size'])) { ?>
			background-size: <?php echo $defaults['betterdocs_doc_page_background_size'] ?>;
			<?php } ?>
			<?php if(!empty($defaults['betterdocs_doc_page_background_repeat'])) { ?>
			background-repeat: <?php echo $defaults['betterdocs_doc_page_background_repeat'] ?>;
			<?php } ?>
			<?php if(!empty($defaults['betterdocs_doc_page_background_attachment'])) { ?>
			background-attachment: <?php echo $defaults['betterdocs_doc_page_background_attachment'] ?>;
			<?php } ?>
			<?php if(!empty($defaults['betterdocs_doc_page_background_position'])) { ?>
			background-position: <?php echo $defaults['betterdocs_doc_page_background_position'] ?>;
			<?php } ?>
		}

		.betterdocs-archive-wrap {
			padding-top: <?php echo $defaults['betterdocs_doc_page_content_padding_top'] ?>px;
			padding-bottom: <?php echo $defaults['betterdocs_doc_page_content_padding_bottom'] ?>px;
			padding-left: <?php echo $defaults['betterdocs_doc_page_content_padding_left'] ?>px;
			padding-right: <?php echo $defaults['betterdocs_doc_page_content_padding_right'] ?>px;
		}
		.betterdocs-categories-wrap {
			width: <?php echo $defaults['betterdocs_doc_page_content_width'] ?>%;
			max-width: <?php echo $defaults['betterdocs_doc_page_content_max_width'] ?>px;
		}
		.betterdocs-categories-wrap.layout-masonry .docs-single-cat-wrap {
			width: calc((100% - <?php echo $total_margin ?>px) / <?php echo $column_number ?>);
			margin-bottom: <?php echo $defaults['betterdocs_doc_page_column_space'] ?>px;
		}
		.betterdocs-categories-wrap.layout-flex .docs-single-cat-wrap {
			margin: <?php echo $defaults['betterdocs_doc_page_column_space'] ?>px; 
		}
		.betterdocs-categories-wrap .docs-single-cat-wrap .docs-cat-title-wrap { 
			padding-top: <?php echo $defaults['betterdocs_doc_page_column_padding_top'] ?>px; 
		}
		.betterdocs-categories-wrap .docs-single-cat-wrap .docs-cat-title-wrap,.docs-item-container { 
			padding-right: <?php echo $defaults['betterdocs_doc_page_column_padding_right'] ?>px;
			padding-left: <?php echo $defaults['betterdocs_doc_page_column_padding_left'] ?>px;  
		}
		.docs-item-container { 
			padding-bottom: <?php $defaults['betterdocs_doc_page_column_padding_right'] ?>px; 
		}
		.betterdocs-categories-wrap.betterdocs-category-box .docs-single-cat-wrap{
			padding-top: <?php echo $defaults['betterdocs_doc_page_column_padding_top'] ?>px; 
			padding-right: <?php echo $defaults['betterdocs_doc_page_column_padding_right'] ?>px;
			padding-left: <?php echo $defaults['betterdocs_doc_page_column_padding_left'] ?>px; 
			padding-bottom: <?php $defaults['betterdocs_doc_page_column_padding_bottom'] ?>px; 
		}
		.docs-cat-title > img { 
			width: <?php echo $defaults['betterdocs_doc_page_cat_icon_size_layout1'] ?>px; 
		}
		.betterdocs-category-box .docs-single-cat-wrap img { 
			width: <?php echo $defaults['betterdocs_doc_page_cat_icon_size_layout2'] ?>px; 
		}
		.docs-cat-title-inner h3,.betterdocs-category-box .docs-single-cat-wrap .docs-cat-title {
			font-size: <?php echo $defaults['betterdocs_doc_page_cat_title_font_size'] ?>px; 
			color: <?php echo $defaults['betterdocs_doc_page_cat_title_color'] ?>; 
		}
		.docs-cat-title-inner {
			border-color: <?php echo $defaults['betterdocs_doc_page_cat_title_border_color'] ?>; 
		}
		.docs-cat-title-inner span {
			color: <?php echo $defaults['betterdocs_doc_page_item_count_color'] ?>; 
			font-size: <?php echo $defaults['betterdocs_doc_page_item_count_font_size'] ?>px;
		}
		.betterdocs-categories-wrap.betterdocs-category-box .docs-single-cat-wrap span{
			color: <?php echo $defaults['betterdocs_doc_page_item_count_color_layout2'] ?>; 
			font-size: <?php echo $defaults['betterdocs_doc_page_item_count_font_size'] ?>px;
		}
		.docs-item-count {
			background-color: <?php echo $defaults['betterdocs_doc_page_item_count_bg_color'] ?>; 
		}
		.betterdocs-archive-wrap .betterdocs-categories-wrap .docs-cat-title-inner span {
			width: <?php echo $defaults['betterdocs_doc_page_item_counter_size'] ?>px; 
			height: <?php echo $defaults['betterdocs_doc_page_item_counter_size'] ?>px;
		}
		.betterdocs-archive-wrap .betterdocs-categories-wrap .docs-item-container {
			background-color: <?php echo $defaults['betterdocs_doc_page_article_list_bg_color'] ?>;
		}
		.betterdocs-archive-wrap .betterdocs-categories-wrap .docs-item-container li {
			margin-top: <?php echo $defaults['betterdocs_doc_page_article_list_margin_top'] ?>px;
			margin-right: <?php echo $defaults['betterdocs_doc_page_article_list_margin_right'] ?>px;
			margin-bottom: <?php echo $defaults['betterdocs_doc_page_article_list_margin_bottom'] ?>px;
			margin-left: <?php echo $defaults['betterdocs_doc_page_article_list_margin_left'] ?>px;
		}
		.betterdocs-archive-wrap .betterdocs-categories-wrap .docs-item-container li i {
			color: <?php echo $defaults['betterdocs_doc_page_list_icon_color'] ?>;
			font-size: <?php echo $defaults['betterdocs_doc_page_list_icon_font_size'] ?>px;
		}
		.betterdocs-archive-wrap .betterdocs-categories-wrap li a {
			color: <?php echo $defaults['betterdocs_doc_page_article_list_color'] ?>;
			font-size: <?php echo $defaults['betterdocs_doc_page_article_list_font_size'] ?>px;
		}
		.betterdocs-archive-wrap .betterdocs-categories-wrap li a:hover {
			color: <?php echo $defaults['betterdocs_doc_page_article_list_hover_color'] ?>;
		}
		.docs-cat-link-btn, .docs-cat-link-btn:visited {
			background-color: <?php echo $defaults['betterdocs_doc_page_explore_btn_bg_color'] ?>;
			font-size: <?php echo $defaults['betterdocs_doc_page_explore_btn_font_size'] ?>px;
			color: <?php echo $defaults['betterdocs_doc_page_explore_btn_color'] ?>;
			border-color: <?php echo $defaults['betterdocs_doc_page_explore_btn_border_color'] ?>;
			border-top-left-radius: <?php echo $defaults['betterdocs_doc_page_explore_btn_borderr_topleft'] ?>px;
			border-top-right-radius: <?php echo $defaults['betterdocs_doc_page_explore_btn_borderr_topright'] ?>px;
			border-bottom-right-radius: <?php echo $defaults['betterdocs_doc_page_explore_btn_borderr_bottomright'] ?>px;
			border-bottom-left-radius: <?php echo $defaults['betterdocs_doc_page_explore_btn_borderr_bottomleft'] ?>px;
			padding-top: <?php echo $defaults['betterdocs_doc_page_explore_btn_padding_top'] ?>px;
			padding-right: <?php echo $defaults['betterdocs_doc_page_explore_btn_padding_right'] ?>px;
			padding-bottom: <?php echo $defaults['betterdocs_doc_page_explore_btn_padding_bottom'] ?>px;
			padding-left: <?php echo $defaults['betterdocs_doc_page_explore_btn_padding_left'] ?>px;
		}
		.docs-cat-link-btn:hover {
			background-color: <?php echo $defaults['betterdocs_doc_page_explore_btn_hover_bg_color'] ?>;
			color: <?php echo $defaults['betterdocs_doc_page_explore_btn_hover_color'] ?>;
			border-color: <?php echo $defaults['betterdocs_doc_page_explore_btn_hover_border_color'] ?>;
		}
		.betterdocs-single-wraper .betterdocs-content-area .docs-single-main {
			padding-top: <?php echo $defaults['betterdocs_doc_single_content_area_padding_top'] ?>px;
			padding-right: <?php echo $defaults['betterdocs_doc_single_content_area_padding_right'] ?>px;
			padding-bottom: <?php echo $defaults['betterdocs_doc_single_content_area_padding_bottom'] ?>px;
			padding-left: <?php echo $defaults['betterdocs_doc_single_content_area_padding_left'] ?>px;
		}
		.betterdocs-single-layout2 .docs-content-full-main .doc-single-content-wrapper {
			padding-top: <?php echo $defaults['betterdocs_doc_single_2_content_area_padding_top'] ?>px;
			padding-right: <?php echo $defaults['betterdocs_doc_single_2_content_area_padding_right'] ?>px;
			padding-bottom: <?php echo $defaults['betterdocs_doc_single_2_content_area_padding_bottom'] ?>px;
			padding-left: <?php echo $defaults['betterdocs_doc_single_2_content_area_padding_left'] ?>px;
		}
		.betterdocs-single-layout3 .docs-content-full-main .doc-single-content-wrapper {
			padding-top: <?php echo $defaults['betterdocs_doc_single_3_content_area_padding_top'] ?>px;
			padding-right: <?php echo $defaults['betterdocs_doc_single_3_content_area_padding_right'] ?>px;
			padding-bottom: <?php echo $defaults['betterdocs_doc_single_3_content_area_padding_bottom'] ?>px;
			padding-left: <?php echo $defaults['betterdocs_doc_single_3_content_area_padding_left'] ?>px;
		}
		.betterdocs-breadcrumb .betterdocs-breadcrumb-item a {
			font-size: <?php echo $defaults['betterdocs_single_doc_breadcrumbs_font_size'] ?>px;
			color: <?php echo $defaults['betterdocs_single_doc_breadcrumb_color'] ?>;
		}
		.betterdocs-breadcrumb .breadcrumb-delimiter {
			color: <?php echo $defaults['betterdocs_single_doc_breadcrumb_color'] ?>;
		}
		.betterdocs-breadcrumb-item.current span {
			font-size: <?php echo $defaults['betterdocs_single_doc_breadcrumbs_font_size'] ?>px;
			color: <?php echo $defaults['betterdocs_single_doc_breadcrumb_active_item_color'] ?>;
		}
		.betterdocs-toc {
			background-color: <?php echo $defaults['betterdocs_toc_bg_color'] ?>;
			padding-top: <?php echo $defaults['betterdocs_doc_single_toc_padding_top'] ?>px;
			padding-right: <?php echo $defaults['betterdocs_doc_single_toc_padding_right'] ?>px;
			padding-bottom: <?php echo $defaults['betterdocs_doc_single_toc_padding_bottom'] ?>px;
			padding-left: <?php echo $defaults['betterdocs_doc_single_toc_padding_left'] ?>px;
		}
		.betterdocs-toc > h2.toc-title {
			color: <?php echo $defaults['betterdocs_toc_title_color'] ?>;
			font-size: <?php echo $defaults['betterdocs_toc_title_font_size'] ?>px;
		}
		.betterdocs-toc > .toc-list a {
			color: <?php echo $defaults['betterdocs_toc_list_item_color'] ?>;
			font-size: <?php echo $defaults['betterdocs_toc_list_item_font_size'] ?>px;
			margin-top: <?php echo $defaults['betterdocs_doc_single_toc_list_margin_top'] ?>px;
			margin-right: <?php echo $defaults['betterdocs_doc_single_toc_list_margin_right'] ?>px;
			margin-bottom: <?php echo $defaults['betterdocs_doc_single_toc_list_margin_bottom'] ?>px;
			margin-left: <?php echo $defaults['betterdocs_doc_single_toc_list_margin_left'] ?>px;
		}
		.betterdocs-toc > .toc-list a:hover {
			color: <?php echo $defaults['betterdocs_toc_list_item_hover_color'] ?>;
		}
		.feedback-form-link .feedback-form-icon svg, .feedback-form-link .feedback-form-icon img {
			width: <?php echo $defaults['betterdocs_single_doc_feedback_icon_font_size'] ?>px;
		}
		.betterdocs-toc > .toc-list a.active {
			color: <?php echo $defaults['betterdocs_toc_active_item_color'] ?>;
		}
		.betterdocs-toc > .toc-list li {
			color: <?php echo $defaults['betterdocs_toc_list_number_color'] ?>;
			font-size: <?php echo $defaults['betterdocs_toc_list_number_font_size'] ?>px;
		}
		.betterdocs-content{
			color: <?php echo $defaults['betterdocs_single_content_font_color'] ?>;
			font-size: <?php echo $defaults['betterdocs_single_content_font_size'] ?>px;
		}
		.betterdocs-entry-footer .feedback-form-link {
			color: <?php echo $defaults['betterdocs_single_doc_feedback_link_color'] ?>;
			font-size: <?php echo $defaults['betterdocs_single_doc_feedback_link_font_size'] ?>px;
		}
		.betterdocs-entry-footer .feedback-update-form .feedback-form-link:hover {
			color: <?php echo $defaults['betterdocs_single_doc_feedback_link_hover_color'] ?>;
		}
		.docs-navigation a {
			color: <?php echo $defaults['betterdocs_single_doc_navigation_color'] ?>;
			font-size: <?php echo $defaults['betterdocs_single_doc_navigation_font_size'] ?>px;
		}
		.docs-navigation a:hover {
			color: <?php echo $defaults['betterdocs_single_doc_navigation_hover_color'] ?>;
		}
		.docs-navigation a svg{
			fill: <?php echo $defaults['betterdocs_single_doc_navigation_arrow_color'] ?>;
			width: <?php echo $defaults['betterdocs_single_doc_navigation_arrow_font_size'] ?>px;
		}
		.betterdocs-entry-footer .update-date{
			color: <?php echo $defaults['betterdocs_single_doc_lu_time_color'] ?>;
			font-size: <?php echo $defaults['betterdocs_single_doc_lu_time_font_size'] ?>px;
		}
		.betterdocs-credit p{
			color: <?php echo $defaults['betterdocs_single_doc_powered_by_color'] ?>;
			font-size: <?php echo $defaults['betterdocs_single_doc_powered_by_font_size'] ?>px;
		}
		.betterdocs-credit p a{
			color: <?php echo $defaults['betterdocs_single_doc_powered_by_link_color'] ?>;
		}
		.betterdocs-sidebar-content .docs-cat-title > img{
			width: <?php echo $defaults['betterdocs_sidebar_icon_size'] ?>;
		}
		.betterdocs-sidebar-content .docs-cat-title-inner h3{
			color: <?php echo $defaults['betterdocs_sidebar_title_color'] ?>;
			font-size: <?php echo $defaults['betterdocs_sidebar_title_font_size'] ?>px;
		}
		.betterdocs-sidebar-content .docs-single-cat-wrap .active-title .docs-cat-title-inner h3,
		.betterdocs-sidebar-content .active-title .docs-cat-title-inner h3{
			color: <?php echo $defaults['betterdocs_sidebar_active_title_color'] ?>;
		}
		.betterdocs-sidebar-content .docs-item-count{
			background-color: <?php echo $defaults['betterdocs_sidbebar_item_count_bg_color'] ?>;
		}
		.betterdocs-sidebar-content .docs-item-count span{
			color: <?php echo $defaults['betterdocs_sidebar_item_count_color'] ?>;
			font-size: <?php echo $defaults['betterdocs_sidebat_item_count_font_size'] ?>px;
		}
		.betterdocs-sidebar-content .betterdocs-categories-wrap .docs-single-cat-wrap .docs-cat-title-wrap {
			padding-top: <?php echo $defaults['betterdocs_sidebar_title_padding_top'] ?>px;
			padding-right: <?php echo $defaults['betterdocs_sidebar_title_padding_right'] ?>px;
			padding-bottom: <?php echo $defaults['betterdocs_sidebar_title_padding_bottom'] ?>px;
			padding-left: <?php echo $defaults['betterdocs_sidebar_title_padding_left'] ?>px;
		}
		.betterdocs-sidebar-content .docs-single-cat-wrap .docs-cat-title-wrap.active-title{
			background-color: <?php echo $defaults['betterdocs_sidebar_active_cat_background_color'] ?>;
			border-color: <?php echo $defaults['betterdocs_sidebar_active_cat_border_color'] ?>;
		}
		.betterdocs-sidebar-content .betterdocs-categories-wrap .docs-item-container li {
			padding-left: 0;
			margin-top: <?php echo $defaults['betterdocs_sidebar_list_item_margin_top'] ?>px;
			margin-right: <?php echo $defaults['betterdocs_sidebar_list_item_margin_right'] ?>px;
			margin-bottom: <?php echo $defaults['betterdocs_sidebar_list_item_margin_bottom'] ?>px;
			margin-left: <?php echo $defaults['betterdocs_sidebar_list_item_margin_left'] ?>px;
		}
		.betterdocs-sidebar-content .betterdocs-categories-wrap li a {
			color: <?php echo $defaults['betterdocs_sidebar_list_item_color'] ?>;
			font-size: <?php echo $defaults['betterdocs_sidebar_list_item_font_size'] ?>px;
		}
		.betterdocs-sidebar-content .betterdocs-categories-wrap li i {
			color: <?php echo $defaults['betterdocs_sidebar_list_icon_color'] ?>;
			font-size: <?php echo $defaults['betterdocs_sidebar_list_icon_font_size'] ?>px;
		}
		.betterdocs-sidebar-content .betterdocs-categories-wrap li a.active {
			color: <?php echo $defaults['betterdocs_sidebar_active_list_item_color'] ?>;
		}	
		.betterdocs-category-wraper.betterdocs-single-wraper{
			<?php if(!empty($defaults['betterdocs_archive_page_background_color'])) { ?>
			background-color: <?php echo $defaults['betterdocs_archive_page_background_color'] ?>;
			<?php } ?>
			<?php if(!empty($defaults['betterdocs_archive_page_background_image'])) { ?>
			background-image: url(<?php echo $defaults['betterdocs_archive_page_background_image'] ?>);
			<?php } ?>
			<?php if(!empty($defaults['betterdocs_archive_page_background_size'])) { ?>
			background-size: <?php echo $defaults['betterdocs_archive_page_background_size'] ?>;
			<?php } ?>
			<?php if(!empty($defaults['betterdocs_archive_page_background_repeat'])) { ?>
			background-repeat: <?php echo $defaults['betterdocs_archive_page_background_repeat'] ?>;
			<?php } ?>
			<?php if(!empty($defaults['betterdocs_archive_page_background_attachment'])) { ?>
			background-attachment: <?php echo $defaults['betterdocs_archive_page_background_attachment'] ?>;
			<?php } ?>
			<?php if(!empty($defaults['betterdocs_archive_page_background_position'])) { ?>
			background-position: <?php echo $defaults['betterdocs_archive_page_background_position'] ?>;
			<?php } ?>
		}	
		.betterdocs-category-wraper.betterdocs-single-wraper .docs-listing-main .docs-category-listing{
			<?php if(!empty($defaults['betterdocs_archive_content_background_color'])) { ?>
			background-color: <?php echo $defaults['betterdocs_archive_content_background_color'] ?>;
			<?php } ?>
			margin-top: <?php echo $defaults['betterdocs_archive_content_margin_top'] ?>px;
			margin-right: <?php echo $defaults['betterdocs_archive_content_margin_right'] ?>px;
			margin-bottom: <?php echo $defaults['betterdocs_archive_content_margin_bottom'] ?>px;
			margin-left: <?php echo $defaults['betterdocs_archive_content_margin_left'] ?>px;
			padding-top: <?php echo $defaults['betterdocs_archive_content_padding_top'] ?>px;
			padding-right: <?php echo $defaults['betterdocs_archive_content_padding_right'] ?>px;
			padding-bottom: <?php echo $defaults['betterdocs_archive_content_padding_bottom'] ?>px;
			padding-left: <?php echo $defaults['betterdocs_archive_content_padding_left'] ?>px;
			border-radius: <?php echo $defaults['betterdocs_archive_content_border_radius'] ?>px;
		}
		.betterdocs-category-wraper .docs-category-listing .docs-cat-title h3 {
			color: <?php echo $defaults['betterdocs_archive_title_color'] ?>;
			font-size: <?php echo $defaults['betterdocs_archive_title_font_size'] ?>px;
			margin-top: <?php echo $defaults['betterdocs_archive_title_margin_top'] ?>px;
			margin-right: <?php echo $defaults['betterdocs_archive_title_margin_right'] ?>px;
			margin-bottom: <?php echo $defaults['betterdocs_archive_title_margin_bottom'] ?>px;
			margin-left: <?php echo $defaults['betterdocs_archive_title_margin_left'] ?>px;
		}
		.docs-category-listing .docs-list ul li {
			color: <?php echo $defaults['betterdocs_archive_list_icon_color'] ?>;
			font-size: <?php echo $defaults['betterdocs_archive_list_icon_font_size'] ?>px;
		}
		.docs-category-listing .docs-list ul li a {
			color: <?php echo $defaults['betterdocs_archive_list_item_color'] ?>;
			font-size: <?php echo $defaults['betterdocs_archive_list_item_font_size'] ?>px;
		}
		.betterdocs-search-form-wrap{
			<?php if(!empty($defaults['betterdocs_live_search_background_color'])) { ?>
			background-color: <?php echo $defaults['betterdocs_live_search_background_color'] ?>;
			<?php } ?>
			<?php if(!empty($defaults['betterdocs_live_search_background_image'])) { ?>
			background-image: url(<?php echo $defaults['betterdocs_live_search_background_image'] ?>);
			<?php } ?>
			<?php if(!empty($defaults['betterdocs_live_search_background_size'])) { ?>
			background-size: <?php echo $defaults['betterdocs_live_search_background_size'] ?>;
			<?php } ?>
			<?php if(!empty($defaults['betterdocs_live_search_background_repeat'])) { ?>
			background-repeat: <?php echo $defaults['betterdocs_live_search_background_repeat'] ?>;
			<?php } ?>
			<?php if(!empty($defaults['betterdocs_live_search_background_attachment'])) { ?>
			background-attachment: <?php echo $defaults['betterdocs_live_search_background_attachment'] ?>;
			<?php } ?>
			<?php if(!empty($defaults['betterdocs_live_search_background_position'])) { ?>
			background-position: <?php echo $defaults['betterdocs_live_search_background_position'] ?>;
			<?php } ?>
			padding-top: <?php echo $defaults['betterdocs_live_search_padding_top'] ?>px;
			padding-right: <?php echo $defaults['betterdocs_live_search_padding_right'] ?>px;
			padding-bottom: <?php echo $defaults['betterdocs_live_search_padding_bottom'] ?>px;
			padding-left: <?php echo $defaults['betterdocs_live_search_padding_left'] ?>px;
		}
		.betterdocs-searchform {
			background-color: <?php echo $defaults['betterdocs_search_field_background_color'] ?>;
			border-radius: <?php echo $defaults['betterdocs_search_field_border_radius'] ?>px;
			padding-top: <?php echo $defaults['betterdocs_search_field_padding_top'] ?>px;
			padding-right: <?php echo $defaults['betterdocs_search_field_padding_right'] ?>px;
			padding-bottom: <?php echo $defaults['betterdocs_search_field_padding_bottom'] ?>px;
			padding-left: <?php echo $defaults['betterdocs_search_field_padding_left'] ?>px;
		}
		.betterdocs-searchform .betterdocs-search-field{
			font-size: <?php echo $defaults['betterdocs_search_field_font_size'] ?>px;
			color: <?php echo $defaults['betterdocs_search_field_color'] ?>;
		}
		.betterdocs-searchform svg.docs-search-icon {
			fill: <?php echo $defaults['betterdocs_search_icon_color'] ?>;
			height: <?php echo $defaults['betterdocs_search_icon_size'] ?>px;
		}
		.docs-search-close path.close-line {
			fill: <?php echo $defaults['betterdocs_search_close_icon_color'] ?>;	
		}
		.docs-search-close path.close-border {
			fill: <?php echo $defaults['betterdocs_search_close_icon_border_color'] ?>;	
		}
		.docs-search-loader {
			stroke: <?php echo $defaults['betterdocs_search_close_icon_border_color'] ?>;	
		}
		.betterdocs-searchform svg.docs-search-icon:hover {
			fill: <?php echo $defaults['betterdocs_search_icon_hover_color'] ?>;
		}
		.betterdocs-live-search .docs-search-result {
			width: <?php echo $defaults['betterdocs_search_result_width'] ?>%;
			max-width: <?php echo $defaults['betterdocs_search_result_max_width'] ?>px;
			background-color: <?php echo $defaults['betterdocs_search_result_background_color'] ?>;
			border-color: <?php echo $defaults['betterdocs_search_result_border_color'] ?>;
		}
		.betterdocs-search-result-wrap::before {
			border-color: transparent transparent <?php echo $defaults['betterdocs_search_result_background_color'] ?>;
		}
		.betterdocs-live-search .docs-search-result li {
			border-color: <?php echo $defaults['betterdocs_search_result_item_border_color'] ?>;
		}
		.betterdocs-live-search .docs-search-result li a {
			font-size: <?php echo $defaults['betterdocs_search_result_item_font_size'] ?>px;
			color: <?php echo $defaults['betterdocs_search_result_item_font_color'] ?>;
			padding-top: <?php echo $defaults['betterdocs_search_result_item_padding_top'] ?>px;
			padding-right: <?php echo $defaults['betterdocs_search_result_item_padding_right'] ?>px;
			padding-bottom: <?php echo $defaults['betterdocs_search_result_item_padding_bottom'] ?>px;
			padding-left: <?php echo $defaults['betterdocs_search_result_item_padding_left'] ?>px;
		}
		.betterdocs-live-search .docs-search-result li:only-child {
			font-size: <?php echo $defaults['betterdocs_search_result_item_font_size'] ?>px;
			color: <?php echo $defaults['betterdocs_search_result_item_font_color'] ?>;
		}
		.betterdocs-live-search .docs-search-result li:hover {
			background-color: <?php echo $defaults['betterdocs_search_result_item_hover_background_color'] ?>;
		}
		.betterdocs-live-search .docs-search-result li a:hover {
			color: <?php echo $defaults['betterdocs_search_result_item_hover_font_color'] ?>;
		}
	</style>
	<script>
		jQuery(document).ready(function() {
			var masonryGrid = jQuery(".betterdocs-categories-wrap.layout-masonry");
			if (masonryGrid.length) {
			masonryGrid.masonry({
				itemSelector: ".docs-single-cat-wrap",
				percentPosition: true,
				gutter: <?php echo $doc_page_column_space ?>
			});
			}
		});
	</script>
    <?php
}
add_action( 'wp_head', 'betterdocs_customize_css');