<?php
/**
 * This class responsible for database work
 * using wordpress functionality 
 * get_option and update_option.
 */
class BetterDocs_DB {
    /**
     * Get all default settings value.
     *
     * @param string $name
     * @return array
     */
    public static function default_settings(){
                
        $option_default = apply_filters('betterdocs_option_default_settings', array(
            'builtin_doc_page' => 1,
            'docs_slug' => 'docs',
            'doc_page' => '',
            'category_slug' => 'docs-category',
            'tag_slug' => 'docs-tag',
            'live_search' => 1,
            'search_result_image' => 1,
            'masonry_layout' => 1,
            'column_number' => 3,
            'posts_number' => 10,
            'post_count' => 1,
            'exploremore_btn' => 1,
            'exploremore_btn_txt' => 'Explore More',
            'doc_single' => 1,
            'enable_toc' => 1,
            'enable_sticky_toc' => 1,
            'title_link_ctc' => 1,
            'enable_breadcrumb' => 1,
            'enable_sidebar_cat_list' => 1,
            'email_feedback' => 1,
            'email_address' => get_option('admin_email'),
            'enable_navigation' => 1,
            'show_last_update_time' => 1,
            'enable_comment' => 1,
            'enable_credit' => 1,
            'customizer_link' => '',
            'category_grid' => '[betterdocs_category_grid]',
            'category_box' => '[betterdocs_category_box]',
            'category_list' => '[betterdocs_category_list]',
            'search_form' => '[betterdocs_search_form]',
            'feedback_form' => '[betterdocs_feedback_form]',
            
        ));

        return $option_default;
    }
    /**
     * Get all settings value from options table.
     *
     * @param string $name
     * @return array
     */
    public static function get_settings( $name = '' ){
        $settings = get_option( 'betterdocs_settings', true );
        
        if( ! empty( $name ) && isset( $settings[ $name ] ) ) {
            return $settings[ $name ];
        }
        
        if( ! empty( $name ) && ! isset( $settings[ $name ] ) ) {
            return '';
        }

        return is_array( $settings ) ? $settings : [];
    }
    /**
     * Update settings 
     * @param array $value
     * @return boolean
     */
    public static function update_settings( $value, $key = '' ){
        if( ! empty( $key ) ) {
            return update_option( $key, $value );
        }
        return update_option( 'betterdocs_settings', $value );
    }
}