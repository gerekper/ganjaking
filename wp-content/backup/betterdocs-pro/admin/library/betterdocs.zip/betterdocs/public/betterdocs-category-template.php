<?php
/**
 * Template archive docs
 *
 * @link       https://wpdeveloper.net
 * @since      1.0.0
 *
 * @package    BetterDocs
 * @subpackage BetterDocs/public
 */

get_header(); 
if (function_exists('flexia_setup')) {
	get_template_part( 'framework/views/template-parts/content', 'masthead' ); 
	flexia_page_header();
}
$object = get_queried_object();
?>

<div class="betterdocs-category-wraper betterdocs-single-wraper">
	<div class="betterdocs-search-form-wrap">
		<?php echo do_shortcode( '[betterdocs_search_form]' ); ?>
	</div>
	<div class="betterdocs-content-area">
		<?php 
		$enable_archive_sidebar = BetterDocs_DB::get_settings('enable_archive_sidebar');
		if($enable_archive_sidebar == 1){
		?>
        <aside id="betterdocs-sidebar">
            <div class="betterdocs-sidebar-content">
                <?php
                echo do_shortcode( '[betterdocs_category_grid]' );
                ?>
			</div>
        </aside><!-- #sidebar -->
		<?php } ?>
		<main id="main" class="docs-listing-main" role="main">
			<div class="docs-category-listing" >
				<div class="docs-cat-title">
					<?php printf( '<h3>%s </h3>', $object->name ); ?>
				</div>
				<div class="docs-list">
					<?php 
						$args = array(
							'post_type' => 'docs',
							'post_status' => 'publish',
							'posts_per_page' => -1,
							'tax_query' => array(
								array(
									'taxonomy' => 'doc_category',
									'field'    => 'slug',
									'terms'    => $object->slug,
								),
							),
						);
						$post_query = new WP_Query( $args );

						if ( $post_query -> have_posts() ) :

							echo '<ul>';
							while ( $post_query -> have_posts() ) : $post_query -> the_post();
								echo '<li><a href="'.get_the_permalink().'">'.get_the_title().'</a></li>';
							endwhile;
							
							echo '</ul>';

						else :

							echo '<p class="nothing-here">'.esc_html__( 'Sorry, no docs were found.', 'betterdocs' ).'</p>';
						
						endif;
						
					?>
				</div>
			</div>
		</main>
	</div>
</div>

<?php
get_footer();
