<div class="userpro-section userpro-column userpro-collapsible-1 userpro-collapsed-0"><?php _e( $upw_default_options->userpro_woocommerce_get_option( 'upw_purchase_tab_text' ), 'userpro-woocommerce');?></div>
<div class="userpro-field userpro-field-all-media userpro-field-view" style="display:block;">
<div class="upw-product-wrapper">
