<div class="wc_userpro_login" style="display:none;">
<?php  echo do_shortcode( '[userpro template=login]' ); ?>
</div>
