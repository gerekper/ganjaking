<form method="post" action="">

<h3><?php _e('Activate UserPro Messaging','userpro-msg'); ?></h3>
<table class="form-table">
	<tr valign="top">
		<th scope="row"><label for="userpro_msg_envato_code"><?php _e('Enter your Item Purchase Code','userpro-msg'); ?></label></th>
		<td>
			<input type="text" name="userpro_msg_envato_code" id="userpro_msg_envato_code" readonly="readonly" value="13z89fdcmr2ia646kphzg3bbz0jdpdja" class="regular-text" />
		</td>
	</tr>
</table>
</form>
