<label for="custom-widget-title" style="font-size: 14px;font-weight: bolder;"><?php _e('Title for Widget','userpro-dashboard'); ?></label>
<tr valign="top" class="">
	<td>
		<input required type="text" style="width:300px !important;" name="custom-widget-title" id="custom-widget-title" value="" />
	</td>
</tr>
<br>
<label for="custom-widget-content" style="font-size: 14px;font-weight: bolder;"><?php _e('Content for Widget','userpro-dashboard'); ?></label>
<tr valign="top" class="">
	<td>
		<textarea required rows="3" style="height: 120px !important;max-width: 100% !important;width: 92% !important;" name="custom-widget-content" id="custom-widget-content"></textarea>
	</td>	
</tr>
<br><br>
<tr valign="top" class="">
	<td>
		<input type="button" class="button" style="" name="userpro-widget-save" value="Save" id="userpro-widget-save" />	
	</td>
</tr>