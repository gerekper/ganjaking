import DiviGrooniGroovyMenu from './DiviGrooniGroovyMenu/DiviGrooniGroovyMenu';
import DiviGrooniGroovyMenuFullwidth from './DiviGrooniGroovyMenuFullwidth/DiviGrooniGroovyMenuFullwidth';

export default [DiviGrooniGroovyMenu, DiviGrooniGroovyMenuFullwidth];
