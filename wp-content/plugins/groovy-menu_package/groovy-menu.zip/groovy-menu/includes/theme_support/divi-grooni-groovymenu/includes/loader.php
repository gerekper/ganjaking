<?php

if ( ! class_exists( 'ET_Builder_Element' ) ) {
	return;
}

require_once __DIR__ . '/modules/DiviGrooniGroovyMenu/DiviGrooniGroovyMenu.php';
require_once __DIR__ . '/modules/DiviGrooniGroovyMenuFullwidth/DiviGrooniGroovyMenuFullwidth.php';
