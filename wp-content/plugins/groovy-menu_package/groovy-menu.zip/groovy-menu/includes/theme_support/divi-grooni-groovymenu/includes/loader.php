<?php

if ( ! class_exists( 'ET_Builder_Element' ) ) {
	return;
}

require_once __DIR__ . DIRECTORY_SEPARATOR . 'modules' . DIRECTORY_SEPARATOR . 'DiviGrooniGroovyMenu' . DIRECTORY_SEPARATOR . 'DiviGrooniGroovyMenu.php';
require_once __DIR__ . DIRECTORY_SEPARATOR . 'modules' . DIRECTORY_SEPARATOR . 'DiviGrooniGroovyMenuFullwidth' . DIRECTORY_SEPARATOR . 'DiviGrooniGroovyMenuFullwidth.php';
