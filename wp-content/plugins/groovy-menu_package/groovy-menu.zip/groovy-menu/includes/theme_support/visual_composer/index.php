<?php defined( 'ABSPATH' ) || die( 'This script cannot be accessed directly.' );

// Silence is gold.
