<?php defined( 'ABSPATH' ) || die( 'This script cannot be accessed directly.' );

global $gm_supported_module;

require_once dirname( __FILE__ ) . '/inc/GroovyMenuRoleCapabilities.php';
require_once dirname( __FILE__ ) . '/inc/GroovyMenuSettings.php';
require_once dirname( __FILE__ ) . '/inc/GroovyMenuStyle.php';
require_once dirname( __FILE__ ) . '/inc/GroovyMenuPreset.php';
require_once dirname( __FILE__ ) . '/inc/GroovyMenuUtils.php';
require_once dirname( __FILE__ ) . '/inc/GroovyMenuSingleMetaPreset.php';
require_once dirname( __FILE__ ) . '/inc/GroovyMenuIcons.php';
require_once dirname( __FILE__ ) . '/inc/GroovyMenuCategoryPreset.php';
require_once dirname( __FILE__ ) . '/inc/GroovyMenuGFonts.php';
