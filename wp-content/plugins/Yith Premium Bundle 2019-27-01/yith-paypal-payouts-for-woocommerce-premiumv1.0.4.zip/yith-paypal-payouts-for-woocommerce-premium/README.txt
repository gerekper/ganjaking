== YITH PayPal PayOuts for WooCommerce ==

= 1.0.4 =

* New: Support to WooCommerce 3.5.4
* Update: Plugin Framework

= 1.0.3 =

* New: Support to WordPress 5.0
* Update: Plugin Framework

= 1.0.2 =
* Update: Plugin Framework
* Update: Language files

= 1.0.1 =
* New: View payout item details in the popup
* New: Supports WooCommerce 3.4.5
* New: Supports WordPress 4.9.8
* New: Plugin framework template
* Tweak: Payout list structure
* Update: Language files
* Update: Plugin framework

= 1.0.0 =

* Initial release
