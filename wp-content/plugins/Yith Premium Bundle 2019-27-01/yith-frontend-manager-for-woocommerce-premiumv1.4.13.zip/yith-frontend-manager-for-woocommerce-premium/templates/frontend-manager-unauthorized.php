<div id="yith-wcfm-unauthorized">
	<h3 class="<?php echo $alert_title_class; ?>">
		<?php echo $alert_title; ?>
	</h3>

	<p><?php echo $alert_message; ?></p>
</div><!-- .page-content -->