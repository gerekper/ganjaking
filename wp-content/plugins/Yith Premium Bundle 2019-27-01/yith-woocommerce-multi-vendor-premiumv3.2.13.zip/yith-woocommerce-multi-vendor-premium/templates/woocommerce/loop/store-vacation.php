<div class="vacation woocommerce-info">
    <i class="far fa-calendar-times" aria-hidden="true"></i>
    <?php echo $vacation_message; ?>
</div>
