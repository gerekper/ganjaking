<?php

return array(
    'premium' => array(
        'home' => array(
            'type'   => 'custom_tab',
            'action' => 'yith_wcdn_premium_tab',
            'hide_sidebar' => true
        )
    )
);