<?php
if( !defined( 'ABSPATH')){
	exit;
}

if( !class_exists('YWCRBP_YITH_Dynamic_Pricing_Module')){

	class YWCRBP_YITH_Dynamic_Pricing_Module{

		protected static  $_instance;
		protected $dynamic_frontend;
		protected $role_based_product;
		public function __construct() {

			$this->dynamic_frontend = YITH_WC_Dynamic_Pricing_Frontend();
			$this->role_based_product = YITH_Role_Based_Prices_Product();

			$this->remove_dynamic_filters();


			add_filter( 'ywcrbp_simple_your_price_html', array( $this,'get_dynamic_pricing_html'), 20, 3 );
			add_filter( 'ywcrbp_simple_regular_price_html', array( $this,'get_dynamic_regular_pricing_html'), 20, 3 );
			add_filter( 'ywcrbp_simple_sale_price_html', array( $this,'get_dynamic_sale_pricing_html'), 20, 3 );
			add_filter( 'woocommerce_product_get_sale_price', array( $this, 'remove_sale_price' ),30, 2 );
			add_filter( 'woocommerce_product_variation_get_sale_price', array( $this, 'remove_sale_price' ),30, 2 );
			add_filter( 'yith_ywrbp_price', array( $this, 'change_role_based_prices' ),30, 2 );

			add_filter( 'ywcrbp_variable_regular_price_html', array( $this, 'get_dynamic_variable_regular_price' ), 20 ,4 );
			add_filter( 'ywcrbp_variable_sale_price_html', array( $this, 'remove_sale_price' ), 20 ,3 );
			add_filter( 'ywcrbp_variable_your_price_html', array( $this, 'get_dynamic_variable_your_price' ), 20 ,4 );

			add_filter( 'ywdpd_get_variable_prices', array( $this, 'get_variable_role_based_prices' ), 20 , 2 );


		}


		public function remove_dynamic_filters(){
			remove_filter( 'woocommerce_get_price_html', array( $this->dynamic_frontend, 'get_price_html' ), 10 );
			remove_filter( 'woocommerce_get_variation_price_html', array( $this->dynamic_frontend, 'get_price_html' ), 10 );
		}

		public function remove_role_based_filters(){
			remove_filter( 'woocommerce_get_price_html', array( $this->role_based_product, 'get_price_html' ), 11 );
			remove_filter( 'woocommerce_get_variation_price_html', array( $this->role_based_product, 'get_price_html' ), 11 );
		}

		/**
		 * @param string $price_html
		 * @param float $role_price
		 * @param WC_Product $product
		 */
		public function get_dynamic_pricing_html( $price_html, $role_price, $product ){

			$dynamic_price = (float)YITH_WC_Dynamic_Pricing()->get_discount_price( $role_price, $product );

			if( $dynamic_price < $role_price ){

				$your_price_html = wc_price( yit_get_display_price( $product, $role_price ) ) . $this->role_based_product->get_price_suffix( $product, $role_price );
				$dynamic_price_html = wc_price( yit_get_display_price( $product, $dynamic_price ) ) . $this->role_based_product->get_price_suffix( $product, $dynamic_price );
				$your_price_txt  = get_option( 'ywcrbp_your_price_txt' );
				$price_html = $your_price_txt.' <del>'.$your_price_html.'</del> '.$dynamic_price_html;
			}
			return $price_html;
		}

		/**
		 * @param string $price_html
		 * @param  float $regular_price
		 * @param WC_Product $product
		 */
		public function get_dynamic_regular_pricing_html( $price_html, $regular_price, $product ){

			$has_role_price = $this->role_based_product->get_role_based_price( $product );

			if( 'no_price' == $has_role_price  ){
				$dynamic_price = (float)YITH_WC_Dynamic_Pricing()->get_discount_price( $regular_price, $product );
				if( $dynamic_price < $regular_price ){

					$your_price_html = wc_price( yit_get_display_price( $product, $regular_price ) ) . $this->role_based_product->get_price_suffix( $product, $regular_price );
					$dynamic_price_html = wc_price( yit_get_display_price( $product, $dynamic_price ) ) . $this->role_based_product->get_price_suffix( $product, $dynamic_price );
					$your_price_txt  = get_option( 'ywcrbp_regular_price_txt' );
					$price_html = $your_price_txt.' <del>'.$your_price_html.'</del> '.$dynamic_price_html;

					$price_html = $this->role_based_product->get_formatted_price_html( $price_html, false, 'regular' );
				}
			}


			if( $has_role_price == $regular_price ){
				return '';
			}
			return $price_html;
		}

		/**
		 * @param string $price_html
		 * @param float $sale_price
		 * @param WC_Product  $product
		 */
		public function get_dynamic_sale_pricing_html( $price_html, $sale_price, $product ){

			if( YITH_WC_Dynamic_Pricing()->check_discount( $product )  ){
				return '';
			}
			return $price_html;
		}

		/**
		 * @param $sale_price
		 * @param $product
		 */
	 public function remove_sale_price( $sale_price, $product ){

		 if( YITH_WC_Dynamic_Pricing()->check_discount( $product )  ){
			 return '';
		 }
		 return $sale_price;
	 }

		/**
		 * @param string|float $role_based_prices
		 * @param WC_Product $product
		 *
		 * @return mixed
		 */
	 public function change_role_based_prices( $role_based_prices , $product ){

	 	if( 'no_price' == $role_based_prices && YITH_WC_Dynamic_Pricing()->check_discount( $product )  ){
		    $how_price = get_option( 'ywcrbp_apply_rule', 'regular' );

		    $sale_price = $product->get_sale_price( 'edit' );
		    if ( $sale_price > 0 && 'on_sale' == $how_price ) {
			    $role_based_prices = $sale_price;
		    } else {

			    $role_based_prices = $product->get_regular_price( 'edit' );
		    }

	    }


	    return $role_based_prices;
	 }

		/**
		 * @param string $regular_price_html
		 * @param WC_product $product
		 * @param float $min_regular_price
		 * @param float $max_regular_price
		 *
		 * @return string
		 */
	 public function get_dynamic_variable_regular_price( $regular_price_html, $product, $min_regular_price, $max_regular_price ){

	 	$your_prices = $this->role_based_product->get_variation_new_prices( $product );


	 	if( count( $your_prices )> 0 && YITH_WC_Dynamic_Pricing()->check_discount( $product )){
		    $min_your_price = floatval( current( $your_prices ) );
		    $max_your_price = floatval( end( $your_prices ) );

		    if( $min_regular_price == $min_your_price && $max_regular_price == $max_your_price ){
		    	return '';
		    }
	    }
	 	return $regular_price_html;
	 }

		/**
		 * @param string $your_price_html
		 * @param WC_Product $product
		 * @param float $min_your_price
		 * @param float $max_your_price
		 *
		 * @return |string
		 */
	 public function get_dynamic_variable_your_price(  $your_price_html, $product, $min_your_price, $max_your_price ){


	 	$min_price = (float)$this->dynamic_frontend->get_minimum_price( $product,1 );
	 	$max_price = (float)$this->dynamic_frontend->get_maximum_price( $product );

	 	$show_range_price = apply_filters( 'ywcrb_show_dynamic_range_price_html', true );

	 	$regular_price_txt = get_option( 'ywcrbp_your_price_txt' );

	 	if( $min_price !== $min_your_price && $max_price !== $max_your_price && YITH_WC_Dynamic_Pricing()->check_discount( $product ) ){

	 		$your_price_html = $regular_price_txt;

	 		$min_your_price_html = $this->role_based_product->get_your_price_html( $product, $min_your_price );
	 		$min_dp_price_html = $this->role_based_product->get_your_price_html( $product, $min_price );


	 		if( $show_range_price && $min_your_price !== $max_your_price ){

			    $max_your_price_html = $this->role_based_product->get_your_price_html( $product, $max_your_price );
			    $min_your_price_html     = ywcrbp_get_format_price_from_to( $product, $min_your_price_html, $max_your_price_html );
		    }

		    if( $show_range_price && $min_price!== $max_price ){

		    	$max_dp_price_html = $this->role_based_product->get_your_price_html( $product, $max_price );
			    $min_dp_price_html = ywcrbp_get_format_price_from_to( $product, $min_dp_price_html, $max_dp_price_html );
		    }

		    $your_price_html .= $this->role_based_product->get_formatted_price_html( "<del>". $min_your_price_html.'</del> '.$min_dp_price_html );
	    }

	 	return $your_price_html;
	 }

		/**
		 * @param array $prices
		 * @param WC_Product_Variable $product
		 * @return array
		 */
	 public function get_variable_role_based_prices( $prices, $product ){

	 	remove_filter( 'ywdpd_get_variable_prices', array( $this, 'get_variable_role_based_prices' ), 20  );
	 	$your_prices = $this->role_based_product->get_variation_new_prices( $product );

	 	if( count( $your_prices) > 0 ){

	 		$prices['price'] = $your_prices;
	    }
		 add_filter( 'ywdpd_get_variable_prices', array( $this, 'get_variable_role_based_prices' ), 20 , 2 );

	    return $prices;
	 }




		/**
		 * Returns single instance of the class
		 *
		 * @since 1.0.0
		 */
		public static function get_instance() {
			if ( is_null( self::$_instance ) ) {
				self::$_instance = new self();
			}

			return self::$_instance;
		}
	}
}

YWCRBP_YITH_Dynamic_Pricing_Module::get_instance();
