<div class="ywsfd-social-button fb-like-btn">
	<div class="fb-like" data-href="<?php echo $social_params['sharing']['url'] ?>" data-layout="button" data-action="like" data-show-faces="false" data-share="false" data-size="small"></div>
</div>