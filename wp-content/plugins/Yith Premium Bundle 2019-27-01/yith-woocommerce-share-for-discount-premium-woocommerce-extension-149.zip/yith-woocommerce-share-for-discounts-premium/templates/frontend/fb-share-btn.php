<div class="ywsfd-social-button fb-share-btn">
	<a href="#" data-href="<?php echo $social_params['sharing']['url'] ?>" class="ywsfd-facebook-share">
		<i class="fa fa-facebook-official"></i> <span><?php echo apply_filters( 'ywsfd_facebook_share_label', __( 'Share', 'yith-woocommerce-share-for-discounts' ) ) ?></span>
	</a>
</div>