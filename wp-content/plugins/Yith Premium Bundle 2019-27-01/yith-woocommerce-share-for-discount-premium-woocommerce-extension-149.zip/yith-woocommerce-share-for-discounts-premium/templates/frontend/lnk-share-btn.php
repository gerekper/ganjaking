<div class="ywsfd-social-button lnk-btn">
	<a href="#" data-href="<?php echo $social_params['sharing']['url'] ?>" class="ywsfd-linkedin-button">
		<i class="fa fa-linkedin"></i>
		<?php echo apply_filters( 'ywsfd_linkedin_label', __( 'Share', 'yith-woocommerce-share-for-discounts' ) ) ?>
	</a>
</div>