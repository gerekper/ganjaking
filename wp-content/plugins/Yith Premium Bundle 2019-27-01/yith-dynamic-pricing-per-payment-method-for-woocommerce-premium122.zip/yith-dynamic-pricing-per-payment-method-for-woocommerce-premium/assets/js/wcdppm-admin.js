/**
 * admin.js
 *
 * @author Your Inspiration Themes
 * @package YITH Dynamic Pricing per Payments Methods for WooCommerce
 * @version 1.0.0
 */

jQuery(document).ready( function($) {

    /*Js custom post type rule*/
    //show_or_hide_checkbox();

    $('#_schedule_from').datepicker({
        dateFormat: 'yy-mm-dd',
    });
    $('#_schedule_to').datepicker({
        dateFormat: 'yy-mm-dd',
    });

    $('#_yith_wcdppm_user_role').select2({
    });

    /*$('#_dynamic_type').on('change',function(){
        show_or_hide_checkbox();
    });

    function show_or_hide_checkbox() {
        if($('#_dynamic_type').val() == 'dec_value' || $('#_dynamic_type').val() =='inc_value') {
            $('#_include_tax').prop('checked', true);
            $('.checkbox').hide();
        } else {
            $('.checkbox').show();
        }
    }*/

});


