/**
 * frontend.js
 *
 * @author Your Inspiration Themes
 * @package YITH Dynamic Pricing per Payments Methods for WooCommerce
 * @version 1.0.0
 */

jQuery( document ).ready( function ( $ ) {
    var maybe_is_wc_stripe_active = true,
        wc_stripe_total_set       = false;

    var change_amount_and_total = function ( $gateway ) {
        var $gateway_data   = $( '#yith-wcdppm-gateway-' + $gateway ),
            amount          = $gateway_data.data( 'amount' ),
            total           = $gateway_data.data( 'total' ),
            json            = $gateway_data.data('payment-method'),
            $order_review   = $( '#order_review' ),
            $amount_td      = $order_review.find( '#yith-wcdppm-amount' ).first(),
            $order_total_td = $order_review.find( '.order-total > td' ).first();
            $order_total = yith_wcdppm_frontend.dom['order-total'];
            $total_tax = yith_wcdppm_frontend.dom['total-tax'];
            
            if ( amount == 0 ) {
                $('.yith-wcdppm-payment-method').hide();
            } else {
                $('.yith-wcdppm-payment-method').show();

                if(amount > 0) {
                    $("#yith-wcdppm-amount").empty();
                    $("#yith-wcdppm-amount").append('+'+json.amount);
                } else {
                    $("#yith-wcdppm-amount").empty();
                    $("#yith-wcdppm-amount").append(json.amount);
                }
            }
            
            if( total > 0) {
                $($order_total).empty();
                $($order_total).append(json.total);
            } else {
                $($order_total).empty();
                $($order_total).append(json.free);
            }
            $($total_tax).empty();
            $($total_tax).append(json.tax);

        //Integration with WooStripe
        if ($gateway == 'stripe' && maybe_is_wc_stripe_active && !wc_stripe_total_set ) {
            var $wc_stripe_data         = $('#stripe-payment-data');
            maybe_is_wc_stripe_active   = $wc_stripe_data.length > 0;

            $wc_stripe_data.attr( 'data-amount', total * 100 );
            wc_stripe_total_set = true;
        }

        if(typeof yith_wcdppm_frontend.dom['custom-code'] != 'undefined') {
            eval(yith_wcdppm_frontend.dom['custom-code']);
        }


    };

    $( document ).on( 'change', '.input-radio[name="payment_method"]', function ( event ) {
        var $target = $( event.target );
        change_amount_and_total( $target.val() );
    } );


    $( document.body ).on( 'updated_checkout', function () {
        change_amount_and_total( $( '.woocommerce-checkout input[name="payment_method"]:checked' ).attr( 'value' ) );
    } );

} );


