<?php
/*
 * This file belongs to the YIT Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 */
if ( ! defined( 'YITH_WCDPPM_VERSION' ) ) {
    exit( 'Direct access forbidden.' );
}

/**
 *
 *
 * @class      YITH_Dynamic_Pricing_Payments_Methods_Premium
 * @package    Yithemes
 * @since      Version 1.0.0
 * @author     Your Inspiration Themes
 *
 */

if ( ! class_exists( 'YITH_Dynamic_Pricing_Payments_Methods_Premium' ) ) {
    /**
     * Class YITH_Dynamic_Pricing_Payments_Methods_Premium
     *
     * @author Carlos Rodríguez <carlos.rodriguez@yourinspiration.it>
     */
    class YITH_Dynamic_Pricing_Payments_Methods_Premium extends YITH_Dynamic_Pricing_Payments_Methods {

        /**
         * Main Instance
         *
         * @var YITH_Dynamic_Pricing_Payments_Methods_Premium
         * @since 1.0
         * @access protected
         */
        protected static $_instance = null;
        

        /**
         * Construct
         *
         * @author Carlos Rodríguez <carlos.rodriguez@yourinspiration.it>
         * @since 1.0
         */
        public function __construct(){
            
            add_filter('yith_wcdppm_require_class',array($this,'load_premium_classes'));
            
            parent::__construct();
        }
        
        /**
         * Add premium files to Require array
         *
         * @param $require The require files array
         *
         * @return Array
         * @author Carlos Rodríguez <carlos.rodriguez@yourinspiration.it>
         * @since 1.0
         *
         */
        public function load_premium_classes( $require ){
            $frontend = array(
                'includes/class.yith-wcdppm-dynamic-payment-methods-frontend-premium.php',
            );
            $common = array(
                'includes/class.yith-wcdppm-dynamic-payment-methods-functions-premium.php',
                'includes/compatibility/class.yith-wcdppm-compatibility.php',
                'includes/compatibility/class.yith-wcdppm-aelia-currency-switcher-compatibility.php',
            );
            $admin = array(
                'includes/class.yith-wcdppm-dynamic-payment-methods-admin-premium.php',
                'includes/class.yith-wcdppm-dynamic-payment-methods-list-table-premium.php',

            );
            $require['admin']   = array_merge($require['admin'],$admin);
            $require['frontend']  = array_merge($require['frontend'],$frontend);
            $require['common']    = array_merge($require['common'],$common);

            return $require;
        }

        public function init_classes() {
            $this->functions = YITH_WCDPPM_Functions::get_instance();
        }

        /**
         * Function init()
         *
         * Instance the admin or frontend classes
         *
         * @author Carlos Rodríguez <carlos.rodriguez@yourinspiration.it>
         * @since  1.0
         * @return void
         * @access protected
         */
        public function init() {
            if ( is_admin() ) {
                $this->admin = new YITH_Dynamic_Pricing_Payments_Methods_Admin_Premium();
            }

            if ( ! is_admin() || ( defined( 'DOING_AJAX' ) && DOING_AJAX ) ) {
                $this->frontend = new YITH_Dynamic_Pricing_Payments_Methods_Frontend_Premium();
            }
        }
    }
    
    
}