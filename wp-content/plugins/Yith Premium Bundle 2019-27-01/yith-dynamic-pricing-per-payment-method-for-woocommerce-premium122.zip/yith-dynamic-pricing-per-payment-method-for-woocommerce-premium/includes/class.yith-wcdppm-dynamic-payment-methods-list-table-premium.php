<?php

if ( !defined( 'ABSPATH' ) || !defined( 'YITH_WCDPPM_VERSION' ) ) {
    exit; // Exit if accessed directly
}

/**
 * Dynamic Pricing Payment per Methods List Table Premium
 *
 * @class   YITH_WCDPPM_Dynamic_Pricing_Per_Payment_Methods_List_Table_Premium
 * @package YITH Dynamic Pricing Per Payment Methods Premium
 * @since   1.0.0
 * @author  Yithemes
 */


class YITH_WCDPPM_Dynamic_Pricing_Per_Payment_Methods_List_Table_Premium extends YITH_WCDPPM_Dynamic_Pricing_Per_Payment_Methods_List_Table
{

    /**
     * YITH_WCDPPM_Dynamic_Pricing_Per_Payment_Methods_List_Table_Premium constructor.
     *
     * @param array $args
     */
    public function __construct($args = array())
    {
        add_filter('yith_wcdppm_dynamic_pricing_per_payment_method_table_list_columns',array($this,'list_columns'));
        parent::__construct();
    }

    public function list_columns ( $columns ) {
        $new_columns = array(
            'custom_text' => __( 'Custom text', 'yith-dynamic-pricing-per-payment-method-for-woocommerce' ),
            'role_to_apply' => __( 'User role', 'yith-dynamic-pricing-per-payment-method-for-woocommerce' ),
            'include_tax' => __('Include tax','yith-dynamic-pricing-payment-method-for-woocoomerce'),
            'min_cart' => __('Min cart','yith-dynamic-pricing-payment-method-for-woocoomerce'),
            'max_cart' => __('Max cart','yith-dynamic-pricing-payment-method-for-woocoomerce'),
            'post_date_from' => __( 'Date: From', 'yith-dynamic-pricing-per-payment-method-for-woocommerce' ),
            'post_date_to' => __( 'Date: To', 'yith-dynamic-pricing-per-payment-method-for-woocommerce' ),
        );

        $columns = array_merge($columns,$new_columns);

        return $columns;
    }

    /**
     * @param object $item
     * @param string $column_name
     *
     * @return string|void
     */
    function column_default( $item, $column_name ) {

        $functions = YITH_Dynamic_Pricing_Payments_Methods()->functions;
        switch( $column_name ) {
            
            case 'payment_method':
                $payment_method = get_post_meta( $item->ID, '_payment_methods', true);
                $payments = $functions->yith_wcdppm_get_payment_gateway();
                if (!empty($payments[$payment_method])) {
                    $payment = $payments[$payment_method];
                    return '<span class="status ' . $payment . '">' . $payment . '</span>';
                }else {
                    return '';
                }
                break;
            case 'rule_type':
                $rule_type = get_post_meta( $item->ID, '_dynamic_type', true);
                $rules = $functions->yith_wcdppm_get_type_dynamic_pricing();
                $rule = ($rule_type) ? $rules[$rule_type] : __('Decrease by value','yith-dynamic-pricing-per-payment-method-for-woocommerce');
                return '<span class="status '.$rule.'">'.$rule.'</span>';
                break;
            case 'title':
                return ($item->post_title) ? '<span>'.$item->post_title.'</span>':'';
                break;
            case 'amount':
                $amount = get_post_meta ($item->ID,'_amount',true);
                if ($amount) {
                    $rule_type = get_post_meta( $item->ID, '_dynamic_type', true);
                    if(($rule_type == 'dec_percent') || ($rule_type == 'inc_percent')){
                        return '<span class="status '.$amount.'">'.wc_format_decimal($amount).'%'.'</span>';
                    }else {
                        return '<span class="status '.$amount.'">'.wc_format_decimal($amount).get_woocommerce_currency_symbol().'</span>';
                    }
                } else {
                    return '';
                }
                break;
            case 'custom_text':
                $custom_text = get_post_meta($item->ID,'_custom_text',true);
                return $custom_text;
                break;
            case 'role_to_apply':
                $role_to_apply = get_post_meta( $item->ID, '_yith_wcdppm_user_role', true);
                return  ($role_to_apply) ? implode(',',$role_to_apply) : _e('All','yith-dynamic-pricing-per-payment-method-for-woocommerce');
                break;
            case 'include_tax':
                $include_tax = get_post_meta( $item->ID, '_include_tax', true);
                if($include_tax) {
                    return '&#x2714';
                } else {
                    return '&#x2716';
                }
                break;
            case 'min_cart':
                $min_cart = get_post_meta( $item->ID, '_min_cart', true);
                return '<span class="status '.$min_cart.'">'.wc_price($min_cart).'</span>';
                break;
            case 'max_cart':
                $max_cart = get_post_meta( $item->ID, '_max_cart', true);
                return ($max_cart) ? '<span class="status '.$max_cart.'">'.wc_price($max_cart).'</span>': '';
                break;
            case 'post_date_from':
                $post_date_from = get_post_meta( $item->ID, '_schedule_from', true);
                return  ( $post_date_from ) ?  $post_date_from  : '';
                break;
            case 'post_date_to':
                $post_date_to = get_post_meta( $item->ID, '_schedule_to', true);
                return  ( $post_date_to) ?  $post_date_to  : '';
                break;

            default:
                return apply_filters('yith_wcdppm_column_default','',$item, $column_name);
        }
    }

}
