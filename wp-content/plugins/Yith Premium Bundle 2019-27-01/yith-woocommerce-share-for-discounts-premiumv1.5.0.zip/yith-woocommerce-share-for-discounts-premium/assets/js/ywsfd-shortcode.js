jQuery(function ($) {

    if (window.QTags !== undefined) {
        QTags.addButton('ywsfd_shortcode', ywsfd_shortcode.title, function () {
            var str = '[ywsfd_shortcode]',
                win = window.dialogArguments || opener || parent || top;

            win.send_to_editor(str);
            var ed;
            if (typeof tinyMCE !== 'undefined' && (ed = tinyMCE.activeEditor) && !ed.isHidden()) {
                ed.setContent(ed.getContent());
            }
        });
    }

});
