jQuery( document ).ready( function( $ ){
    var stripe_mode = $( '#woocommerce_yith-stripe_mode' ),
        save_cards = $( '#woocommerce_yith-stripe_save_cards' ),
        save_cards_mode = $( '#woocommerce_yith-stripe_save_cards_mode' ),
        billing_hosted_fields = $( '#woocommerce_yith-stripe_add_billing_hosted_fields' ),
        shipping_hosted_fields = $( '#woocommerce_yith-stripe_add_shipping_hosted_fields' ),
        billing_fields = $( '#woocommerce_yith-stripe_add_billing_fields' ),
        add_hidden_billing_fields_only = $( '#woocommerce_yith-stripe_add_hidden_billing_fields_only' ),
        enable_bitcoin = $( '#woocommerce_yith-stripe_enable_bitcoin' ),
        elements_show_zip = $( '#woocommerce_yith-stripe_elements_show_zip' );

    stripe_mode.on( 'change', function(){
        var t = $(this),
            v = t.val();

        if( v === 'standard' ){
            save_cards.closest( 'tr' ).show();
            save_cards_mode.closest( 'tr' ).show();
            billing_hosted_fields.closest( 'tr' ).hide();
            shipping_hosted_fields.closest( 'tr' ).hide();
            billing_fields.closest( 'tr' ).show();
            add_hidden_billing_fields_only.closest( 'tr' ).show();
            enable_bitcoin.closest( 'tr' ).hide();
            elements_show_zip.closest( 'tr' ).hide();
        }
        else if( v === 'hosted_std' ){
            save_cards.closest( 'tr' ).hide();
            save_cards_mode.closest( 'tr' ).hide();
            billing_hosted_fields.closest( 'tr' ).hide();
            shipping_hosted_fields.closest( 'tr' ).hide();
            billing_fields.closest( 'tr' ).hide();
            add_hidden_billing_fields_only.closest( 'tr' ).hide();
            enable_bitcoin.closest( 'tr' ).hide();
            elements_show_zip.closest( 'tr' ).hide();
        }
        else if( v === 'hosted' ){
            save_cards.closest( 'tr' ).hide();
            save_cards_mode.closest( 'tr' ).hide();
            billing_hosted_fields.closest( 'tr' ).show();
            shipping_hosted_fields.closest( 'tr' ).show();
            billing_fields.closest( 'tr' ).hide();
            add_hidden_billing_fields_only.closest( 'tr' ).hide();
            enable_bitcoin.closest( 'tr' ).show();
            elements_show_zip.closest( 'tr' ).hide();
        }
        else if( v === 'elements' ){
            save_cards.closest( 'tr' ).show();
            save_cards_mode.closest( 'tr' ).show();
            billing_hosted_fields.closest( 'tr' ).hide();
            shipping_hosted_fields.closest( 'tr' ).hide();
            billing_fields.closest( 'tr' ).show();
            add_hidden_billing_fields_only.closest( 'tr' ).show();
            enable_bitcoin.closest( 'tr' ).hide();
            elements_show_zip.closest( 'tr' ).show();
        }
    } ).change();
} );