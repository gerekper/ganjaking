<?php
/**
 * Function file
 *
 * @author Your Inspiration Themes
 * @package YITH WooCommerce Stripe
 * @version 1.0.0
 */

if ( ! defined( 'YITH_WCSTRIPE' ) ) {
	exit;
} // Exit if accessed directly

if( ! function_exists( 'yith_wcstripe_return_10' ) ){
	/**
	 * Just returns 10
	 *
	 * @return int 10
	 */
	function yith_wcstripe_return_10(){
		return 10;
	}
}

if( ! function_exists( 'yith_wcstripe_error_message_call' ) ){
    /**
     *
     * @return error
     */
    function yith_wcstripe_error_message_call( $errors, $err, $message ){

        return apply_filters( 'yith_wcstripe_error_message', $errors[ $err['code'] ], $message, $err['code'], $err );

    }
}

if( ! function_exists( 'yith_wcstripe_error_message_order_note_call' ) ){
    /**
     *
     * @return error
     */
    function yith_wcstripe_error_message_order_note_call( $e, $err ){

        return apply_filters( 'yith_wcstripe_error_message_order_note', 'Stripe Error: ' . $e->getHttpStatus() . ' - ' . $e->getMessage(), $e, $err );

    }
}