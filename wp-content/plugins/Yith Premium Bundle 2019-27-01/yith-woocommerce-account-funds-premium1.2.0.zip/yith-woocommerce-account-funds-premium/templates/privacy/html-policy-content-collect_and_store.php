<p>All the information about transactions involving your funds/credits.</p>
<p>So, all your wallet top-ups/deposits, payments and refunds, and all actions performed by external plugins that change your credit balance.</p>
<p>Moreover, your current balance is saved.</p>
<p>During the creation of the order, we will store the meta fields related to the funds used (whenever you pay using your credits) or the funds you’ve been credited (whenever you top up your account). These fields, so, are subject to WooCommerce plugin Privacy Policy.</p>
<p>The plugin sends two emails to the user.</p>
<p>The first one is sent every time the credit balance goes below a given threshold and invites users to top up the account.</p>
<p>The second one is sent every time the admin applies changes to the credit balance from the backend.</p>

