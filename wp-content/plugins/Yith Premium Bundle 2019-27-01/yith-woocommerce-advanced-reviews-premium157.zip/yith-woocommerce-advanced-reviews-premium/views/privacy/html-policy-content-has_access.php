<p><?php _ex( 'Members of our team have access to the information you provide us. For example, both Administrators and Shop Managers can access:', 'Privacy Policy Content', 'yith-woocommerce-advanced-reviews' ) ?></p>

<ul>
    <li><?php _ex( 'Author name, author email, author IP, date, title and content of the reviews you have made', 'Privacy Policy Content', 'yith-woocommerce-advanced-reviews' ); ?></li>
</ul>