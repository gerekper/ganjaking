jQuery( function ( $ ) {

    /* ------------------ Events to show TOOLTIPS ------------------  */
    $( document ).on( 'mouseover', '.yith_wceue_tooltip', function ( e ) {
        var element    = $( e.target ),
            image_url  = element.data( 'image' ),
            product_id = element.data( 'product-id' ),
            tt         = $( '<div id="yith-wceue-tooltip-container-' + product_id + '"/>' ).addClass( 'yith-wceue-tooltip-container' ).append( '<img src="' + image_url + '" />' );

        if(element.is('.yith-wceue-eu-energy-label-mini')){
            tt.addClass('yith-wceue-tooltip-container-mini')
        }

        $( document.body ).append( tt );
        tt.css( {
            left: element.offset().left + 'px',
            top: (element.offset().top + 40) + 'px',
            position: 'absolute'
        } );
    } )

        .on( 'mouseout', '.yith_wceue_tooltip', function () {
            $( '.yith-wceue-tooltip-container' ).remove();
        } );
    /* ---------------------------------------------------------------  */

} );