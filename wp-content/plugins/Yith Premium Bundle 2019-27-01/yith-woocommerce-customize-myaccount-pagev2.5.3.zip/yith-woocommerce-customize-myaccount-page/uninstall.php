<?php
/**
 * Uninstall plugin
 *
 * @author YITH
 * @package YITH WooCommerce Customize My Account Page
 * @version 1.0
 */

// If uninstall not called from WordPress exit
if( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}