<div class="hover_a2w_fulfillment">
    <span class="helper"></span>
    <div>
        <div class="pr"><?php sprintf( _x('Placing orders %d/%d...', 'Status', 'ali2woo'),0,0); ?></div>
    <?php /*    <div class="info">Check <a href="javascript: alert('We will add this feature soon.')">Status Page</a> for more details.</div> */ ?>
        <div class="tip"></div>
        <button class="solve"><?php _e('Switch', 'ali2woo'); ?></button>
        <button class="continue"><?php _e('Continue', 'ali2woo'); ?></button>
        <button class="skip"><?php _e('Skip', 'ali2woo'); ?></button>
        <button class="refresh"><?php _e('"Refresh" Page', 'ali2woo'); ?></button>
        <button class="payall"><?php _e('Orders List', 'ali2woo'); ?></button>
        <button class="close"><?php _e('Close', 'ali2woo'); ?></button>
    </div>
</div>