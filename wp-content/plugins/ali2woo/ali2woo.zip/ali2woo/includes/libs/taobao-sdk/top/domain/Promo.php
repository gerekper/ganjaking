<?php

/**
 * 返回主题活动列表
 * @author auto create
 */
class Promo
{
	
	/** 
	 * 主题活动的商品数量
	 **/
	public $product_num;
	
	/** 
	 * 主题活动描述
	 **/
	public $promo_desc;
	
	/** 
	 * 主题活动名称
	 **/
	public $promo_name;	
}
?>