<?php

/**
 * 推广链接列表
 * @author auto create
 */
class PromotionLink
{
	
	/** 
	 * 推广链接
	 **/
	public $promotion_link;
	
	/** 
	 * 原始链接或者值
	 **/
	public $source_value;	
}
?>