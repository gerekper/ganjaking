<?php

/**
 * 返回结果明细
 * @author auto create
 */
class TrafficOrderResultDto
{
	
	/** 
	 * 当前页记录条数
	 **/
	public $current_record_count;
	
	/** 
	 * 订单内容明细
	 **/
	public $orders;	
}
?>