<?php

/**
 * 返回结果明细
 * @author auto create
 */
class TrafficFeaturedPromoResultDto
{
	
	/** 
	 * 当前返回数量
	 **/
	public $current_record_count;
	
	/** 
	 * 返回主题活动列表
	 **/
	public $promos;	
}
?>