<?php

/**
 * 返回记录结果列表
 * @author auto create
 */
class Result
{
	
	/** 
	 * 类目信息
	 **/
	public $categories;
	
	/** 
	 * 返回结果数量
	 **/
	public $total_result_count;	
}
?>