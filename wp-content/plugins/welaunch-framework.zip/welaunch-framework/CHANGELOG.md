# Changelog
======
1.0.2
======
- FIX:	Updater now centralized in this plugin

======
1.0.1
======
- NEW:	Bundle support
- FIX:	Licenses not showed after adding
- FIX:	Removed more tracking stuff

======
1.0.0
======
- Inital release