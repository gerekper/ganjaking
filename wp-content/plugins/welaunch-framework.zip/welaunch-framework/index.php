<?php
/**
 * Silence is golden.
 *
 * @package weLaunch Framework
 */

echo null;
