<?php
/**
 * Debug Options Object
 *
 * @package     weLaunchFramework
 * @author      Kevin Provance (kprovance)
 * @version     3.5.4
 */

defined( 'ABSPATH' ) || exit;

// Don't duplicate me!
if ( ! class_exists( 'weLaunch_Options_Object', false ) ) {

	/**
	 * Main weLaunch_options_object class
	 *
	 * @since       1.0.0
	 */
	class weLaunch_Options_Object extends weLaunch_Field {

		/**
		 * weLaunch_Options_Object constructor.
		 *
		 * @param array  $field Field array.
		 * @param string $value Value array.
		 * @param object $parent weLaunchFramework object.
		 *
		 * @throws ReflectionException .
		 */
		public function __construct( $field = array(), $value = '', $parent ) {
			parent::__construct( $field, $value, $parent );

			$this->is_field = $this->parent->extensions['options_object']->is_field;
		}

		/**
		 * Set field defaults.
		 */
		public function set_defaults() {
			$defaults = array(
				'options'          => array(),
				'stylesheet'       => '',
				'output'           => true,
				'enqueue'          => true,
				'enqueue_frontend' => true,
			);

			$this->field = wp_parse_args( $this->field, $defaults );
		}

		/**
		 * Field Render Function.
		 * Takes the vars and outputs the HTML for the field in the settings
		 *
		 * @since       1.0.0
		 * @access      public
		 * @return      void
		 */
		public function render() {
			if ( version_compare( phpversion(), '5.3.0', '>=' ) ) {
				$json = wp_json_encode( $this->parent->options, true );
			} else {
				$json = wp_json_encode( $this->parent->options );
			}

			$defaults = array(
				'full_width' => true,
				'overflow'   => 'inherit',
			);

			$this->field = wp_parse_args( $this->field, $defaults );

			if ( $this->is_field ) {
				$full_width = $this->field['full_width'];
			}

			$do_close = false;

			$id = $this->parent->args['opt_name'] . '-' . $this->field['id'];

			if ( ! $this->is_field || ( $this->is_field && false === $full_width ) ) {
				?>
				<style>#<?php echo esc_html( $id ); ?>{padding: 0;}</style>
				<?php // phpcs:ignore WordPress.CodeAnalysis.EmptyStatement ?>
				<?php echo '</td></tr></table>'; ?>
				<table id="<?php echo esc_attr( $id ); ?>" class="form-table no-border welaunch-group-table welaunch-raw-table" style=" overflow: <?php esc_attr( $this->field['overflow'] ); ?>;">
				<tbody><tr><td>
				<?php
				$do_close = true;
			}
			?>
			<fieldset
					id="<?php echo esc_attr( $id ); ?>-fieldset"
					class="welaunch-field welaunch-container-<?php echo esc_attr( $this->field['type'] ) . ' ' . esc_attr( $this->field['class'] ); ?>"
					data-id="<?php echo esc_attr( $this->field['id'] ); ?>">

				<h3><?php esc_html_e( 'Options Object', 'welaunch-framework' ); ?></h3>
				<div id="welaunch-object-browser"></div>
				<div id="welaunch-object-json" class="hide"><?php echo( $json ); // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
				<a
					href="#" id="consolePrintObject"
					class="button">
					<?php esc_html_e( 'Show Object in Javascript Console Object', 'welaunch-framework' ); ?></a>

			</fieldset>
			<?php if ( true === $do_close ) { ?>
				</td></tr></table>
				<table class="form-table no-border" style="margin-top: 0;">
					<tbody>
					<tr style="border-bottom: 0;">
						<th></th>
						<td>
			<?php } ?>
			<?php
		}

		/**
		 * Enqueue Function.
		 * If this field requires any scripts, or css define this function and register/enqueue the scripts/css
		 *
		 * @since       1.0.0
		 * @access      public
		 * @return      void
		 */
		public function enqueue() {
			if ( $this->parent->args['dev_mode'] ) {
				wp_enqueue_script(
					'welaunch-extension-options-object-js',
					$this->url . 'welaunch-options-object' . weLaunch_Functions::is_min() . '.js',
					array( 'jquery', 'welaunch-js' ),
					weLaunch_Extension_Options_Object::$version,
					true
				);
			}

			wp_enqueue_style(
				'welaunch-options-object',
				$this->url . 'welaunch-options-object.css',
				array(),
				weLaunch_Extension_Options_Object::$version,
				'all'
			);
		}
	}
}
