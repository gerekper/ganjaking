<?php
/**
 * Silence is golden.
 *
 * @package weLaunch Framework
 */

// Shim file for odd theme integrations.

echo null;
