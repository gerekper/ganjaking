=== WP Fusion - Webhooks Addon ===
Contributors: verygoodplugins
Tags: wp fusion, webhooks, zapier
Requires at least: 4.0
Tested up to: 5.2.4
Stable tag: 1.3.1

Allows sending webhooks from WP Fusion to Zapier or any other third party service.

== Description ==

Allows sending webhooks from WP Fusion to Zapier or any other third party service.

== Changelog ==

= 1.3.1 - 10/24/2019 =
* Submitted form data will now be included in Register and Update webhooks

= 1.3 - 8/5/2019 =
* Added "Form Submitted" trigger
* Fixed tag setting box not saving when empty

= 1.2 - 2/7/2019 =
* Added check all and uncheck all option for Post Fields setting
* Fix for data in wp_users table not being sent

= 1.1 - 12/22/2018 =
* Fixed "Send Test" button for unpublished webhooks

= 1.0 - 12/21/2018 =
* Initial release