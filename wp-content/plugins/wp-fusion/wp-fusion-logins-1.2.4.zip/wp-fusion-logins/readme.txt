=== WP Fusion - Logins Addon ===
Contributors: verygoodplugins
Tags: wp fusion, login tags, tags, user tags, crm, redirect, login redirect
Requires at least: 4.0
Tested up to: 5.7.1
Stable tag: 1.2.4

Enables tracking last user login, as well as tagging users who have not logged in for a set amount of days. Enables redirecting on login based on a user's tags.

== Description ==
Enables tracking last user login, as well as tagging users who have not logged in for a set amount of days. Also enables redirecting on login based on a user's tags.

== Installation ==
Requires WP Fusion to be installed first.

= 1.2.4 - 4/15/2021 =
* Stale account tags will now be removed during "Once a day on site visit" daily check, instead of waiting for a wp_login event
* Reduced number of database queries required displaying admin settings panel
* Fixed login redirects running during AJAX requests
* Fixed errors during login if WP Fusion wasn't active

= 1.2.3 = 11/16/2020 =
* Fixed login count not updating when login count method was set to "When a user actually logs in"
* "Recovered" account tags will now be removed if the account becomes stale again

= 1.2.2 - 9/28/2020 =
* Updated for tags select compatibility with WP Fusion 3.35

= 1.2.1 - 9/7/2020 =
* Re-enabled login redirects on WooCommerce's My Account page
* Fixed changed date( 'z' ) to current_time( 'z' ) for determining the current day when using Once A Day on Site Visit login tracking
* Fixed stale account tags only being applied if the cron job was triggered by an admin
* Fixed Uncaught ArgumentCountError during login with WooCommerce on some configs

= 1.2 - 7/20/2020 =
* Blocked login redirects from running on WooCommerce checkout / account logins
* Moved last_login usermeta key to wpf_last_login to prevent plugin conflicts
* Added .pot file

= 1.1.3 - 5/12/2020 =
* Changed time() to current_time() to respect the site's timezone
* Fixed login count rules not respecting required tags

= 1.1.2 - 4/1/2020 =
* Fixed login count not updating when someone logged in and count method was set to Daily

= 1.1.1 - 3/25/2020 =
* Made daily login check the default
* Fixed login daily check not updating last login date
* Removed use of transients in daily login check

= 1.1 - 3/17/2020 =
* Added Last Login column to users view
* Added WooCommerce checkout redirects
* Stopped setting last_login when users are imported

= 1.0.1 - 8/27/2019 =
* Fixed last_login not being tracked for admins
* Added catchall redirect

= 1.0 - 8/6/2019 =
* Increased limit on number of posts shown in dropdowns
* Fixed Stale Accounts tags not applying

= 0.9 - 6/2/2019 =
* Prevented last_login field from loading during a webhook

= 0.8 - 5/31/2019 =
* Added last login to admin user profile
* Fix for login count field not syncing
* last_login will now be set when a user is imported

= 0.7 - 5/21/2019 =
* Added recovered stale login tagging
* Added compatibility class
* Fixed login count rules not applying tags

= 0.6 - 5/6/2019 =
* Improved login redirect method to be better compatible with other plugins
* Added login counting
* Added login count redirect / tagging rules

= 0.5 - 3/17/2019 =
* Added last_login field to be available for syncing
* PilotPress compatibility fixes

= 0.4 - 12/19/2018 =
* Made redirects more aggressive to prevent being overruled by other plugins
* Fix for redirects to a protected page ignoring current user's tags

= 0.3 - 10/13/2018 =
* Compatibility fixes with Ultimate Member
* Made public class publicly accessible

= 0.2 - 6/12/2018 =
* Fix for incorrect update notices

= 0.1 - 6/9/2018 =
* Initial release

= 1636983106-1023 =