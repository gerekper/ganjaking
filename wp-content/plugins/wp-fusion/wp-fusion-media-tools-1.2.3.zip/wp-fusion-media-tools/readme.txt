=== WP Fusion - Media Tools Addon ===
Contributors: verygoodplugins
Tags: wp fusion, video, audio, youtube, embed, crm, vimeo, wistia, vooplayer, presto player
Requires at least: 4.6
Tested up to: 5.7.1
Stable tag: 1.2.3

Enables tracking user engagement with embedded videos and audio by applying tags in your CRM based on certain triggers.

== Description ==

Enables tracking user engagement with embedded videos and audio by applying tags in your CRM based on certain triggers.

== Changelog ==

= 1.2.3 - 4/20/2021 =
* Added option to enqueue tracking scripts on every page

= 1.2.2 - 4/19/2021 =
* Improved - If the YouTube player is time seeked, multiple timecode tags will be combined into a single AJAX request
* Fixed "Cannot read property 'addAction' of undefined" JavaScript error

= 1.2.1 - 4/7/2021 =
* Presto player bugfixes

= 1.2 - 4/5/2021 =
* Added Presto Player integration
* Additional compatibility fixes for Elementor 3.1.0+

= 1.1.3 - 3/2/2021 =
* Added compatibility warning with Borlabs Cookie Opt-In
* Fixed YouTube player not applying tags in Elementor 3.1.0+

= 1.1.2 - 10/27/2020 =
* Added 350ms delay before initializing iFrames to get around FitVids.js in BuddyBoss Theme

= 1.1.1 - 6/30/2020 =
* Added percentage based tracking for Vimeo
* Wistia tracking bugfixes

= 1.1 - 3/29/2020 =
* Added multiple timecodes support to Elementor
* Added support for Memberoni course videos
* Fix for start tags not applying when an Elementor video overlay image is used

= 1.0.1 - 8/5/2019 =
* Fix for tags not applying with multiple YouTube players on a page

= 1.0 - 2/28/2019 =
* VooPlayer timecode tracking bugfixes

= 0.9 - 1/29/2019 =
* Elementor bugfixes

= 0.8 - 1/22/2019 =
* Elementor support

= 0.7 - 1/6/2019 =
* Fix for settings sometimes not saving in admin

= 0.6 - 9/28/2018 =
* Added VooPlayer support

= 0.5 - 3/15/2018 =
* Added Wistia player support

= 0.4 - 8/29/2017  =
* Updates for WPF v3.3
* Added support for multiple timecodes via shortcode

= 0.3 - 12/28/2016 =
* Added YouTube player support

= 0.2 - 8/23/2018 =
* Added Vimeo player support

= 0.1 - 7/14/2016 =
* Initial release

= 1636983104-1023 =