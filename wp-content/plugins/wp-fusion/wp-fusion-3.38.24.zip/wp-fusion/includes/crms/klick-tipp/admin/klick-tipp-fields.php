<?php

$klicktipp_fields = array();

$klicktipp_fields['first_name'] = array(
	'crm_label' => 'First Name',
	'crm_field' => 'fieldFirstName'
);

$klicktipp_fields['last_name'] = array(
	'crm_label' => 'Last Name',
	'crm_field' => 'fieldLastName'
);

$klicktipp_fields['user_email'] = array(
	'crm_label' => 'Email',
	'crm_field' => 'email'
);

$klicktipp_fields['phone_number'] = array(
	'crm_label' => 'Phone',
	'crm_field' => 'fieldPhone'
);