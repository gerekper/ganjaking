<?php

$birdsend_fields = array();

$birdsend_fields['first_name'] = array(
	'crm_field' => 'first_name',
	'crm_label' => 'First Name',
);

$birdsend_fields['last_name'] = array(
	'crm_field' => 'last_name',
	'crm_label' => 'Last Name',
);

$birdsend_fields['user_email'] = array(
	'crm_field' => 'email',
	'crm_label' => 'Email',
);
