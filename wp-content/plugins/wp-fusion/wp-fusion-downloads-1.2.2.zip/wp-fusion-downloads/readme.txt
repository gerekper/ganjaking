=== WP Fusion - Downloads Addon ===
Contributors: verygoodplugins
Tags: wp fusion, file protection
Requires at least: 4.0
Tested up to: 5.4.2
Stable tag: 1.2.1

Protects media library items using a user's CRM tags

== Description ==
Protects media library items using a user's CRM tags

== Installation ==
Requires WP Fusion to be installed first.
	
= 1.2.2 - 7/28/2020 =
* Fixed crash if activated for WP Fusion Lite
* 404 will now get the theme's 404 template (thanks @Erik)
* Made .htaccess warning dismissable

= 1.2.1 - 4/28/2020 =
* Fixed updater

= 1.2 - 4/27/2020 =
* Improved support for NGINX servers 

= 1.1.2 - 1/23/2020 =
* Fixed crash if WP Fusion wasn't active

= 1.1.1 - 12/27/2019 =
* Fixed rewrite rules not being set on first install
* Admin style fixes

= 1.1 - 10/14/2019 =
* Added option to redirect when a restricted file is accessed
* Improved editing settings via single attachment page

= 1.0.1 - 9/12/2019 =
* Moved data storage
* Requests with wp-admin referrer will bypass .htaccess rule
* Cosmetic improvements

= 1.0 - 8/30/2019 =
* Initial release