###NGINX notes
1. Locate your main uploads directory, i.e. wp-content/uploads
2.Find and open nginx config file of your WordPress website which is usually located at 
**/etc/nginx/site-available or /etc/nginx/conf/site-available**

3. Edit config file:

server {

    location / {
     ...
    }

   **Add WPFD rewrite rules here, i.e.**
   
   **rewrite wp-content/uploads(/_wpfd/.*\.\w+)$ "/index.php?wpfd=$1" last;**
}