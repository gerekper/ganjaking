jQuery(document).ready(function($){

	if (wp.media) {

		wp.media.view.Modal.prototype.on( 'open', function() {

			wp.media.frame.on('all', function(e) {

				//console.log('event ' + e);

			});

			wp.media.frame.on('selection:toggle', function(e) {

				initializeTagsSelect( '.compat-field-wpf_required_tags' );

				$('input.wpfd-switch-input').change(function(event) {
					
					if( $(this).is(':checked') ) {

						$(this).closest('.compat-attachment-fields').find('select.select4-wpf-tags').removeProp('disabled');

					} else {

						$(this).closest('.compat-attachment-fields').find('select.select4-wpf-tags').addProp('disabled');

					}

				});

				// After settings have been saved

				wp.media.frame.on('attachment:compat:ready', function(e) {

					initializeTagsSelect( '.compat-field-wpf_required_tags' );

				});

			});

        });

	}


	if( $('body').hasClass( 'post-type-attachment' ) ) {

		$('input.wpfd-switch-input').change(function(event) {
			
			if( $(this).is(':checked') ) {

				$(this).closest('.compat-attachment-fields').find('select.select4-wpf-tags').removeProp('disabled');

			} else {

				$(this).closest('.compat-attachment-fields').find('select.select4-wpf-tags').addProp('disabled');

			}

		});

	}

});