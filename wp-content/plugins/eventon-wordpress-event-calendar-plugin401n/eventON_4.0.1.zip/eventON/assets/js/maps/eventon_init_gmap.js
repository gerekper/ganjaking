/*
	INITIATE google gmaps on web page
	version: 0.2
*/

	
var geocoder;
var test =3;

function getGeocoder(){
	return geocoder;
}

function initialize() {	
}