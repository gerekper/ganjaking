<?php declare(strict_types = 1);

namespace MailPoet\Premium\Automation\Integrations\WooCommerceSubscriptions;

if (!defined('ABSPATH')) exit;


use MailPoet\Automation\Engine\Integration;
use MailPoet\Automation\Engine\Registry;
use MailPoet\Premium\Automation\Integrations\WooCommerceSubscriptions\Subjects\WooCommerceSubscriptionStatusChangeSubject;
use MailPoet\Premium\Automation\Integrations\WooCommerceSubscriptions\Subjects\WooCommerceSubscriptionSubject;
use MailPoet\Premium\Automation\Integrations\WooCommerceSubscriptions\Triggers\SubscriptionCreatedTrigger;
use MailPoet\Premium\Automation\Integrations\WooCommerceSubscriptions\Triggers\SubscriptionStatusChangedTrigger;

class WooCommerceSubscriptionsIntegration implements Integration {


  /** @var ContextFactory */
  private $contextFactory;

  /** @var SubscriptionCreatedTrigger */
  private $subscriptionCreatedTrigger;

  /** @var SubscriptionStatusChangedTrigger */
  private $subscriptionStatusChangedTrigger;

  /** @var WooCommerceSubscriptionSubject */
  private $wooCommerceSubscriptionSubject;

  /** @var WooCommerceSubscriptionStatusChangeSubject */
  private $wooCommerceSubscriptionStatusChangeSubject;

  public function __construct(
    ContextFactory $contextFactory,
    SubscriptionCreatedTrigger $subscriptionCreatedTrigger,
    SubscriptionStatusChangedTrigger $subscriptionStatusChangedTrigger,
    WooCommerceSubscriptionSubject $wooCommerceSubscriptionSubject,
    WooCommerceSubscriptionStatusChangeSubject $wooCommerceSubscriptionStatusChangeSubject
  ) {
    $this->contextFactory = $contextFactory;
    $this->subscriptionCreatedTrigger = $subscriptionCreatedTrigger;
    $this->subscriptionStatusChangedTrigger = $subscriptionStatusChangedTrigger;
    $this->wooCommerceSubscriptionSubject = $wooCommerceSubscriptionSubject;
    $this->wooCommerceSubscriptionStatusChangeSubject = $wooCommerceSubscriptionStatusChangeSubject;
  }

  public function register(Registry $registry): void {
    $registry->addContextFactory('woocommerce-subscriptions', function () {
      return $this->contextFactory->getContextData();
    });

    $registry->addTrigger($this->subscriptionCreatedTrigger);
    $registry->addTrigger($this->subscriptionStatusChangedTrigger);
    $registry->addSubject($this->wooCommerceSubscriptionSubject);
    $registry->addSubject($this->wooCommerceSubscriptionStatusChangeSubject);
  }
}
