<?php


if(!defined('ABSPATH')) {exit;}

//if(!class_exists('class-upml-ajax')) :

//class upml-ajax {
	
	
//	public function __construct() {
            
  //      }
//}

