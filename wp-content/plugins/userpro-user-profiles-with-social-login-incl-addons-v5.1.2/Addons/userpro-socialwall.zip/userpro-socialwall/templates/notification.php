<div class="userpro-notifier userpro-notifier-r">

	<a href="#" class="social-notify-link userpro-social-notify" data-user_id="<?php echo $user_id; ?>">
		<span class="count"><i class="userpro-icon-comment"></i><?php echo comment_notifiction_count($user_id); ?></span>
	</a>

</div>
