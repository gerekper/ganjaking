<form method="post" action="">



<h3><?php _e('Purchase code','userpro'); ?></h3>
<table class="form-table">
<tr valign="top">
		<th scope="row"><label for="userpro_userwall_envato_code"><?php _e('Envato Purchase code','userpro-userwall'); ?></label></th>
		<td>
			<input type="text" style="width:300px !important;" name="userpro_userwall_envato_code" id="userpro_userwall_envato_code" readonly="readonly" value="13z89fdcmr2ia646kphzg3bbz0jdpdja" class="regular-text" />
		</td>
</tr>
</table>
</form>
