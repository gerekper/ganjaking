<?php

// Exit if accessed directly
defined('ABSPATH') || exit;

/**
 * RightPress Settings Exception Class
 *
 * @class RightPress_Settings_Exception
 * @package RightPress
 * @author RightPress
 */
class RightPress_Settings_Exception extends RightPress_Exception
{



}
