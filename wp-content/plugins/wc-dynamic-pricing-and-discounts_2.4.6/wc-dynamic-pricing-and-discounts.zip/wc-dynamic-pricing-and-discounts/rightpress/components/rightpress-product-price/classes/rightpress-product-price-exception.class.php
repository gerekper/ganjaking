<?php

// Exit if accessed directly
defined('ABSPATH') || exit;

/**
 * RightPress Product Price Exception Class
 *
 * @class RightPress_Product_Price_Exception
 * @package RightPress
 * @author RightPress
 */
class RightPress_Product_Price_Exception extends RightPress_Exception
{



}
