<?php // phpcs:ignore Internal.NoCodeFound ?>
{{schema name="yoast/cooking-time" only-nested=true }}
{{attribute name="cooking-time-iso8601-duration" }}
