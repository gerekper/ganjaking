<?php

// phpcs:disable Yoast.NamingConventions.ObjectNameDepth.MaxExceeded -- Discussed in Tech Council, a better solution is being worked on.

namespace Yoast\WP\SEO\Exceptions\Addon_Installation;

/**
 * Class User_Cannot_Install_Plugins_Exception
 */
class User_Cannot_Install_Plugins_Exception extends \Exception {}
