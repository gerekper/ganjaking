<?php
/**
 * The template for displaying the end of the local mode
 *
 * This template can be overridden by copying it to yourtheme/tm-extra-product-options/tm-start.php
 *
 * NOTE that we may need to update template files and you
 * (the plugin or theme developer) will need to copy the new files
 * to your theme or plugin to maintain compatibility.
 *
 * @author  themeComplete
 * @package WooCommerce Extra Product Options/Templates
 * @version 4.0
 */

defined( 'ABSPATH' ) || exit;
?>
</ul>
</div>
</div>