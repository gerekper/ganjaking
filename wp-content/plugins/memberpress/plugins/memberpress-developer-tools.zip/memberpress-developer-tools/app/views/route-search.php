<?php if(!defined('ABSPATH')) {die('You are not allowed to call this page directly.');} ?>
<?php /** This is a template to be used on the javascript side */ ?>

<div class="mepr-sub-box-white">
  <h3>{{field}}</h3>
  <p class="mpdt_route_input_type">{{type}}{{default}}</p>
  <p>{{description}}</p>
</div>
<div>&nbsp;</div>

