<?php if(!defined('ABSPATH')) {die('You are not allowed to call this page directly.');} ?>

<div class="mepr-page-title"><?php _e('Resources', 'memberpress-developer-tools'); ?></div>
<p><?php _e('Additional MemberPress Development Resources', 'memberpress-developer-tools'); ?></p>

<h3><?php _e('Shortcodes', 'memberpress-developer-tools'); ?></h3>
<div>
  <a href="https://www.memberpress.com/user-manual/available-shortcodes/">https://www.memberpress.com/user-manual/available-shortcodes/</a>
</div>

