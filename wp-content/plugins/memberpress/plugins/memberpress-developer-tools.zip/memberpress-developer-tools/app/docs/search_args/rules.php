<?php if(!defined('ABSPATH')) {die('You are not allowed to call this page directly.');}

// The format of this array is determined by WP-API
return array(
  // TODO: We'll get to this eventually
  //'membership' => array(
  //  'description'        => __('Limit results to rules that protect a specific membership.'),
  //  'type'               => 'integer',
  //  'sanitize_callback'  => 'absint',
  //),
);

