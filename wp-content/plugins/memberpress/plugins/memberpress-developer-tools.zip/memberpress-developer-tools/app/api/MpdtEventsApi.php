<?php
if(!defined('ABSPATH')) {die('You are not allowed to call this page directly.');}

class MpdtEventsApi extends MpdtBaseApi { }

