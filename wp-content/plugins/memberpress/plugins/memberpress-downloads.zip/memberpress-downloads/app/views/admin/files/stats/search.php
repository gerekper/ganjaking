<?php foreach( $files as $file ) : ?>
   <?php echo $file->post_title, "\n"; ?>
<?php endforeach; ?>