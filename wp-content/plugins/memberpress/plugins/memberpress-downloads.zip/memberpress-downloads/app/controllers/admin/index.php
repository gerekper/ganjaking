<?php /* Silence will fall. */ ?>
