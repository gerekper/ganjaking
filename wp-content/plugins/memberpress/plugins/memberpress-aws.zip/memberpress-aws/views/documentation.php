<br/><br/>
<?php _e('AWS S3 URL Shortcode:', 'memberpress-aws'); ?>
<strong>[aws-s3-url rule="<?php echo $rule->ID; ?>" src="whudup/cool.zip" expires="+30 seconds" /]</strong>
<br/><br/>
<?php _e('AWS S3 Link Shortcode:', 'memberpress-aws'); ?>
<strong>[aws-s3-link rule="<?php echo $rule->ID; ?>" src="whudup/cool.zip" expires="+5 days"]</strong><?php _e('Link text goes here...', 'memberpress-aws'); ?><strong>[/aws-s3-link]</strong>
<br/><br/>
<?php _e('AWS S3 Audio Shortcode:', 'memberpress-aws'); ?>
<strong>[aws-s3-audio rule="<?php echo $rule->ID; ?>" src="whudup/cool.mp4" expires="+1 minute" /]</strong>
<br/><br/>
<?php _e('AWS S3 Video Shortcode:', 'memberpress-aws'); ?>
<strong>[aws-s3-video rule="<?php echo $rule->ID; ?>" src="whudup/cool.mp4" expires="+1 minute" /]</strong>
<br/><br/>
<?php _e('AWS S3 Video Shortcode:', 'memberpress-aws'); ?>
<strong>[aws-s3-video rule="<?php echo $rule->ID; ?>" mp4="whudup/cool.mp4" webm="whudup/cool.mp4" expires="+1 minute" /]</strong>
<br/><br/>
