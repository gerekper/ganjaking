<?php if(!defined('ABSPATH')) { die('You are not allowed to call this page directly.'); } ?>

<div class="wrap sort-scroll-container">
  <div id="curriculum-builder" class="">
  </div>
</div>
