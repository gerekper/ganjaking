<?php if(!defined('ABSPATH')) { die('You are not allowed to call this page directly.'); } ?>

<div class="wrap sort-scroll-container">
  <div id="mpcs-certificates-settings" class="">
  </div>
</div>
