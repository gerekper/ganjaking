<?php
if (isset($_COOKIE['rsreferredusername'])) {
                /*
                 * Update the Referred Person Registration Count
                 */
                
                $user_info = new WP_User($user_id);
                $registered_date = $user_info->user_registered;
                $limitation = false;
                $modified_registered_date = date('Y-m-d h:i:sa', strtotime($registered_date));
                $delay_days = get_option('_rs_select_referral_points_referee_time_content');
                $checking_date = date('Y-m-d h:i:sa', strtotime($modified_registered_date . ' + ' . $delay_days . ' days '));
                $modified_checking_date = strtotime($checking_date);
                $current_date = date('Y-m-d h:i:sa');
                $modified_current_date = strtotime($current_date);
                //Is for Immediatly
                if (get_option('_rs_select_referral_points_referee_time') == '1') {
                    $limitation = true;
                } else {
                    // Is for Limited Time with Number of Days
                    if ($modified_current_date > $modified_checking_date) {
                        $limitation = true;
                    } else {
                        $limitation = false;
                    }
                }
                if ($limitation == true) {
                    $referreduser = get_user_by('login', $_COOKIE['rsreferredusername']);
                    if ($referreduser != false) {
                        $refuserid = $referreduser->ID;
                    } else {
                        $refuserid = $_COOKIE['rsreferredusername'];
                    }
//                        $banned_user_list = get_option('rs_banned-users_list');
//                        if (!in_array($refuserid, (array) $banned_user_list)) {
//                            $getarrayofuserdata = get_userdata($refuserid);
//                            $banninguserrole = get_option('rs_banning_user_role');
//                            if (!in_array(isset($getarrayofuserdata->roles[0]) ? $getarrayofuserdata->roles[0] : '0', (array) $banninguserrole)) {
                    //$userid = get_current_user_id();
                    $banning_type = FPRewardSystem::check_banning_type($refuserid);
                    if ($banning_type != 'earningonly' && $banning_type != 'both') {
                        $getregisteredcount = get_user_meta($refuserid, 'rsreferreduserregisteredcount', true);
                        $currentregistration = $getregisteredcount + 1;
                        update_user_meta($refuserid, 'rsreferreduserregisteredcount', $currentregistration);
                        /*
                         * Update the Referred Person Registration Count End
                         */
                        $oldpointss = get_user_meta($refuserid, '_my_reward_points', true);
                        $referral_registration_points = get_option('rs_referral_reward_signup');
                        $referral_registration_points = RSUserRoleRewardPoints::user_role_based_reward_points($refuserid, $referral_registration_points);
                        $previouslog = get_option('rs_referral_log');
                        RS_Referral_Log::main_referral_log_function($refuserid, $user_id, $referral_registration_points, array_filter((array) $previouslog));
                        FPRewardSystem::save_total_earned_points($refuserid, $referral_registration_points);
                        $currentregistrationpointss = $oldpointss + $referral_registration_points;
                        if ($enabledisablepoints == '1') {
                            if (($currentregistrationpointss <= $restrictuserpoints) || ($restrictuserpoints == '')) {
                                $currentregistrationpointss = $currentregistrationpointss;
                            } else {
                                $currentregistrationpointss = $restrictuserpoints;
                            }
                        }



                        update_user_meta($refuserid, '_my_reward_points', $currentregistrationpointss);


                        $referralregisteredusermessage = get_option('_rs_localize_points_earned_for_referral_registration');
                        $fromreferralregistereduser = array('{registereduser}');
                        $toreferralregistereduser = array(get_user_meta($user_id, 'nickname', true));
                        $updatedreferralregistereduser = str_replace($fromreferralregistereduser, $toreferralregistereduser, $referralregisteredusermessage);


                        $myrewards = get_user_meta($refuserid, '_my_reward_points', true);
                        $pointslogs[] = array('orderid' => '', 'userid' => $refuserid, 'points_earned_order' => $referral_registration_points, 'points_redeemed' => '', 'points_value' => '', 'before_order_points' => '', 'totalpoints' => $myrewards, 'date' => date('Y-m-d H:i:s'), 'rewarder_for' => $updatedreferralregistereduser, 'rewarder_for_frontend' => $updatedreferralregistereduser);
                        $overalllogs[] = array('userid' => $refuserid, 'totalvalue' => $myrewards, 'eventname' => $updatedreferralregistereduser, 'date' => date('Y-m-d H:i:s'));
                        $getoveralllogs = get_option('rsoveralllog');
                        $logmerges = array_merge((array) $getoveralllogs, $overalllogs);
                        update_option('rsoveralllog', $logmerges);
                        $getmypointss = get_user_meta($refuserid, '_my_points_log', true);
                        $mergeds = array_merge((array) $getmypointss, $pointslogs);
                        update_user_meta($refuserid, '_my_points_log', $mergeds);
                        update_user_meta($user_id, '_rs_i_referred_by', $refuserid);
//                            }
//                        }
                    }
                }
            }