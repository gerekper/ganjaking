<?php

    if (get_option('rs_set_price_percentage_reward_points') == '1') {
                            $getregularprice = get_post_meta($item['product_id'], '_regular_price', true);
                        } else {
                            $getregularprice = get_post_meta($item['product_id'], '_price', true);
                        }

                        do_action_ref_array('rs_update_points_for_referral_simple', array(&$getregularprice, &$item));

                        $getpercent = get_post_meta($item['product_id'], '_rewardsystempercent', true);

                        $item['qty'];
                        $order->user_id;
                        $item['product_id'];
                        $referreduser = get_post_meta($order_id, '_referrer_name', true);
                        if ($referreduser != '') {
                            include_once 'rs_update_referral_points.php';
                        } else {
                            $referrer_id = FPRewardSystemManualLinking::rs_perform_manual_link_referer($order->user_id);
                            if ($referrer_id != false) {
                                include_once 'rs_update_manuall_referral_points.php';
                            }
                        }

                        if (get_post_meta($item['product_id'], '_rewardsystemcheckboxvalue', true) == 'yes') {

                            if (get_post_meta($item['product_id'], '_rewardsystem_options', true) == '1') {
                                $getpoints = get_post_meta($item['product_id'], '_rewardsystempoints', true);
                                if ($getpoints == '') {
                                    $term = get_the_terms($item['product_id'], 'product_cat');
// var_dump($term);
                                    if (is_array($term)) {
//var_dump($term);
                                        $rewardpoints = array('0');
                                        foreach ($term as $term) {

                                            $enablevalue = get_woocommerce_term_meta($term->term_id, 'enable_reward_system_category', true);
                                            $display_type = get_woocommerce_term_meta($term->term_id, 'enable_rs_rule', true);
//                                            echo $rewardpoints = get_woocommerce_term_meta($term->term_id, 'rs_category_points', true) . "<br>";
//                                            echo $rewardpercent = get_woocommerce_term_meta($term->term_id, 'rs_category_percent', true) . "<br>";
                                            if (($enablevalue == 'yes') && ($enablevalue != '')) {
                                                if ($display_type == '1') {
                                                    if (get_woocommerce_term_meta($term->term_id, 'rs_category_points', true) == '') {
                                                        $global_enable = get_option('rs_global_enable_disable_reward');
                                                        $global_reward_type = get_option('rs_global_reward_type');
                                                        if ($global_enable == '1') {
                                                            if ($global_reward_type == '1') {
                                                                $rewardpoints[] = get_option('rs_global_reward_points');
                                                            } else {
                                                                $pointconversion = get_option('rs_earn_point');
                                                                $pointconversionvalue = get_option('rs_earn_point_value');
                                                                $getaverage = get_option('rs_global_reward_percent') / 100;
                                                                $getaveragepoints = $getaverage * $getregularprice;
                                                                $pointswithvalue = $getaveragepoints * $pointconversion;
                                                                $rewardpoints[] = $pointswithvalue / $pointconversionvalue;
                                                            }
                                                        }
                                                    } else {
                                                        $rewardpoints[] = get_woocommerce_term_meta($term->term_id, 'rs_category_points', true);
                                                    }
                                                } else {
                                                    $pointconversion = get_option('rs_earn_point');
                                                    $pointconversionvalue = get_option('rs_earn_point_value');
                                                    $getaverage = get_woocommerce_term_meta($term->term_id, 'rs_category_percent', true) / 100;
                                                    $getaveragepoints = $getaverage * $getregularprice;
                                                    $pointswithvalue = $getaveragepoints * $pointconversion;
                                                    if (get_woocommerce_term_meta($term->term_id, 'rs_category_percent', true) == '') {
                                                        $global_enable = get_option('rs_global_enable_disable_reward');
                                                        $global_reward_type = get_option('rs_global_reward_type');
                                                        if ($global_enable == '1') {
                                                            if ($global_reward_type == '1') {
                                                                $rewardpoints[] = get_option('rs_global_reward_points');
                                                            } else {
                                                                $pointconversion = get_option('rs_earn_point');
                                                                $pointconversionvalue = get_option('rs_earn_point_value');
                                                                $getaverage = get_option('rs_global_reward_percent') / 100;
                                                                $getaveragepoints = $getaverage * $getregularprice;
                                                                $pointswithvalue = $getaveragepoints * $pointconversion;
                                                                $rewardpoints[] = $pointswithvalue / $pointconversionvalue;
                                                            }
                                                        }
                                                    } else {
                                                        $rewardpoints[] = $pointswithvalue / $pointconversionvalue;
                                                    }
                                                }
                                            } else {
                                                if ($global_enable == '1') {
                                                    if ($global_reward_type == '1') {
                                                        $rewardpoints[] = get_option('rs_global_reward_points');
                                                    } else {
                                                        $pointconversion = get_option('rs_earn_point');
                                                        $pointconversionvalue = get_option('rs_earn_point_value');
                                                        $getaverage = get_option('rs_global_reward_percent') / 100;
                                                        $getaveragepoints = $getaverage * $getregularprice;
                                                        $pointswithvalue = $getaveragepoints * $pointconversion;
                                                        $rewardpoints[] = $pointswithvalue / $pointconversionvalue;
                                                    }
                                                }
                                            }
                                        }
                                    } else {
                                        if ($global_enable == '1') {
                                            if ($global_reward_type == '1') {
                                                $rewardpoints[] = get_option('rs_global_reward_points');
                                            } else {
                                                $pointconversion = get_option('rs_earn_point');
                                                $pointconversionvalue = get_option('rs_earn_point_value');
                                                $getaverage = get_option('rs_global_reward_percent') / 100;
                                                $getaveragepoints = $getaverage * $getregularprice;
                                                $pointswithvalue = $getaveragepoints * $pointconversion;
                                                $rewardpoints[] = $pointswithvalue / $pointconversionvalue;
                                            }
                                        }
                                    }
//var_dump($rewardpoints);
                                    $getpoints = max($rewardpoints);

//$rewardpoints = array_search($value, $rewardpoints);
                                }

                                $pointsearnedforpurchaselog = get_option('_rs_localize_product_purchase_reward_points');
                                $tofindarrayslog = array('{itemproductid}', '{currentorderid}');
                                $toreplacearrayslog = array($item['product_id'], $order_id);
                                $toupdatedvaluesarrays = str_replace($tofindarrayslog, $toreplacearrayslog, $pointsearnedforpurchaselog);
                                $rs_totalearnedpoints[$item['product_id']] = $getpoints * $item['qty'];



                                $getpointsmulti = RSUserRoleRewardPoints::user_role_based_reward_points($order->user_id, $getpoints) * $item['qty'];
                                FPRewardSystem::save_total_earned_points($order->user_id, $getpointsmulti);
                                if($order->user_id != ''){
                                $overalllog[] = array('userid' => $order->user_id, 'totalvalue' => $getpointsmulti, 'eventname' => $toupdatedvaluesarrays, 'date' => $order->order_date);
                                $getoveralllog = get_option('rsoveralllog');
                                $logmerge = array_merge((array) $getoveralllog, $overalllog);
                                //update_option('rsoveralllog', $logmerge);
                                }
                                $userpoints = get_user_meta($order->user_id, '_my_reward_points', true);
                                $newgetpoints = $getpointsmulti + $userpoints;
                                if ($enabledisablemaxpoints == 'yes') {
                                    if (($newgetpoints <= $restrictuserpoints) || ($restrictuserpoints == '')) {
                                        $newgetpoints = $newgetpoints;
                                    } else {
                                        $newgetpoints = $restrictuserpoints;
                                    }
                                }
                                update_user_meta($order->user_id, '_my_reward_points', $newgetpoints);
                            } else {
                                $points = get_option('rs_earn_point');
                                $pointsequalto = get_option('rs_earn_point_value');
                                $getpercent = get_post_meta($item['product_id'], '_rewardsystempercent', true);
                                if (get_option('rs_set_price_percentage_reward_points') == '1') {
                                    $getregularprice = get_post_meta($item['product_id'], '_regular_price', true);
                                } else {
                                    $getregularprice = get_post_meta($item['product_id'], '_price', true);
                                }

                                do_action_ref_array('rs_update_points_for_simple', array(&$getregularprice, &$item));

                                $percentageproduct = $getpercent / 100;
                                $getpricepercent = $percentageproduct * $getregularprice;
                                $getpointconvert = $getpricepercent * $points;
                                $getexactpoint = $getpointconvert / $pointsequalto;

                                if ($getpercent == '') {
                                    $term = get_the_terms($item['product_id'], 'product_cat');
// var_dump($term);
                                    if (is_array($term)) {
//var_dump($term);
                                        $rewardpoints = array('0');
                                        foreach ($term as $term) {

                                            $enablevalue = get_woocommerce_term_meta($term->term_id, 'enable_reward_system_category', true);
                                            $display_type = get_woocommerce_term_meta($term->term_id, 'enable_rs_rule', true);
//                                            echo $rewardpoints = get_woocommerce_term_meta($term->term_id, 'rs_category_points', true) . "<br>";
//                                            echo $rewardpercent = get_woocommerce_term_meta($term->term_id, 'rs_category_percent', true) . "<br>";
                                            if (($enablevalue == 'yes') && ($enablevalue != '')) {
                                                if ($display_type == '1') {
                                                    if (get_woocommerce_term_meta($term->term_id, 'rs_category_points', true) == '') {
                                                        $global_enable = get_option('rs_global_enable_disable_reward');
                                                        $global_reward_type = get_option('rs_global_reward_type');
                                                        if ($global_enable == '1') {
                                                            if ($global_reward_type == '1') {
                                                                $rewardpoints[] = get_option('rs_global_reward_points');
                                                            } else {
                                                                $pointconversion = get_option('rs_earn_point');
                                                                $pointconversionvalue = get_option('rs_earn_point_value');
                                                                $getaverage = get_option('rs_global_reward_percent') / 100;
                                                                $getaveragepoints = $getaverage * $getregularprice;
                                                                $pointswithvalue = $getaveragepoints * $pointconversion;
                                                                $rewardpoints[] = $pointswithvalue / $pointconversionvalue;
                                                            }
                                                        }
                                                    } else {
                                                        $rewardpoints[] = get_woocommerce_term_meta($term->term_id, 'rs_category_points', true);
                                                    }
                                                } else {
                                                    $pointconversion = get_option('rs_earn_point');
                                                    $pointconversionvalue = get_option('rs_earn_point_value');
                                                    $getaverage = get_woocommerce_term_meta($term->term_id, 'rs_category_percent', true) / 100;
                                                    $getaveragepoints = $getaverage * $getregularprice;
                                                    $pointswithvalue = $getaveragepoints * $pointconversion;
                                                    if (get_woocommerce_term_meta($term->term_id, 'rs_category_percent', true) == '') {
                                                        $global_enable = get_option('rs_global_enable_disable_reward');
                                                        $global_reward_type = get_option('rs_global_reward_type');
                                                        if ($global_enable == '1') {
                                                            if ($global_reward_type == '1') {
                                                                $rewardpoints[] = get_option('rs_global_reward_points');
                                                            } else {
                                                                $pointconversion = get_option('rs_earn_point');
                                                                $pointconversionvalue = get_option('rs_earn_point_value');
                                                                $getaverage = get_option('rs_global_reward_percent') / 100;
                                                                $getaveragepoints = $getaverage * $getregularprice;
                                                                $pointswithvalue = $getaveragepoints * $pointconversion;
                                                                $rewardpoints[] = $pointswithvalue / $pointconversionvalue;
                                                            }
                                                        }
                                                    } else {
                                                        $rewardpoints[] = $pointswithvalue / $pointconversionvalue;
                                                    }
                                                }
                                            } else {
                                                if ($global_enable == '1') {
                                                    if ($global_reward_type == '1') {
                                                        $rewardpoints[] = get_option('rs_global_reward_points');
                                                    } else {
                                                        $pointconversion = get_option('rs_earn_point');
                                                        $pointconversionvalue = get_option('rs_earn_point_value');
                                                        $getaverage = get_option('rs_global_reward_percent') / 100;
                                                        $getaveragepoints = $getaverage * $getregularprice;
                                                        $pointswithvalue = $getaveragepoints * $pointconversion;
                                                        $rewardpoints[] = $pointswithvalue / $pointconversionvalue;
                                                    }
                                                }
                                            }
                                        }
                                    } else {
                                        if ($global_enable == '1') {
                                            if ($global_reward_type == '1') {
                                                $rewardpoints[] = get_option('rs_global_reward_points');
                                            } else {
                                                $pointconversion = get_option('rs_earn_point');
                                                $pointconversionvalue = get_option('rs_earn_point_value');
                                                $getaverage = get_option('rs_global_reward_percent') / 100;
                                                $getaveragepoints = $getaverage * $getregularprice;
                                                $pointswithvalue = $getaveragepoints * $pointconversion;
                                                $rewardpoints[] = $pointswithvalue / $pointconversionvalue;
                                            }
                                        }
                                    }
//var_dump($rewardpoints);
                                    $getexactpoint = max($rewardpoints);

//$rewardpoints = array_search($value, $rewardpoints);
                                }

                                $pointsearnedforpurchaselog = get_option('_rs_localize_product_purchase_reward_points');
                                $tofindarrayslog = array('{itemproductid}', '{currentorderid}');
                                $toreplacearrayslog = array($item['product_id'], $order_id);
                                $toupdatedvaluesarrays = str_replace($tofindarrayslog, $toreplacearrayslog, $pointsearnedforpurchaselog);
                                $rs_totalearnedpoints[$item['product_id']] =  $getexactpoint * $item['qty'];
                                $getpointsmulti = RSUserRoleRewardPoints::user_role_based_reward_points($order->user_id, $getexactpoint) * $item['qty'];
                                FPRewardSystem::save_total_earned_points($order->user_id, $getpointsmulti);
                                if($order->user_id != ''){
                                $overalllog[] = array('userid' => $order->user_id, 'totalvalue' => $getpointsmulti, 'eventname' => $toupdatedvaluesarrays, 'date' => $order->order_date);
                                $getoveralllog = get_option('rsoveralllog');
                                $logmerge = array_merge((array) $getoveralllog, $overalllog);
                                //update_option('rsoveralllog', $logmerge);
                                }
                                $userpoints = get_user_meta($order->user_id, '_my_reward_points', true);
                                $updatedpoints = $getpointsmulti + $userpoints;
                                if ($enabledisablemaxpoints == 'yes') {
                                    if (($updatedpoints <= $restrictuserpoints) || ($restrictuserpoints == '')) {
                                        $updatedpoints = $updatedpoints;
                                    } else {
                                        $updatedpoints = $restrictuserpoints;
                                    }
                                }
                                update_user_meta($order->user_id, '_my_reward_points', $updatedpoints);
                            }
                        }
                        if (get_post_meta($item['variation_id'], '_enable_reward_points', true) == '1') {
                            $checkenablevariation = get_post_meta($item['variation_id'], '_enable_reward_points', true);
                            $variablerewardpoints = get_post_meta($item['variation_id'], '_reward_points', true);
                            $variationselectrule = get_post_meta($item['variation_id'], '_select_reward_rule', true);
                            $variationrewardpercent = get_post_meta($item['variation_id'], '_reward_percent', true);
                            $variable_product1 = new WC_Product_Variation($item['variation_id']);
#Step 4: You have the data. Have fun :)
                            if (get_option('rs_set_price_percentage_reward_points') == '1') {
                                $variationregularprice = $variable_product1->regular_price;
                            } else {
                                $variationregularprice = $variable_product1->price;
                            }

                            do_action_ref_array('rs_update_points_for_variable', array(&$variationregularprice, &$item));

                            if ($variationselectrule == '1') {
                                $getpoints = get_post_meta($item['variation_id'], '_reward_points', true);
                                $parentvariationid = new WC_Product_Variation($item['variation_id']);
                                $newparentid = $parentvariationid->parent->id;
                                if ($getpoints == '') {
                                    $term = get_the_terms($newparentid, 'product_cat');
//var_dump($term);
                                    if (is_array($term)) {
//var_dump($term);
                                        $rewardpoints = array('0');
                                        foreach ($term as $term) {

                                            $enablevalue = get_woocommerce_term_meta($term->term_id, 'enable_reward_system_category', true);
                                            $display_type = get_woocommerce_term_meta($term->term_id, 'enable_rs_rule', true);
//                                            echo $rewardpoints = get_woocommerce_term_meta($term->term_id, 'rs_category_points', true) . "<br>";
//                                            echo $rewardpercent = get_woocommerce_term_meta($term->term_id, 'rs_category_percent', true) . "<br>";
                                            if (($enablevalue == 'yes') && ($enablevalue != '')) {
                                                if ($display_type == '1') {
                                                    if (get_woocommerce_term_meta($term->term_id, 'rs_category_points', true) == '') {
                                                        $global_enable = get_option('rs_global_enable_disable_reward');
                                                        $global_reward_type = get_option('rs_global_reward_type');
                                                        if ($global_enable == '1') {
                                                            if ($global_reward_type == '1') {
                                                                $rewardpoints[] = get_option('rs_global_reward_points');
                                                            } else {
                                                                $pointconversion = get_option('rs_earn_point');
                                                                $pointconversionvalue = get_option('rs_earn_point_value');
                                                                $getaverage = get_option('rs_global_reward_percent') / 100;
                                                                $getaveragepoints = $getaverage * $variationregularprice;
                                                                $pointswithvalue = $getaveragepoints * $pointconversion;
                                                                $rewardpoints[] = $pointswithvalue / $pointconversionvalue;
                                                            }
                                                        }
                                                    } else {
                                                        $rewardpoints[] = get_woocommerce_term_meta($term->term_id, 'rs_category_points', true);
                                                    }
                                                } else {
                                                    $pointconversion = get_option('rs_earn_point');
                                                    $pointconversionvalue = get_option('rs_earn_point_value');
                                                    $getaverage = get_woocommerce_term_meta($term->term_id, 'rs_category_percent', true) / 100;
                                                    $getaveragepoints = $getaverage * $variationregularprice;
                                                    $pointswithvalue = $getaveragepoints * $pointconversion;
                                                    if (get_woocommerce_term_meta($term->term_id, 'rs_category_percent', true) == '') {
                                                        $global_enable = get_option('rs_global_enable_disable_reward');
                                                        $global_reward_type = get_option('rs_global_reward_type');
                                                        if ($global_enable == '1') {
                                                            if ($global_reward_type == '1') {
                                                                $rewardpoints[] = get_option('rs_global_reward_points');
                                                            } else {
                                                                $pointconversion = get_option('rs_earn_point');
                                                                $pointconversionvalue = get_option('rs_earn_point_value');
                                                                $getaverage = get_option('rs_global_reward_percent') / 100;
                                                                $getaveragepoints = $getaverage * $variationregularprice;
                                                                $pointswithvalue = $getaveragepoints * $pointconversion;
                                                                $rewardpoints[] = $pointswithvalue / $pointconversionvalue;
                                                            }
                                                        }
                                                    } else {
                                                        $rewardpoints[] = $pointswithvalue / $pointconversionvalue;
                                                    }
                                                }
                                            } else {
                                                if ($global_enable == '1') {
                                                    if ($global_reward_type == '1') {
                                                        $rewardpoints[] = get_option('rs_global_reward_points');
                                                    } else {
                                                        $pointconversion = get_option('rs_earn_point');
                                                        $pointconversionvalue = get_option('rs_earn_point_value');
                                                        $getaverage = get_option('rs_global_reward_percent') / 100;
                                                        $getaveragepoints = $getaverage * $variationregularprice;
                                                        $pointswithvalue = $getaveragepoints * $pointconversion;
                                                        $rewardpoints[] = $pointswithvalue / $pointconversionvalue;
                                                    }
                                                }
                                            }
                                        }
                                    } else {
                                        if ($global_enable == '1') {
                                            if ($global_reward_type == '1') {
                                                $rewardpoints[] = get_option('rs_global_reward_points');
                                            } else {
                                                $pointconversion = get_option('rs_earn_point');
                                                $pointconversionvalue = get_option('rs_earn_point_value');
                                                $getaverage = get_option('rs_global_reward_percent') / 100;
                                                $getaveragepoints = $getaverage * $variationregularprice;
                                                $pointswithvalue = $getaveragepoints * $pointconversion;
                                                $rewardpoints[] = $pointswithvalue / $pointconversionvalue;
                                            }
                                        }
                                    }
//var_dump($rewardpoints);
                                    $getpoints = max($rewardpoints);

//$rewardpoints = array_search($value, $rewardpoints);
                                }

                                $pointsearnedforpurchaselog = get_option('_rs_localize_product_purchase_reward_points');
                                $tofindarrayslog = array('{itemproductid}', '{currentorderid}');
                                $toreplacearrayslog = array($item['variation_id'], $order_id);
                                $toupdatedvaluesarrays = str_replace($tofindarrayslog, $toreplacearrayslog, $pointsearnedforpurchaselog);
                                $rs_totalearnedpoints[$item['variation_id']]=$getpoints * $item['qty'];

                                $getpointsmulti = RSUserRoleRewardPoints::user_role_based_reward_points($order->user_id, $getpoints) * $item['qty'];
                                FPRewardSystem::save_total_earned_points($order->user_id, $getpointsmulti);
                                if($order->user_id != ''){
                                $overalllog[] = array('userid' => $order->user_id, 'totalvalue' => $getpointsmulti, 'eventname' => $toupdatedvaluesarrays, 'date' => $order->order_date);
                                $getoveralllog = get_option('rsoveralllog');
                                $logmerge = array_merge((array) $getoveralllog, $overalllog);
                                //update_option('rsoveralllog', $logmerge);
                                }
                                $userpoints = get_user_meta($order->user_id, '_my_reward_points', true);
                                $newgetpoints = $getpointsmulti + $userpoints;
                                if ($enabledisablemaxpoints == 'yes') {
                                    if (($newgetpoints <= $restrictuserpoints) || ($restrictuserpoints == '')) {
                                        $newgetpoints = $newgetpoints;
                                    } else {
                                        $newgetpoints = $restrictuserpoints;
                                    }
                                }
                                update_user_meta($order->user_id, '_my_reward_points', $newgetpoints);
                            } else {
                                $pointconversion = get_option('rs_earn_point');
                                $pointconversionvalue = get_option('rs_earn_point_value');
                                $getaverage = $variationrewardpercent / 100;
                                $getaveragepoints = $getaverage * $variationregularprice;
                                $getpointsvalue = $getaveragepoints * $pointconversion;
                                $points = $getpointsvalue / $pointconversionvalue;

                                $parentvariationid = new WC_Product_Variation($item['variation_id']);
                                $newparentid = $parentvariationid->parent->id;
                                if ($variationrewardpercent == '') {
                                    $term = get_the_terms($newparentid, 'product_cat');
//var_dump($term);
                                    if (is_array($term)) {
//var_dump($term);
                                        $rewardpoints = array('0');
                                        foreach ($term as $term) {

                                            $enablevalue = get_woocommerce_term_meta($term->term_id, 'enable_reward_system_category', true);
                                            $display_type = get_woocommerce_term_meta($term->term_id, 'enable_rs_rule', true);
//                                            echo $rewardpoints = get_woocommerce_term_meta($term->term_id, 'rs_category_points', true) . "<br>";
//                                            echo $rewardpercent = get_woocommerce_term_meta($term->term_id, 'rs_category_percent', true) . "<br>";
                                            if (($enablevalue == 'yes') && ($enablevalue != '')) {
                                                if ($display_type == '1') {
                                                    if (get_woocommerce_term_meta($term->term_id, 'rs_category_points', true) == '') {
                                                        $global_enable = get_option('rs_global_enable_disable_reward');
                                                        $global_reward_type = get_option('rs_global_reward_type');
                                                        if ($global_enable == '1') {
                                                            if ($global_reward_type == '1') {
                                                                $rewardpoints[] = get_option('rs_global_reward_points');
                                                            } else {
                                                                $pointconversion = get_option('rs_earn_point');
                                                                $pointconversionvalue = get_option('rs_earn_point_value');
                                                                $getaverage = get_option('rs_global_reward_percent') / 100;
                                                                $getaveragepoints = $getaverage * $variationregularprice;
                                                                $pointswithvalue = $getaveragepoints * $pointconversion;
                                                                $rewardpoints[] = $pointswithvalue / $pointconversionvalue;
                                                            }
                                                        }
                                                    } else {
                                                        $rewardpoints[] = get_woocommerce_term_meta($term->term_id, 'rs_category_points', true);
                                                    }
                                                } else {
                                                    $pointconversion = get_option('rs_earn_point');
                                                    $pointconversionvalue = get_option('rs_earn_point_value');
                                                    $getaverage = get_woocommerce_term_meta($term->term_id, 'rs_category_percent', true) / 100;
                                                    $getaveragepoints = $getaverage * $variationregularprice;
                                                    $pointswithvalue = $getaveragepoints * $pointconversion;
                                                    if (get_woocommerce_term_meta($term->term_id, 'rs_category_percent', true) == '') {
                                                        $global_enable = get_option('rs_global_enable_disable_reward');
                                                        $global_reward_type = get_option('rs_global_reward_type');
                                                        if ($global_enable == '1') {
                                                            if ($global_reward_type == '1') {
                                                                $rewardpoints[] = get_option('rs_global_reward_points');
                                                            } else {
                                                                $pointconversion = get_option('rs_earn_point');
                                                                $pointconversionvalue = get_option('rs_earn_point_value');
                                                                $getaverage = get_option('rs_global_reward_percent') / 100;
                                                                $getaveragepoints = $getaverage * $variationregularprice;
                                                                $pointswithvalue = $getaveragepoints * $pointconversion;
                                                                $rewardpoints[] = $pointswithvalue / $pointconversionvalue;
                                                            }
                                                        }
                                                    } else {
                                                        $rewardpoints[] = $pointswithvalue / $pointconversionvalue;
                                                    }
                                                }
                                            } else {
                                                if ($global_enable == '1') {
                                                    if ($global_reward_type == '1') {
                                                        $rewardpoints[] = get_option('rs_global_reward_points');
                                                    } else {
                                                        $pointconversion = get_option('rs_earn_point');
                                                        $pointconversionvalue = get_option('rs_earn_point_value');
                                                        $getaverage = get_option('rs_global_reward_percent') / 100;
                                                        $getaveragepoints = $getaverage * $variationregularprice;
                                                        $pointswithvalue = $getaveragepoints * $pointconversion;
                                                        $rewardpoints[] = $pointswithvalue / $pointconversionvalue;
                                                    }
                                                }
                                            }
                                        }
                                    } else {
                                        if ($global_enable == '1') {
                                            if ($global_reward_type == '1') {
                                                $rewardpoints[] = get_option('rs_global_reward_points');
                                            } else {
                                                $pointconversion = get_option('rs_earn_point');
                                                $pointconversionvalue = get_option('rs_earn_point_value');
                                                $getaverage = get_option('rs_global_reward_percent') / 100;
                                                $getaveragepoints = $getaverage * $variationregularprice;
                                                $pointswithvalue = $getaveragepoints * $pointconversion;
                                                $rewardpoints[] = $pointswithvalue / $pointconversionvalue;
                                            }
                                        }
                                    }
//var_dump($rewardpoints);
                                    $points = max($rewardpoints);

//$rewardpoints = array_search($value, $rewardpoints);
                                }

                                $pointsearnedforpurchaselog = get_option('_rs_localize_product_purchase_reward_points');
                                $tofindarrayslog = array('{itemproductid}', '{currentorderid}');
                                $toreplacearrayslog = array($item['variation_id'], $order_id);
                                $toupdatedvaluesarrays = str_replace($tofindarrayslog, $toreplacearrayslog, $pointsearnedforpurchaselog);
                                $rs_totalearnedpoints[$item['variation_id']]= $points * $item['qty'];

                                $getpointsmulti = RSUserRoleRewardPoints::user_role_based_reward_points($order->user_id, $points) * $item['qty'];
                                FPRewardSystem::save_total_earned_points($order->user_id, $getpointsmulti);
                                if($order->user_id != ''){
                                $overalllog[] = array('userid' => $order->user_id, 'totalvalue' => $getpointsmulti, 'eventname' => $toupdatedvaluesarrays, 'date' => $order->order_date);
                                $getoveralllog = get_option('rsoveralllog');
                                $logmerge = array_merge((array) $getoveralllog, $overalllog);
                                //update_option('rsoveralllog', $logmerge);
                                }
                                $userpoints = get_user_meta($order->user_id, '_my_reward_points', true);
                                $newgetpoints = $getpointsmulti + $userpoints;
                                if ($enabledisablemaxpoints == 'yes') {
                                    if (($newgetpoints <= $restrictuserpoints) || ($restrictuserpoints == '')) {
                                        $newgetpoints = $newgetpoints;
                                    } else {
                                        $newgetpoints = $restrictuserpoints;
                                    }
                                }
                                update_user_meta($order->user_id, '_my_reward_points', $newgetpoints);
                            }
                        }