<?php
$referral_registration_points = get_option('rs_referral_reward_signup');
    $restrictuserpoints = get_option('rs_maximum_earning_points_for_user');
    $enabledisablepoints = get_option('rs_enable_maximum_earning_points');
 if (isset($_COOKIE['rsreferredusername'])) {
                /*
                 * Update the Referred Person Registration Count
                 */
                    
                $user_info = new WP_User($user_id);                
                $registered_date = $user_info->user_registered;                
                $limitation = false;
                $modified_registered_date = date('Y-m-d h:i:sa', strtotime($registered_date));
                $delay_days = get_option('_rs_select_referral_points_referee_time_content');
                $checking_date = date('Y-m-d h:i:sa', strtotime($modified_registered_date . ' + ' . $delay_days . ' days '));
                $modified_checking_date = strtotime($checking_date);
                $current_date = date('Y-m-d h:i:sa');
                $modified_current_date = strtotime($current_date);               
                //Is for Immediatly
                if (get_option('_rs_select_referral_points_referee_time') == '1') {
                    $limitation = true;
                } else {
                    // Is for Limited Time with Number of Days
                    if ($modified_current_date > $modified_checking_date) {
                        $limitation = true;
                    } else {
                        $limitation = false;
                    }
                }
                if ($limitation == true) {
                    $referreduser = get_user_by('login', $_COOKIE['rsreferredusername']);
                    if ($referreduser != false) {
                        $refuserid = $referreduser->ID;
                    } else {
                        $refuserid = $_COOKIE['rsreferredusername'];
                    }    
                    
            $banning_type = FPRewardSystem::check_banning_type($refuserid);
            if ($banning_type != 'earningonly' && $banning_type != 'both') {
                        $getregisteredcount = get_user_meta($refuserid, 'rsreferreduserregisteredcount', true);
                        $currentregistration = $getregisteredcount + 1;
                       // update_user_meta($refuserid, 'rsreferreduserregisteredcount', $currentregistration);
                     
                        /*
                         * Update the Referred Person Registration Count End
                         */
                        $oldpointss = get_user_meta($refuserid, '_my_reward_points', true);

                        $referral_registration_points = RSUserRoleRewardPoints::user_role_based_reward_points($refuserid, $referral_registration_points);
                        $previouslog = get_option('rs_referral_log');
                        RS_Referral_Log::main_referral_log_function($refuserid, $user_id, $referral_registration_points, array_filter((array) $previouslog));
                        FPRewardSystem::save_total_earned_points($refuserid, $referral_registration_points);
                        $currentregistrationpointss = $oldpointss + $referral_registration_points;
                        if ($enabledisablepoints == 'yes') {
                            if (($currentregistrationpointss <= $restrictuserpoints) || ($restrictuserpoints == '')) {
                                $currentregistrationpointss = $currentregistrationpointss;
                            } else {
                                $currentregistrationpointss = $restrictuserpoints;
                            }
                        }
                        $mainpoints = array();

                        $mainpoints[$user_id] = array('userid' => $user_id, 'points' => $referral_registration_points, 'refuserid' => $refuserid, 'refpoints' =>$referral_registration_points);
                        
                        update_user_meta($user_id,'rs_get_data_for_reward_points',$mainpoints);
                }
                    
                }
            }