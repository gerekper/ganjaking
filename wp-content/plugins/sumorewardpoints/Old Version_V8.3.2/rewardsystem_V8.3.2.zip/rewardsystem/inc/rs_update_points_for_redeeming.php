<?php 


// Inside Loop  

 $rewardpointscoupons = $order->get_items(array('coupon'));
                        $getuserdatabyid = get_user_by('id', $order->user_id);
                        $getusernickname = $getuserdatabyid->user_login;
                        $maincouponchecker = 'sumo_' . strtolower($getusernickname);
                        foreach ($rewardpointscoupons as $couponcode => $value) {
                            if ($maincouponchecker == $value['name']) {
                                if (get_option('rewardsystem_looped_over_coupon' . $order_id) != '1') {
                                    $getuserdatabyid = get_user_by('id', $order->user_id);
                                    $getusernickname = $getuserdatabyid->user_login;
                                    $getcouponid = get_user_meta($order->user_id, 'redeemcouponids', true);
                                    $currentamount = get_post_meta($getcouponid, 'coupon_amount', true);
                                    //update_option('testings', $order->get_total_discount());
                                    if ($currentamount >= $value['discount_amount']) {
                                        $current_conversion = get_option('rs_redeem_point');
                                        $point_amount = get_option('rs_redeem_point_value');
                                        $redeemedamount = $value['discount_amount'] * $current_conversion;
                                        $redeemedpoints = $redeemedamount / $point_amount;
                                        //$overalllog[] = array('userid' => $order->user_id, 'totalvalue' => $redeemedpoints, 'eventname' => 'Points Redeemed Towards Purchase', 'date' => $order->order_date);
                                        //$getoveralllog = get_option('rsoveralllog');
                                        //$logmerge = array_merge((array) $getoveralllog, $overalllog);
                                        //update_option('rsoveralllog', $logmerge);
                                        $rs_totalredeempoints[$item['variation_id']]=$redeemedpoints;
                                        update_user_meta($order->user_id, '_redeemed_points', $redeemedpoints);
                                        update_user_meta($order->user_id, '_redeemed_amount', $value['discount_amount']);
                                        $yourpoints = get_user_meta($order->user_id, '_my_reward_points', true);
                                        update_user_meta($order->user_id, '_my_reward_points', $yourpoints - $redeemedpoints);                                                                                                                       
                                        $fp_earned_points_sms = true;
                                        if($fp_earned_points_sms == true){
                                            if(get_option('rs_enable_send_sms_to_user') == 'yes'){
                                                if(get_option('rs_send_sms_redeeming_points') == 'yes'){
                                       if(get_option('rs_sms_sending_api_option') == '1'){                                
                        FPRewardSystemSms::send_sms_twilio_api($order_id);
                    }else{
                        FPRewardSystemSms::send_sms_nexmo_api($order_id);
                    }
                                                }
                                            }        
                                        }
                                        
                                    }

                                    update_option('rewardsystem_looped_over_coupon' . $order_id, '1');
                                }
                            }
                        }