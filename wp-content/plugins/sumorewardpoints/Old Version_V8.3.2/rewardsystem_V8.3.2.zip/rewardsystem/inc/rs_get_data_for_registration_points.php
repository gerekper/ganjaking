<?php
            $registration_points = RSUserRoleRewardPoints::user_role_based_reward_points($user_id, get_option('rs_reward_signup'));
            FPRewardSystem::save_total_earned_points($user_id, $registration_points);
            $referral_registration_points = get_option('rs_referral_reward_signup');
            $restrictuserpoints = get_option('rs_maximum_earning_points_for_user');
            $enabledisablepoints = get_option('rs_enable_maximum_earning_points');
            
            
            
            $oldpoints = get_user_meta($user_id, '_my_reward_points', true);
            $currentregistrationpoints = $oldpoints + $registration_points;

            if ($enabledisablepoints == 'yes') {
                if (($currentregistrationpoints <= $restrictuserpoints) || ($restrictuserpoints == '')) {
                    $currentregistrationpoints = $currentregistrationpoints;
                } else {
                    $currentregistrationpoints = $restrictuserpoints;
                }
            }


            $registeredusermessage = get_option('_rs_localize_points_earned_for_registration');
            $fromregistereduser = array('{registereduser}');
            $toregistereduser = array(get_user_meta($user_id, 'nickname', true));
            $updatedregistereduser = str_replace($fromregistereduser, $toregistereduser, $registeredusermessage);

            update_user_meta($user_id, '_my_reward_points', $currentregistrationpoints);
            $myreward = get_user_meta($user_id, '_my_reward_points', true);
            $pointslog[] = array('orderid' => '', 'userid' => $user_id, 'points_earned_order' => $currentregistrationpoints, 'points_redeemed' => '', 'points_value' => '', 'before_order_points' => '', 'totalpoints' => $myreward, 'date' => date('Y-m-d H:i:s'), 'rewarder_for' => $updatedregistereduser, 'rewarder_for_frontend' => $updatedregistereduser);
            $overalllog[] = array('userid' => $user_id, 'totalvalue' => $myreward, 'eventname' => $updatedregistereduser, 'date' => date('Y-m-d H:i:s'));
            $getoveralllog = get_option('rsoveralllog');
            $logmerge = array_merge((array) $getoveralllog, $overalllog);
            update_option('rsoveralllog', $logmerge);
            $getmypoints = get_user_meta($user_id, '_my_points_log', true);
            $merged = array_merge((array) $getmypoints, $pointslog);
            update_user_meta($user_id, '_my_points_log', $merged);
            add_user_meta($user_id, '_points_awarded', '1');