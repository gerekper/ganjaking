<?php
                            $user_info = new WP_User($order->user_id);
                            $registered_date = $user_info->user_registered;
                            $limitation = false;
                            $modified_registered_date = date('Y-m-d h:i:sa', strtotime($registered_date));
                            $delay_days = get_option('_rs_select_referral_points_referee_time_content');
                            $checking_date = date('Y-m-d h:i:sa', strtotime($modified_registered_date . ' + ' . $delay_days . ' days '));
                            $modified_checking_date = strtotime($checking_date);
                            $current_date = date('Y-m-d h:i:sa');
                            $modified_current_date = strtotime($current_date);
                            //Is for Immediatly
                            if (get_option('_rs_select_referral_points_referee_time') == '1') {
                                $limitation = true;
                            } else {
                                // Is for Limited Time with Number of Days
                                if ($modified_current_date > $modified_checking_date) {
                                    $limitation = true;
                                } else {
                                    $limitation = false;
                                }
                            }

                            if ($limitation == true) {
                                $refuser = get_user_by('login', $referreduser);
                                if ($refuser != false) {
                                    
                                    $myid = $refuser->ID;
                                } else {
                                    $myid = $referreduser;
                                }
//                                $banned_user_list = get_option('rs_banned-users_list');
//                                if (!in_array($myid, (array) $banned_user_list)) {
//                                    $getarrayofuserdataref = get_userdata($myid);
//                                    $banninguserrole = get_option('rs_banning_user_role');
//                                    if (!in_array(isset($getarrayofuserdata->roles[0]) ? $getarrayofuserdata->roles[0] : '0', (array) $banninguserrole)) {
                                        $banning_type = FPRewardSystem::check_banning_type($myid);        
                                        if($banning_type!='earningonly'&&$banning_type!='both') {
                                        if (get_post_meta($item['product_id'], '_rewardsystemcheckboxvalue', true) == 'yes') {
                                            $getreferraltype = get_post_meta($item['product_id'], '_referral_rewardsystem_options', true);
                                            if ($getreferraltype == '1') {
                                                $getreferralpoints = get_post_meta($item['product_id'], '_referralrewardsystempoints', true);
                                                if ($getreferralpoints == '') {
                                                    $term = get_the_terms($item['product_id'], 'product_cat');
                                                    if (is_array($term)) {
                                                        $rewardpointer = array();
                                                        foreach ($term as $term) {
                                                            $enablevalue = get_woocommerce_term_meta($term->term_id, 'enable_reward_system_category', true);
                                                            $display_type = get_woocommerce_term_meta($term->term_id, 'referral_enable_rs_rule', true);
                                                            if (($enablevalue == 'yes') && ($enablevalue != '')) {
                                                                if ($display_type == '1') {
                                                                    if (get_woocommerce_term_meta($term->term_id, 'referral_rs_category_points', true) == '') {

                                                                        if ($global_referral_enable == '1') {
                                                                            if ($global_referral_reward_type == '1') {
                                                                                $rewardpointer[] = get_option('rs_global_referral_reward_point');
                                                                            } else {
                                                                                $pointconversion = get_option('rs_earn_point');
                                                                                $pointconversionvalue = get_option('rs_earn_point_value');
                                                                                $getaverage = get_option('rs_global_referral_reward_percent') / 100;
                                                                                $getaveragepoints = $getaverage * $getregularprice;
                                                                                $pointswithvalue = $getaveragepoints * $pointconversion;
                                                                                $rewardpointer[] = $pointswithvalue / $pointconversionvalue;
                                                                            }
                                                                        }
                                                                    } else {
                                                                        $rewardpointer[] = get_woocommerce_term_meta($term->term_id, 'referral_rs_category_points', true);
                                                                    }
                                                                } else {
                                                                    $pointconversion = get_option('rs_earn_point');
                                                                    $pointconversionvalue = get_option('rs_earn_point_value');
                                                                    $getaverage = get_woocommerce_term_meta($term->term_id, 'referral_rs_category_percent', true) / 100;
                                                                    $getaveragepoints = $getaverage * $getregularprice;
                                                                    $pointswithvalue = $getaveragepoints * $pointconversion;
                                                                    if (get_woocommerce_term_meta($term->term_id, 'referral_rs_category_percent', true) == '') {
                                                                        $global_referral_enable = get_option('rs_global_enable_disable_reward');
                                                                        $global_referral_reward_type = get_option('rs_global_referral_reward_type');
                                                                        if ($global_referral_enable == '1') {
                                                                            if ($global_referral_reward_type == '1') {
                                                                                $rewardpointer[] = get_option('rs_global_referral_reward_point');
                                                                            } else {
                                                                                $pointconversion = get_option('rs_earn_point');
                                                                                $pointconversionvalue = get_option('rs_earn_point_value');
                                                                                $getaverage = get_option('rs_global_referral_reward_percent') / 100;
                                                                                $getaveragepoints = $getaverage * $getregularprice;
                                                                                $pointswithvalue = $getaveragepoints * $pointconversion;
                                                                                $rewardpointer[] = $pointswithvalue / $pointconversionvalue;
                                                                            }
                                                                        }
                                                                    } else {
                                                                        $rewardpointer[] = $pointswithvalue / $pointconversionvalue;
                                                                    }
                                                                }
                                                            } else {
                                                                if ($global_referral_enable == '1') {
                                                                    if ($global_referral_reward_type == '1') {
                                                                        $rewardpointer[] = get_option('rs_global_referral_reward_point');
                                                                    } else {
                                                                        $pointconversion = get_option('rs_earn_point');
                                                                        $pointconversionvalue = get_option('rs_earn_point_value');
                                                                        $getaverage = get_option('rs_global_referral_reward_percent') / 100;
                                                                        $getaveragepoints = $getaverage * $getregularprice;
                                                                        $pointswithvalue = $getaveragepoints * $pointconversion;
                                                                        $rewardpointer[] = $pointswithvalue / $pointconversionvalue;
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    } else {
                                                        if ($global_referral_enable == '1') {
                                                            if ($global_referral_reward_type == '1') {
                                                                $rewardpointer[] = get_option('rs_global_referral_reward_point');
                                                            } else {
                                                                $pointconversion = get_option('rs_earn_point');
                                                                $pointconversionvalue = get_option('rs_earn_point_value');
                                                                $getaverage = get_option('rs_global_referral_reward_percent') / 100;
                                                                $getaveragepoints = $getaverage * $getregularprice;
                                                                $pointswithvalue = $getaveragepoints * $pointconversion;
                                                                $rewardpointer[] = $pointswithvalue / $pointconversionvalue;
                                                            }
                                                        }
                                                    }
                                                    $getreferralpoints = max($rewardpointer);
                                                }


                                                $exactpointer = RSUserRoleRewardPoints::user_role_based_reward_points($myid, $getreferralpoints) * $item['qty'];
                                                FPRewardSystem::save_total_earned_points($myid, $exactpointer);
                                                $logofgetoption = get_option('_rs_localize_referral_reward_points_for_purchase');

                                                $findarrays = array('{itemproductid}', '{purchasedusername}');
                                                $usernickname = get_user_meta($order->user_id, 'nickname', true);
                                                $replacearrays = array($item['product_id'], $usernickname != '' ? $usernickname : __('Guest','rewardsystem'));                                                

                                                $updatedvaluesarrays = str_replace($findarrays, $replacearrays, $logofgetoption);

                                                $overalllogs[] = array('userid' => $myid, 'totalvalue' => $exactpointer, 'eventname' => $updatedvaluesarrays, 'date' => $order->order_date);
                                                $getoveralllogs = get_option('rsoveralllog');
                                                $logmerges = array_merge((array) $getoveralllogs, $overalllogs);
                                                update_option('rsoveralllog', $logmerges);

                                                $userpoints = get_user_meta($myid, '_my_reward_points', true);
                                                $newgetpoints = $exactpointer + $userpoints;
                                                if ($enabledisablemaxpoints == '1') {
                                                    if (($newgetpoints <= $restrictuserpoints) || ($restrictuserpoints == '')) {
                                                        $newgetpoints = $newgetpoints;
                                                    } else {
                                                        $newgetpoints = $restrictuserpoints;
                                                    }
                                                }
                                                update_user_meta($myid, '_my_reward_points', $newgetpoints);
                                                $previouslog = get_option('rs_referral_log');
                                                RS_Referral_Log::main_referral_log_function($myid,$order->user_id,$exactpointer,(array)$previouslog);
                                                $pointsfixed[] = array('orderid' => $order_id, 'userid' => $myid, 'points_earned_order' => $exactpointer, 'points_redeemed' => '', 'points_value' => '', 'before_order_points' => '', 'totalpoints' => get_user_meta($myid, '_my_reward_points', true), 'date' => $order->order_date, 'rewarder_for' => $updatedvaluesarrays, 'rewarder_for_frontend' => $updatedvaluesarrays);
                                                $getlogger = get_user_meta($myid, '_my_points_log', true);
                                                $merged = array_merge((array) $getlogger, $pointsfixed);
                                                update_user_meta($myid, '_my_points_log', $merged);
                                            } else {



                                                $points = get_option('rs_earn_point');
                                                $pointsequalto = get_option('rs_earn_point_value');
                                                $getreferralpercent = get_post_meta($item['product_id'], '_referralrewardsystempercent', true);
                                                if (get_option('rs_set_price_percentage_reward_points') == '1') {
                                                    $getregularprices = get_post_meta($item['product_id'], '_regular_price', true);
                                                } else {
                                                    $getregularprices = get_post_meta($item['product_id'], '_price', true);
                                                }

                                                /* Referral Simple Product with Regular Prices */
                                                do_action_ref_array('rs_update_points_for_referral_simples', array(&$getregularprices, &$item));

                                                $referralpercentageproduct = $getreferralpercent / 100;
                                                $getreferralpricepercent = $referralpercentageproduct * $getregularprices;
                                                $getpointconversion = $getreferralpricepercent * $points;
                                                $getreferpoints = $getpointconversion / $pointsequalto;

                                                if ($getreferralpercent == '') {
                                                    $term = get_the_terms($item['product_id'], 'product_cat');
// var_dump($term);
                                                    if (is_array($term)) {
//var_dump($term);
                                                        $rewardpoints = array('0');
                                                        foreach ($term as $term) {

                                                            $enablevalue = get_woocommerce_term_meta($term->term_id, 'enable_reward_system_category', true);
                                                            $display_type = get_woocommerce_term_meta($term->term_id, 'referral_enable_rs_rule', true);
//                                            echo $rewardpoints = get_woocommerce_term_meta($term->term_id, 'rs_category_points', true) . "<br>";
//                                            echo $rewardpercent = get_woocommerce_term_meta($term->term_id, 'rs_category_percent', true) . "<br>";
                                                            if (($enablevalue == 'yes') && ($enablevalue != '')) {
                                                                if ($display_type == '1') {
                                                                    if (get_woocommerce_term_meta($term->term_id, 'referral_rs_category_points', true) == '') {
                                                                        $global_referral_enable = get_option('rs_global_enable_disable_reward');
                                                                        $global_referral_reward_type = get_option('rs_global_referral_reward_type');
                                                                        if ($global_referral_enable == '1') {
                                                                            if ($global_referral_reward_type == '1') {
                                                                                $rewardpoints[] = get_option('rs_global_referral_reward_point');
                                                                            } else {
                                                                                $pointconversion = get_option('rs_earn_point');
                                                                                $pointconversionvalue = get_option('rs_earn_point_value');
                                                                                $getaverage = get_option('rs_global_referral_reward_percent') / 100;
                                                                                $getaveragepoints = $getaverage * $getregularprice;
                                                                                $pointswithvalue = $getaveragepoints * $pointconversion;
                                                                                $rewardpoints[] = $pointswithvalue / $pointconversionvalue;
                                                                            }
                                                                        }
                                                                    } else {
                                                                        $rewardpoints[] = get_woocommerce_term_meta($term->term_id, 'referral_rs_category_points', true);
                                                                    }
                                                                } else {
                                                                    $pointconversion = get_option('rs_earn_point');
                                                                    $pointconversionvalue = get_option('rs_earn_point_value');
                                                                    $getaverage = get_woocommerce_term_meta($term->term_id, 'referral_rs_category_percent', true) / 100;
                                                                    $getaveragepoints = $getaverage * $getregularprice;
                                                                    $pointswithvalue = $getaveragepoints * $pointconversion;
                                                                    if (get_woocommerce_term_meta($term->term_id, 'referral_rs_category_percent', true) == '') {
                                                                        $global_referral_enable = get_option('rs_global_enable_disable_reward');
                                                                        $global_referral_reward_type = get_option('rs_global_referral_reward_type');
                                                                        if ($global_referral_enable == '1') {
                                                                            if ($global_referral_reward_type == '1') {
                                                                                $rewardpoints[] = get_option('rs_global_referral_reward_point');
                                                                            } else {
                                                                                $pointconversion = get_option('rs_earn_point');
                                                                                $pointconversionvalue = get_option('rs_earn_point_value');
                                                                                $getaverage = get_option('rs_global_referral_reward_percent') / 100;
                                                                                $getaveragepoints = $getaverage * $getregularprice;
                                                                                $pointswithvalue = $getaveragepoints * $pointconversion;
                                                                                $rewardpoints[] = $pointswithvalue / $pointconversionvalue;
                                                                            }
                                                                        }
                                                                    } else {
                                                                        $rewardpoints[] = $pointswithvalue / $pointconversionvalue;
                                                                    }
                                                                }
                                                            } else {
                                                                if ($global_referral_enable == '1') {
                                                                    if ($global_referral_reward_type == '1') {
                                                                        $rewardpoints[] = get_option('rs_global_referral_reward_point');
                                                                    } else {
                                                                        $pointconversion = get_option('rs_earn_point');
                                                                        $pointconversionvalue = get_option('rs_earn_point_value');
                                                                        $getaverage = get_option('rs_global_referral_reward_percent') / 100;
                                                                        $getaveragepoints = $getaverage * $getregularprice;
                                                                        $pointswithvalue = $getaveragepoints * $pointconversion;
                                                                        $rewardpoints[] = $pointswithvalue / $pointconversionvalue;
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    } else {
                                                        if ($global_referral_enable == '1') {
                                                            if ($global_referral_reward_type == '1') {
                                                                $rewardpoints[] = get_option('rs_global_referral_reward_point');
                                                            } else {
                                                                $pointconversion = get_option('rs_earn_point');
                                                                $pointconversionvalue = get_option('rs_earn_point_value');
                                                                $getaverage = get_option('rs_global_referral_reward_percent') / 100;
                                                                $getaveragepoints = $getaverage * $getregularprice;
                                                                $pointswithvalue = $getaveragepoints * $pointconversion;
                                                                $rewardpoints[] = $pointswithvalue / $pointconversionvalue;
                                                            }
                                                        }
                                                    }
                                                    $getreferpoints = max($rewardpoints);
                                                }


                                                $logofgetoption = get_option('_rs_localize_referral_reward_points_for_purchase');

                                                $findarrays = array('{itemproductid}', '{purchasedusername}');
                                                $usernickname = get_user_meta($order->user_id, 'nickname', true);
                                                $replacearrays = array($item['product_id'], $usernickname != '' ? $usernickname : __('Guest','rewardsystem'));                                                
                                                $updatedvaluesarrays = str_replace($findarrays, $replacearrays, $logofgetoption);



                                                $exactpointer = RSUserRoleRewardPoints::user_role_based_reward_points($myid, $getreferpoints) * $item['qty'];
                                                FPRewardSystem::save_total_earned_points($myid, $exactpointer);
                                                $overalllogs[] = array('userid' => $myid, 'totalvalue' => $exactpointer, 'eventname' => $updatedvaluesarrays, 'date' => $order->order_date);
                                                $getoveralllogs = get_option('rsoveralllog');
                                                $logmerges = array_merge((array) $getoveralllogs, $overalllogs);
                                                update_option('rsoveralllog', $logmerges);
                                                $userpoints = get_user_meta($myid, '_my_reward_points', true);
                                                $updatedpoints = $exactpointer + $userpoints;
                                                if ($enabledisablemaxpoints == '1') {
                                                    if (($updatedpoints <= $restrictuserpoints) || ($restrictuserpoints == '')) {
                                                        $updatedpoints = $updatedpoints;
                                                    } else {
                                                        $updatedpoints = $restrictuserpoints;
                                                    }
                                                }
                                                update_user_meta($myid, '_my_reward_points', $updatedpoints);
                                                $previouslog = get_option('rs_referral_log');
                                                RS_Referral_Log::main_referral_log_function($myid,$order->user_id,$exactpointer,(array)$previouslog);
                                                $pointspercent[] = array('orderid' => $order_id, 'userid' => $myid, 'points_earned_order' => $exactpointer, 'points_redeemed' => '', 'points_value' => '', 'before_order_points' => '', 'totalpoints' => get_user_meta($myid, '_my_reward_points', true), 'date' => $order->order_date, 'rewarder_for' => $updatedvaluesarrays, 'rewarder_for_frontend' => $updatedvaluesarrays);
                                                $getlogg = get_user_meta($myid, '_my_points_log', true);
                                                $mergeds = array_merge((array) $getlogg, $pointspercent);
                                                update_user_meta($myid, '_my_points_log', $mergeds);
                                            }
                                        }


                                        /* Referral Reward Points for Variable Products */
                                        if (get_post_meta($item['variation_id'], '_enable_reward_points', true) == '1') {
                                            $variablereferralrewardpoints = get_post_meta($item['variation_id'], '_referral_reward_points', true);
                                            $variationreferralselectrule = get_post_meta($item['variation_id'], '_select_referral_reward_rule', true);
                                            $variationreferralrewardpercent = get_post_meta($item['variation_id'], '_referral_reward_percent', true);
                                            $variable_products = new WC_Product_Variation($item['variation_id']);
                                            if (get_option('rs_set_price_percentage_reward_points') == '1') {
                                                $variationregularprice = $variable_products->regular_price;
                                            } else {
                                                $variationregularprice = $variable_products->price;
                                            }

                                            do_action_ref_array('rs_update_points_for_referral_variable', array(&$variationregularprice, &$item));


                                            if ($variationreferralselectrule == '1') {
                                                $getreferralpoints = get_post_meta($item['variation_id'], '_referral_reward_points', true);
                                                $parentvariationid = new WC_Product_Variation($item['variation_id']);
                                                $newparentid = $parentvariationid->parent->id;
                                                if ($getreferralpoints == '') {
                                                    $term = get_the_terms($newparentid, 'product_cat');
//var_dump($term);
                                                    if (is_array($term)) {
//var_dump($term);
                                                        $rewardpoints = array('0');
                                                        foreach ($term as $term) {

                                                            $enablevalue = get_woocommerce_term_meta($term->term_id, 'enable_reward_system_category', true);
                                                            $display_type = get_woocommerce_term_meta($term->term_id, 'referral_enable_rs_rule', true);
//                                            echo $rewardpoints = get_woocommerce_term_meta($term->term_id, 'rs_category_points', true) . "<br>";
//                                            echo $rewardpercent = get_woocommerce_term_meta($term->term_id, 'rs_category_percent', true) . "<br>";
                                                            if (($enablevalue == 'yes') && ($enablevalue != '')) {
                                                                if ($display_type == '1') {
                                                                    if (get_woocommerce_term_meta($term->term_id, 'referral_rs_category_points', true) == '') {
                                                                        $global_referral_enable = get_option('rs_global_enable_disable_reward');
                                                                        $global_referral_reward_type = get_option('rs_global_referral_reward_type');
                                                                        if ($global_referral_enable == '1') {
                                                                            if ($global_referral_reward_type == '1') {
                                                                                $rewardpoints[] = get_option('rs_global_referral_reward_point');
                                                                            } else {
                                                                                $pointconversion = get_option('rs_earn_point');
                                                                                $pointconversionvalue = get_option('rs_earn_point_value');
                                                                                $getaverage = get_option('rs_global_referral_reward_percent') / 100;
                                                                                $getaveragepoints = $getaverage * $variationregularprice;
                                                                                $pointswithvalue = $getaveragepoints * $pointconversion;
                                                                                $rewardpoints[] = $pointswithvalue / $pointconversionvalue;
                                                                            }
                                                                        }
                                                                    } else {
                                                                        $rewardpoints[] = get_woocommerce_term_meta($term->term_id, 'referral_rs_category_points', true);
                                                                    }
                                                                } else {
                                                                    $pointconversion = get_option('rs_earn_point');
                                                                    $pointconversionvalue = get_option('rs_earn_point_value');
                                                                    $getaverage = get_woocommerce_term_meta($term->term_id, 'referral_rs_category_percent', true) / 100;
                                                                    $getaveragepoints = $getaverage * $variationregularprice;
                                                                    $pointswithvalue = $getaveragepoints * $pointconversion;
                                                                    if (get_woocommerce_term_meta($term->term_id, 'referral_rs_category_percent', true) == '') {
                                                                        $global_referral_enable = get_option('rs_global_enable_disable_reward');
                                                                        $global_referral_reward_type = get_option('rs_global_referral_reward_type');
                                                                        if ($global_referral_enable == '1') {
                                                                            if ($global_referral_reward_type == '1') {
                                                                                $rewardpoints[] = get_option('rs_global_referral_reward_point');
                                                                            } else {
                                                                                $pointconversion = get_option('rs_earn_point');
                                                                                $pointconversionvalue = get_option('rs_earn_point_value');
                                                                                $getaverage = get_option('rs_global_referral_reward_percent') / 100;
                                                                                $getaveragepoints = $getaverage * $variationregularprice;
                                                                                $pointswithvalue = $getaveragepoints * $pointconversion;
                                                                                $rewardpoints[] = $pointswithvalue / $pointconversionvalue;
                                                                            }
                                                                        }
                                                                    } else {
                                                                        $rewardpoints[] = $pointswithvalue / $pointconversionvalue;
                                                                    }
                                                                }
                                                            } else {
                                                                if ($global_referral_enable == '1') {
                                                                    if ($global_referral_reward_type == '1') {
                                                                        $rewardpoints[] = get_option('rs_global_referral_reward_point');
                                                                    } else {
                                                                        $pointconversion = get_option('rs_earn_point');
                                                                        $pointconversionvalue = get_option('rs_earn_point_value');
                                                                        $getaverage = get_option('rs_global_referral_reward_percent') / 100;
                                                                        $getaveragepoints = $getaverage * $variationregularprice;
                                                                        $pointswithvalue = $getaveragepoints * $pointconversion;
                                                                        $rewardpoints[] = $pointswithvalue / $pointconversionvalue;
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    } else {
                                                        if ($global_referral_enable == '1') {
                                                            if ($global_referral_reward_type == '1') {
                                                                $rewardpoints[] = get_option('rs_global_referral_reward_point');
                                                            } else {
                                                                $pointconversion = get_option('rs_earn_point');
                                                                $pointconversionvalue = get_option('rs_earn_point_value');
                                                                $getaverage = get_option('rs_global_referral_reward_percent') / 100;
                                                                $getaveragepoints = $getaverage * $variationregularprice;
                                                                $pointswithvalue = $getaveragepoints * $pointconversion;
                                                                $rewardpoints[] = $pointswithvalue / $pointconversionvalue;
                                                            }
                                                        }
                                                    }
//var_dump($rewardpoints);
                                                    $getreferralpoints = max($rewardpoints);

//$rewardpoints = array_search($value, $rewardpoints);
                                                }

                                                $logofgetoption = get_option('_rs_localize_referral_reward_points_for_purchase');

                                                $findarrays = array('{itemproductid}', '{purchasedusername}');
                                                $usernickname = get_user_meta($order->user_id, 'nickname', true);
                                                $replacearrays = array($item['variation_id'], $usernickname != '' ? $usernickname : __('Guest','rewardsystem'));                                                
                                                $updatedvaluesarrays = str_replace($findarrays, $replacearrays, $logofgetoption);

                                                $getvarpoints = RSUserRoleRewardPoints::user_role_based_reward_points($myid, $getreferralpoints) * $item['qty'];
                                                FPRewardSystem::save_total_earned_points($myid, $getvarpoints);
                                                $overalllogging[] = array('userid' => $myid, 'totalvalue' => $getvarpoints, 'eventname' => $updatedvaluesarrays, 'date' => $order->order_date);
                                                $getoveralllogging = get_option('rsoveralllog');
                                                $logmerging = array_merge((array) $getoveralllogging, $overalllogging);
                                                update_option('rsoveralllog', $logmerging);
                                                $userpoints = get_user_meta($myid, '_my_reward_points', true);
                                                $newgetpointing = $getvarpoints + $userpoints;
                                                if ($enabledisablemaxpoints == '1') {
                                                    if (($newgetpointing <= $restrictuserpoints) || ($restrictuserpoints == '')) {
                                                        $newgetpointing = $newgetpointing;
                                                    } else {
                                                        $newgetpointing = $restrictuserpoints;
                                                    }
                                                }
                                                update_user_meta($myid, '_my_reward_points', $newgetpointing);
                                                $previouslog = get_option('rs_referral_log');
                                                RS_Referral_Log::main_referral_log_function($myid,$order->user_id,$getvarpoints,(array)$previouslog);
                                                $varpointsfixed[] = array('orderid' => $order_id, 'userid' => $myid, 'points_earned_order' => $getvarpoints, 'points_redeemed' => '', 'points_value' => '', 'before_order_points' => '', 'totalpoints' => get_user_meta($myid, '_my_reward_points', true), 'date' => $order->order_date, 'rewarder_for' => $updatedvaluesarrays, 'rewarder_for_frontend' => $updatedvaluesarrays);
                                                $getlogge = get_user_meta($myid, '_my_points_log', true);
                                                $mergedse = array_merge((array) $getlogge, $varpointsfixed);
                                                update_user_meta($myid, '_my_points_log', $mergedse);
                                            } else {
                                                $pointconversion = get_option('rs_earn_point');
                                                $pointconversionvalue = get_option('rs_earn_point_value');
                                                $getvaraverage = $variationreferralrewardpercent / 100;
                                                $getvaraveragepoints = $getvaraverage * $variationregularprice;
                                                $getvarpointsvalue = $getvaraveragepoints * $pointconversion;
                                                $varpoints = $getvarpointsvalue / $pointconversionvalue;

                                                $parentvariationid = new WC_Product_Variation($item['variation_id']);
                                                $newparentid = $parentvariationid->parent->id;
                                                if ($variationreferralrewardpercent == '') {
                                                    $term = get_the_terms($newparentid, 'product_cat');
//var_dump($term);
                                                    if (is_array($term)) {
//var_dump($term);
                                                        $rewardpoints = array('0');
                                                        foreach ($term as $term) {

                                                            $enablevalue = get_woocommerce_term_meta($term->term_id, 'enable_reward_system_category', true);
                                                            $display_type = get_woocommerce_term_meta($term->term_id, 'referral_enable_rs_rule', true);
//                                            echo $rewardpoints = get_woocommerce_term_meta($term->term_id, 'rs_category_points', true) . "<br>";
//                                            echo $rewardpercent = get_woocommerce_term_meta($term->term_id, 'rs_category_percent', true) . "<br>";
                                                            if (($enablevalue == 'yes') && ($enablevalue != '')) {
                                                                if ($display_type == '1') {
                                                                    if (get_woocommerce_term_meta($term->term_id, 'referral_rs_category_points', true) == '') {
                                                                        $global_referral_enable = get_option('rs_global_enable_disable_reward');
                                                                        $global_referral_reward_type = get_option('rs_global_referral_reward_type');
                                                                        if ($global_referral_enable == '1') {
                                                                            if ($global_referral_reward_type == '1') {
                                                                                $rewardpoints[] = get_option('rs_global_referral_reward_point');
                                                                            } else {
                                                                                $pointconversion = get_option('rs_earn_point');
                                                                                $pointconversionvalue = get_option('rs_earn_point_value');
                                                                                $getaverage = get_option('rs_global_referral_reward_percent') / 100;
                                                                                $getaveragepoints = $getaverage * $variationregularprice;
                                                                                $pointswithvalue = $getaveragepoints * $pointconversion;
                                                                                $rewardpoints[] = $pointswithvalue / $pointconversionvalue;
                                                                            }
                                                                        }
                                                                    } else {
                                                                        $rewardpoints[] = get_woocommerce_term_meta($term->term_id, 'referral_rs_category_points', true);
                                                                    }
                                                                } else {
                                                                    $pointconversion = get_option('rs_earn_point');
                                                                    $pointconversionvalue = get_option('rs_earn_point_value');
                                                                    $getaverage = get_woocommerce_term_meta($term->term_id, 'referral_rs_category_percent', true) / 100;
                                                                    $getaveragepoints = $getaverage * $variationregularprice;
                                                                    $pointswithvalue = $getaveragepoints * $pointconversion;
                                                                    if (get_woocommerce_term_meta($term->term_id, 'referral_rs_category_percent', true) == '') {
                                                                        $global_referral_enable = get_option('rs_global_enable_disable_reward');
                                                                        $global_referral_reward_type = get_option('rs_global_referral_reward_type');
                                                                        if ($global_referral_enable == '1') {
                                                                            if ($global_referral_reward_type == '1') {
                                                                                $rewardpoints[] = get_option('rs_global_referral_reward_point');
                                                                            } else {
                                                                                $pointconversion = get_option('rs_earn_point');
                                                                                $pointconversionvalue = get_option('rs_earn_point_value');
                                                                                $getaverage = get_option('rs_global_referral_reward_percent') / 100;
                                                                                $getaveragepoints = $getaverage * $variationregularprice;
                                                                                $pointswithvalue = $getaveragepoints * $pointconversion;
                                                                                $rewardpoints[] = $pointswithvalue / $pointconversionvalue;
                                                                            }
                                                                        }
                                                                    } else {
                                                                        $rewardpoints[] = $pointswithvalue / $pointconversionvalue;
                                                                    }
                                                                }
                                                            } else {
                                                                if ($global_referral_enable == '1') {
                                                                    if ($global_referral_reward_type == '1') {
                                                                        $rewardpoints[] = get_option('rs_global_referral_reward_point');
                                                                    } else {
                                                                        $pointconversion = get_option('rs_earn_point');
                                                                        $pointconversionvalue = get_option('rs_earn_point_value');
                                                                        $getaverage = get_option('rs_global_referral_reward_percent') / 100;
                                                                        $getaveragepoints = $getaverage * $variationregularprice;
                                                                        $pointswithvalue = $getaveragepoints * $pointconversion;
                                                                        $rewardpoints[] = $pointswithvalue / $pointconversionvalue;
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    } else {
                                                        if ($global_referral_enable == '1') {
                                                            if ($global_referral_reward_type == '1') {
                                                                $rewardpoints[] = get_option('rs_global_referral_reward_point');
                                                            } else {
                                                                $pointconversion = get_option('rs_earn_point');
                                                                $pointconversionvalue = get_option('rs_earn_point_value');
                                                                $getaverage = get_option('rs_global_referral_reward_percent') / 100;
                                                                $getaveragepoints = $getaverage * $variationregularprice;
                                                                $pointswithvalue = $getaveragepoints * $pointconversion;
                                                                $rewardpoints[] = $pointswithvalue / $pointconversionvalue;
                                                            }
                                                        }
                                                    }
//var_dump($rewardpoints);
                                                    $varpoints = max($rewardpoints);

//$rewardpoints = array_search($value, $rewardpoints);
                                                }
                                                $logofgetoption = get_option('_rs_localize_referral_reward_points_for_purchase');

                                                $findarrays = array('{itemproductid}', '{purchasedusername}');
                                                $usernickname = get_user_meta($order->user_id, 'nickname', true);
                                                $replacearrays = array($item['variation_id'], $usernickname != '' ? $usernickname : __('Guest','rewardsystem'));                                                
                                                $updatedvaluesarrays = str_replace($findarrays, $replacearrays, $logofgetoption);

                                                $getexactvar = RSUserRoleRewardPoints::user_role_based_reward_points($myid, $varpoints) * $item['qty'];
                                                FPRewardSystem::save_total_earned_points($myid, $getexactvar);
                                                $overallloggered[] = array('userid' => $myid, 'totalvalue' => $getexactvar, 'eventname' => $updatedvaluesarrays, 'date' => $order->order_date);
                                                $getoverallloggered = get_option('rsoveralllog');
                                                $logmergeder = array_merge((array) $getoverallloggered, $overallloggered);
                                                update_option('rsoveralllog', $logmergeder);
                                                $userpointser = get_user_meta($myid, '_my_reward_points', true);
                                                $newgetpointser = $getexactvar + $userpointser;
                                                if ($enabledisablemaxpoints == '1') {
                                                    if (($newgetpointser <= $restrictuserpoints) || ($restrictuserpoints == '')) {
                                                        $newgetpointser = $newgetpointser;
                                                    } else {
                                                        $newgetpointser = $restrictuserpoints;
                                                    }
                                                }
                                                update_user_meta($myid, '_my_reward_points', $newgetpointser);
                                                $previouslog = get_option('rs_referral_log');
                                                RS_Referral_Log::main_referral_log_function($myid,$order->user_id,$getexactvar,(array)$previouslog);
                                                $varpointspercent[] = array('orderid' => $order_id, 'userid' => $myid, 'points_earned_order' => $getexactvar, 'points_redeemed' => '', 'points_value' => '', 'before_order_points' => '', 'totalpoints' => get_user_meta($myid, '_my_reward_points', true), 'date' => $order->order_date, 'rewarder_for' => $updatedvaluesarrays, 'rewarder_for_frontend' => $updatedvaluesarrays);
                                                $getlogge = get_user_meta($myid, '_my_points_log', true);
                                                $mergedse = array_merge((array) $getlogge, $varpointspercent);
                                                update_user_meta($myid, '_my_points_log', $mergedse);
                                            }
                                        }
//                                    }
//                                }
                                    }            
                            }
