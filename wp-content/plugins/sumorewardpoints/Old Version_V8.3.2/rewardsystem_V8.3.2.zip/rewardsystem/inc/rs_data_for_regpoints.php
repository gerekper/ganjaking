<?php
            $banning_type = FPRewardSystem::check_banning_type($user_id);
            if ($banning_type != 'earningonly' && $banning_type != 'both') {
            $registration_points = RSUserRoleRewardPoints::user_role_based_reward_points($user_id, get_option('rs_reward_signup'));
            FPRewardSystem::save_total_earned_points($user_id, $registration_points);            
            $restrictuserpoints = get_option('rs_maximum_earning_points_for_user');
            $enabledisablepoints = get_option('rs_enable_maximum_earning_points');
            
            
            
            $oldpoints = get_user_meta($user_id, '_my_reward_points', true);
            $currentregistrationpoints = $oldpoints + $registration_points;
            

            if ($enabledisablepoints == 'yes') {
                if (($currentregistrationpoints <= $restrictuserpoints) || ($restrictuserpoints == '')) {
                    $currentregistrationpoints = $currentregistrationpoints;
                } else {
                    $currentregistrationpoints = $restrictuserpoints;                    
                }
            }

            $mainpoints=array();
           
            $mainpoints[$user_id] = array('userid'=>$user_id,'points'=>$currentregistrationpoints,'refuserid'=>'','refpoints'=>'');           
            
            update_user_meta($user_id,'rs_get_data_for_reward_points',$mainpoints);
            }
