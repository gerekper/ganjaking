<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit ; // Exit if accessed directly.
}
if ( ! class_exists( 'RSPointExpiryModule' ) ) {

	class RSPointExpiryModule {
		
	}

}
