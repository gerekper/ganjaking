<?php

class Services_Twilio_Rest_Recordings
	extends Services_Twilio_ListResource {

}
