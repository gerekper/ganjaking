jQuery(function ($) {
    jQuery(document).on('click', '.rs_section_wrapper h2', function () {        
        jQuery(this).nextUntil('h2').toggle();        
	jQuery( this ).trigger( "rs_section_wrapper" , [jQuery( this )] ) ;

    });
    jQuery(document).on('click', '.rs_membership_compatible_wrapper h2', function () {
        
        jQuery(this).nextUntil('h2').toggle();        

    });
    jQuery(document).on('click', '.rs_bsn_compatible_wrapper h2', function () {
        
        jQuery(this).nextUntil('h2').toggle();        

    });
    jQuery(document).on('click', '.rs_affs_compatible_wrapper h2', function () {
        
        jQuery(this).nextUntil('h2').toggle();        

    });
    jQuery(document).on('click', '.rs_fpwcrs_compatible_wrapper h2', function () {
        
        jQuery(this).nextUntil('h2').toggle();        

    });
     jQuery(document).on('click', '.rs_subscription_compatible_wrapper h2', function () {
        
        jQuery(this).nextUntil('h2').toggle();        

    });
    
     jQuery(document).on('click', '.rs_payment_plan_compatible_wrapper h2', function () {
        
        jQuery(this).nextUntil('h2').toggle();        

    });
    jQuery(document).on('click', '.rs_coupon_compatible_wrapper h2', function () {
        
        jQuery(this).nextUntil('h2').toggle();        

    });
      jQuery(document).on('click', '.rs_adminstrator_wrapper h2', function () {
        
        jQuery(this).nextUntil('h2').toggle();        

    });
    
});
