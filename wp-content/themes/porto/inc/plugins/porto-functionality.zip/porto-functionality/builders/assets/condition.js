!function(a){"use strict";"function"==typeof define&&define.amd?define(["jquery"],a):a("object"==typeof exports&&"function"==typeof require?require("jquery"):jQuery)}(function(a){"use strict";function b(c,d){var e=this;e.element=c,e.el=a(c),e.suggestions=[],e.badQueries=[],e.selectedIndex=-1,e.currentValue=e.element.value,e.timeoutId=null,e.cachedResponse={},e.onChangeTimeout=null,e.onChange=null,e.isLocal=!1,e.suggestionsContainer=null,e.noSuggestionsContainer=null,e.options=a.extend(!0,{},b.defaults,d),e.classes={selected:"autocomplete-selected",suggestion:"autocomplete-suggestion"},e.hint=null,e.hintValue="",e.selection=null,e.initialize(),e.setOptions(d)}function c(a,b,c){return a.value.toLowerCase().indexOf(c)!==-1}function d(b){return"string"==typeof b?JSON.parse(b):b}function e(a,b){if(!b)return a.value;var c="("+g.escapeRegExChars(b)+")";return a.value.replace(new RegExp(c,"gi"),"<strong>$1</strong>").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/&lt;(\/?strong)&gt;/g,"<$1>")}function f(a,b){return'<div class="autocomplete-group">'+b+"</div>"}var g=function(){return{escapeRegExChars:function(a){return a.replace(/[|\\{}()[\]^$+*?.]/g,"\\$&")},createNode:function(a){var b=document.createElement("div");return b.className=a,b.style.position="absolute",b.style.display="none",b}}}(),h={ESC:27,TAB:9,RETURN:13,LEFT:37,UP:38,RIGHT:39,DOWN:40},i=a.noop;b.utils=g,a.Autocomplete=b,b.defaults={ajaxSettings:{},autoSelectFirst:!1,appendTo:"body",serviceUrl:null,lookup:null,onSelect:null,width:"auto",minChars:1,maxHeight:300,deferRequestBy:0,params:{},formatResult:e,formatGroup:f,delimiter:null,zIndex:9999,type:"GET",noCache:!1,onSearchStart:i,onSearchComplete:i,onSearchError:i,preserveInput:!1,containerClass:"autocomplete-suggestions",tabDisabled:!1,dataType:"text",currentRequest:null,triggerSelectOnValidInput:!0,preventBadQueries:!0,lookupFilter:c,paramName:"query",transformResult:d,showNoSuggestionNotice:!1,noSuggestionNotice:"No results",orientation:"bottom",forceFixPosition:!1},b.prototype={initialize:function(){var c,d=this,e="."+d.classes.suggestion,f=d.classes.selected,g=d.options;d.element.setAttribute("autocomplete","off"),d.noSuggestionsContainer=a('<div class="autocomplete-no-suggestion"></div>').html(this.options.noSuggestionNotice).get(0),d.suggestionsContainer=b.utils.createNode(g.containerClass),c=a(d.suggestionsContainer),c.appendTo(g.appendTo||"body"),"auto"!==g.width&&c.css("width",g.width),c.on("mouseover.autocomplete",e,function(){d.activate(a(this).data("index"))}),c.on("mouseout.autocomplete",function(){d.selectedIndex=-1,c.children("."+f).removeClass(f)}),c.on("click.autocomplete",e,function(){d.select(a(this).data("index"))}),c.on("click.autocomplete",function(){clearTimeout(d.blurTimeoutId)}),d.fixPositionCapture=function(){d.visible&&d.fixPosition()},a(window).on("resize.autocomplete",d.fixPositionCapture),d.el.on("keydown.autocomplete",function(a){d.onKeyPress(a)}),d.el.on("keyup.autocomplete",function(a){d.onKeyUp(a)}),d.el.on("blur.autocomplete",function(){d.onBlur()}),d.el.on("focus.autocomplete",function(){d.onFocus()}),d.el.on("change.autocomplete",function(a){d.onKeyUp(a)}),d.el.on("input.autocomplete",function(a){d.onKeyUp(a)})},onFocus:function(){var a=this;a.fixPosition(),a.el.val().length>=a.options.minChars&&a.onValueChange()},onBlur:function(){var a=this;a.blurTimeoutId=setTimeout(function(){a.hide()},200)},abortAjax:function(){var a=this;a.currentRequest&&(a.currentRequest.abort(),a.currentRequest=null)},setOptions:function(b){var c=this,d=a.extend({},c.options,b);c.isLocal=Array.isArray(d.lookup),c.isLocal&&(d.lookup=c.verifySuggestionsFormat(d.lookup)),d.orientation=c.validateOrientation(d.orientation,"bottom"),a(c.suggestionsContainer).css({"max-height":d.maxHeight+"px",width:d.width+"px","z-index":d.zIndex}),this.options=d},clearCache:function(){this.cachedResponse={},this.badQueries=[]},clear:function(){this.clearCache(),this.currentValue="",this.suggestions=[]},disable:function(){var a=this;a.disabled=!0,clearTimeout(a.onChangeTimeout),a.abortAjax()},enable:function(){this.disabled=!1},fixPosition:function(){var b=this,c=a(b.suggestionsContainer),d=c.parent().get(0);if(d===document.body||b.options.forceFixPosition){var e=b.options.orientation,f=c.outerHeight(),g=b.el.outerHeight(),h=b.el.offset(),i={top:h.top,left:h.left};if("auto"===e){var j=a(window).height(),k=a(window).scrollTop(),l=-k+h.top-f,m=k+j-(h.top+g+f);e=Math.max(l,m)===l?"top":"bottom"}if("top"===e?i.top+=-f:i.top+=g,d!==document.body){var n,o=c.css("opacity");b.visible||c.css("opacity",0).show(),n=c.offsetParent().offset(),i.top-=n.top,i.top+=d.scrollTop,i.left-=n.left,b.visible||c.css("opacity",o).hide()}"auto"===b.options.width&&(i.width=b.el.outerWidth()+"px"),c.css(i)}},isCursorAtEnd:function(){var a,b=this,c=b.el.val().length,d=b.element.selectionStart;return"number"==typeof d?d===c:!document.selection||(a=document.selection.createRange(),a.moveStart("character",-c),c===a.text.length)},onKeyPress:function(a){var b=this;if(!b.disabled&&!b.visible&&a.which===h.DOWN&&b.currentValue)return void b.suggest();if(!b.disabled&&b.visible){switch(a.which){case h.ESC:b.el.val(b.currentValue),b.hide();break;case h.RIGHT:if(b.hint&&b.options.onHint&&b.isCursorAtEnd()){b.selectHint();break}return;case h.TAB:if(b.hint&&b.options.onHint)return void b.selectHint();if(b.selectedIndex===-1)return void b.hide();if(b.select(b.selectedIndex),b.options.tabDisabled===!1)return;break;case h.RETURN:if(b.selectedIndex===-1)return void b.hide();b.select(b.selectedIndex);break;case h.UP:b.moveUp();break;case h.DOWN:b.moveDown();break;default:return}a.stopImmediatePropagation(),a.preventDefault()}},onKeyUp:function(a){var b=this;if(!b.disabled){switch(a.which){case h.UP:case h.DOWN:return}clearTimeout(b.onChangeTimeout),b.currentValue!==b.el.val()&&(b.findBestHint(),b.options.deferRequestBy>0?b.onChangeTimeout=setTimeout(function(){b.onValueChange()},b.options.deferRequestBy):b.onValueChange())}},onValueChange:function(){if(this.ignoreValueChange)return void(this.ignoreValueChange=!1);var b=this,c=b.options,d=b.el.val(),e=b.getQuery(d);return b.selection&&b.currentValue!==e&&(b.selection=null,(c.onInvalidateSelection||a.noop).call(b.element)),clearTimeout(b.onChangeTimeout),b.currentValue=d,b.selectedIndex=-1,c.triggerSelectOnValidInput&&b.isExactMatch(e)?void b.select(0):void(e.length<c.minChars?b.hide():b.getSuggestions(e))},isExactMatch:function(a){var b=this.suggestions;return 1===b.length&&b[0].value.toLowerCase()===a.toLowerCase()},getQuery:function(b){var c,d=this.options.delimiter;return d?(c=b.split(d),a.trim(c[c.length-1])):b},getSuggestionsLocal:function(b){var c,d=this,e=d.options,f=b.toLowerCase(),g=e.lookupFilter,h=parseInt(e.lookupLimit,10);return c={suggestions:a.grep(e.lookup,function(a){return g(a,b,f)})},h&&c.suggestions.length>h&&(c.suggestions=c.suggestions.slice(0,h)),c},getSuggestions:function(b){var c,d,e,f,g=this,h=g.options,i=h.serviceUrl;if(h.params[h.paramName]=b,h.onSearchStart.call(g.element,h.params)!==!1){if(d=h.ignoreParams?null:h.params,a.isFunction(h.lookup))return void h.lookup(b,function(a){g.suggestions=a.suggestions,g.suggest(),h.onSearchComplete.call(g.element,b,a.suggestions)});g.isLocal?c=g.getSuggestionsLocal(b):(a.isFunction(i)&&(i=i.call(g.element,b)),e=i+"?"+a.param(d||{}),c=g.cachedResponse[e]),c&&Array.isArray(c.suggestions)?(g.suggestions=c.suggestions,g.suggest(),h.onSearchComplete.call(g.element,b,c.suggestions)):g.isBadQuery(b)?h.onSearchComplete.call(g.element,b,[]):(g.abortAjax(),f={url:i,data:d,type:h.type,dataType:h.dataType},a.extend(f,h.ajaxSettings),g.currentRequest=a.ajax(f).done(function(a){var c;g.currentRequest=null,c=h.transformResult(a,b),g.processResponse(c,b,e),h.onSearchComplete.call(g.element,b,c.suggestions)}).fail(function(a,c,d){h.onSearchError.call(g.element,b,a,c,d)}))}},isBadQuery:function(a){if(!this.options.preventBadQueries)return!1;for(var b=this.badQueries,c=b.length;c--;)if(0===a.indexOf(b[c]))return!0;return!1},hide:function(){var b=this,c=a(b.suggestionsContainer);a.isFunction(b.options.onHide)&&b.visible&&b.options.onHide.call(b.element,c),b.visible=!1,b.selectedIndex=-1,clearTimeout(b.onChangeTimeout),a(b.suggestionsContainer).hide(),b.signalHint(null)},suggest:function(){if(!this.suggestions.length)return void(this.options.showNoSuggestionNotice?this.noSuggestions():this.hide());var b,c=this,d=c.options,e=d.groupBy,f=d.formatResult,g=c.getQuery(c.currentValue),h=c.classes.suggestion,i=c.classes.selected,j=a(c.suggestionsContainer),k=a(c.noSuggestionsContainer),l=d.beforeRender,m="",n=function(a,c){var f=a.data[e];return b===f?"":(b=f,d.formatGroup(a,b))};return d.triggerSelectOnValidInput&&c.isExactMatch(g)?void c.select(0):(a.each(c.suggestions,function(a,b){e&&(m+=n(b,g,a)),m+='<div class="'+h+'" data-index="'+a+'">'+f(b,g,a)+"</div>"}),this.adjustContainerWidth(),k.detach(),j.html(m),a.isFunction(l)&&l.call(c.element,j,c.suggestions),c.fixPosition(),j.show(),d.autoSelectFirst&&(c.selectedIndex=0,j.scrollTop(0),j.children("."+h).first().addClass(i)),c.visible=!0,void c.findBestHint())},noSuggestions:function(){var b=this,c=b.options.beforeRender,d=a(b.suggestionsContainer),e=a(b.noSuggestionsContainer);this.adjustContainerWidth(),e.detach(),d.empty(),d.append(e),a.isFunction(c)&&c.call(b.element,d,b.suggestions),b.fixPosition(),d.show(),b.visible=!0},adjustContainerWidth:function(){var b,c=this,d=c.options,e=a(c.suggestionsContainer);"auto"===d.width?(b=c.el.outerWidth(),e.css("width",b>0?b:300)):"flex"===d.width&&e.css("width","")},findBestHint:function(){var b=this,c=b.el.val().toLowerCase(),d=null;c&&(a.each(b.suggestions,function(a,b){var e=0===b.value.toLowerCase().indexOf(c);return e&&(d=b),!e}),b.signalHint(d))},signalHint:function(b){var c="",d=this;b&&(c=d.currentValue+b.value.substr(d.currentValue.length)),d.hintValue!==c&&(d.hintValue=c,d.hint=b,(this.options.onHint||a.noop)(c))},verifySuggestionsFormat:function(b){return b.length&&"string"==typeof b[0]?a.map(b,function(a){return{value:a,data:null}}):b},validateOrientation:function(b,c){return b=a.trim(b||"").toLowerCase(),a.inArray(b,["auto","bottom","top"])===-1&&(b=c),b},processResponse:function(a,b,c){var d=this,e=d.options;a.suggestions=d.verifySuggestionsFormat(a.suggestions),e.noCache||(d.cachedResponse[c]=a,e.preventBadQueries&&!a.suggestions.length&&d.badQueries.push(b)),b===d.getQuery(d.currentValue)&&(d.suggestions=a.suggestions,d.suggest())},activate:function(b){var c,d=this,e=d.classes.selected,f=a(d.suggestionsContainer),g=f.find("."+d.classes.suggestion);return f.find("."+e).removeClass(e),d.selectedIndex=b,d.selectedIndex!==-1&&g.length>d.selectedIndex?(c=g.get(d.selectedIndex),a(c).addClass(e),c):null},selectHint:function(){var b=this,c=a.inArray(b.hint,b.suggestions);b.select(c)},select:function(a){var b=this;b.hide(),b.onSelect(a)},moveUp:function(){var b=this;if(b.selectedIndex!==-1)return 0===b.selectedIndex?(a(b.suggestionsContainer).children("."+b.classes.suggestion).first().removeClass(b.classes.selected),b.selectedIndex=-1,b.ignoreValueChange=!1,b.el.val(b.currentValue),void b.findBestHint()):void b.adjustScroll(b.selectedIndex-1)},moveDown:function(){var a=this;a.selectedIndex!==a.suggestions.length-1&&a.adjustScroll(a.selectedIndex+1)},adjustScroll:function(b){var c=this,d=c.activate(b);if(d){var e,f,g,h=a(d).outerHeight();e=d.offsetTop,f=a(c.suggestionsContainer).scrollTop(),g=f+c.options.maxHeight-h,e<f?a(c.suggestionsContainer).scrollTop(e):e>g&&a(c.suggestionsContainer).scrollTop(e-c.options.maxHeight+h),c.options.preserveInput||(c.ignoreValueChange=!0,c.el.val(c.getValue(c.suggestions[b].value))),c.signalHint(null)}},onSelect:function(b){var c=this,d=c.options.onSelect,e=c.suggestions[b];c.currentValue=c.getValue(e.value),c.currentValue===c.el.val()||c.options.preserveInput||c.el.val(c.currentValue),c.signalHint(null),c.suggestions=[],c.selection=e,a.isFunction(d)&&d.call(c.element,e)},getValue:function(a){var b,c,d=this,e=d.options.delimiter;return e?(b=d.currentValue,c=b.split(e),1===c.length?a:b.substr(0,b.length-c[c.length-1].length)+a):a},dispose:function(){var b=this;b.el.off(".autocomplete").removeData("autocomplete"),a(window).off("resize.autocomplete",b.fixPositionCapture),a(b.suggestionsContainer).remove()}},a.fn.devbridgeAutocomplete=function(c,d){var e="autocomplete";return arguments.length?this.each(function(){var f=a(this),g=f.data(e);"string"==typeof c?g&&"function"==typeof g[c]&&g[c](d):(g&&g.dispose&&g.dispose(),g=new b(this,c),f.data(e,g))}):this.first().data(e)},a.fn.autocomplete||(a.fn.autocomplete=a.fn.devbridgeAutocomplete)});

jQuery(document).ready(function($) {
	var porto_query_post_type = '';
	if (typeof elementor != 'undefined') {
		elementor.on('panel:init', function() {
			$('<div id="porto-elementor-builder-condition" class="elementor-panel-footer-sub-menu-item"><i class="elementor-icon fas fa-network-wired" aria-hidden="true"></i><div class="elementor-title">Display Conditions</div></div>').insertAfter('#elementor-panel-footer-sub-menu-item-save-draft');
		});
	}
	$(document.body).on('click', '#porto-elementor-builder-condition, #porto-condition-button, .porto-meta-tab #condition', function(e) {
		e.preventDefault();
		$.magnificPopup.open({
			items: {
				src: '.porto-builder-cond-wrap'
			},
			type: 'inline',
			mainClass: 'mfp-fade',
			removalDelay: 160,
			preloader: false,
			//fixedContentPos: false,
			callbacks: {
				change: function() {

				}
			}
		});

	}).on('click', '.porto-builder-condition .condition-close', function(e) {
		e.preventDefault();
		var $this = $(this),
			$cond = $this.closest('.porto-builder-condition');
		if (0 === $cond.index() && $cond.siblings('.porto-builder-condition').length < 1) {
			$cond.hide();
		} else {
			$cond.remove();
		}
	}).on('click', '.porto-builder-cond-wrap .btn-add-condition', function(e) {
		e.preventDefault();
		if ($('.porto-builder-condition').eq(0).is(':hidden')) {
			$('.porto-builder-condition').eq(0).css('display', '');
		} else {
			var $new = $('.porto-builder-condition').eq(0).clone().css('display', '');
			$new.find('input[name="query"]').val('');
			$new.find('.condition').eq(0).val('');
			$new.find('.condition').eq(1).val('').hide();
			$new.find('.condition').eq(2).hide();
			$new.find('.condition-object-id').val('');
			$new.find('.condition-object-name').val('');
			$new.find('input[name="query"]').val('');
			$new.insertAfter($('.porto-builder-condition').last());
			init_live_search($new);
		}
	}).on('click', '#elementor-panel-saver-button-publish, .vcv-ui-navbar-controls-group[data-vcv-guide-helper="save-control"]', function(e) {
		if ($('.porto-builder-cond-wrap.notsaved').length) {
			$.magnificPopup.open({
				items: {
					src: '.porto-builder-cond-wrap'
				},
				type: 'inline',
				mainClass: 'mfp-fade',
				removalDelay: 160,
				preloader: false,
				callbacks: {
					change: function() {

					}
				}
			});
		}
	});

	$('.porto-builder-cond-wrap').on('change', '.condition-type', function(e) {
		var val = $(this).val();
			$cond = $(this).closest('.porto-builder-condition');
		if ('single' == val) {
			$cond.find('.condition-object-type').show();
			$cond.find('.condition-object-type').find('option[value^="single/"]').show();
			$cond.find('.condition-object-type').find('option[value^="archive/"]').hide();
		} else if ('archive' == val) {
			$cond.find('.condition-object-type').show();
			$cond.find('.condition-object-type').find('option[value^="single/"]').hide();
			$cond.find('.condition-object-type').find('option[value^="archive/"]').show();
		} else {
			$cond.find('.condition-object-type').val('');
			$cond.find('.condition-object-type').hide();
			$cond.find('.condition').eq(2).hide();
		}
	}).on('change', '.condition-object-type', function(e, is_first) {
		var val = $(this).val();
			$cond = $(this).closest('.porto-builder-condition');
		if (val && 'single/404' != val && -1 === val.indexOf('archive/')) {
			var $obj = $cond.find('.condition').eq(2);
			if (typeof is_first == 'undefined') {
				$obj.show();
			}
			porto_query_post_type = val;
		} else {
			$cond.find('.condition').eq(2).hide();
			porto_query_post_type = '';
		}
		if (typeof is_first == 'undefined') {
			$cond.find('.condition').eq(2).find('.condition-object-id').val('');
			$cond.find('.condition').eq(2).find('input[name="query"]').val('');
		}
	}).on('input', 'input[name="query"]', function(e) {
		var $this = $(this);
		if ($this.val()) {
			$this.siblings('.condition-cancel').show();
		} else {
			$this.siblings('.condition-cancel').hide();
		}
	}).on('click', '.condition-cancel', function(e) {
		e.preventDefault();
		$(this).hide().siblings('input[name="query"]').val('').focus();
	}).on('click', '.condition-clone', function(e) {
		e.preventDefault();
		var $this_condition = $(this).closest('.porto-builder-condition'),
			$new = $this_condition.clone().insertAfter($this_condition);
		$new.find('.condition').eq(0).val($this_condition.find('.condition').eq(0).val());
		$new.find('.condition').eq(1).val($this_condition.find('.condition').eq(1).val());
		init_live_search($new);
	});

	$('.porto-builder-cond-wrap .save-condition').on('click', function(e) {
		e.preventDefault();
		var $this = $(this),
			postdata = '';
		$this.closest('.porto-builder-cond-wrap').find('.porto-builder-condition').each(function() {
			if ($(this).is(':hidden')) {
				if ($(this).siblings('.porto-builder-condition').length) {
					$(this).remove();
				} else {
					var tmp_cloned = $(this).clone();
					$(this).remove();
					postdata = $this.closest('form').serialize();
					tmp_cloned.prependTo($this.closest('form'));
					init_live_search(tmp_cloned);
				}
			}
		});
		if (!postdata) {
			postdata = $this.closest('form').serialize();
		}
		$this.prop('disabled', true);
		$.magnificPopup.close();
		$.ajax({
			url: ajaxurl,
			type: 'POST',
			dataType: 'json',
			data: postdata + '&action=porto_builder_save_condition',
			success: function(response) {
				$this.closest('.porto-builder-cond-wrap').removeClass('notsaved');
			},
			complete: function() {
				$this.prop('disabled', false);
			},
			failure: function() {
				alert('Save failed. Please refresh and try again.');
			}
		});
	});
	$('.porto-builder-cond-wrap .condition-type').trigger('change');
	$('.porto-builder-cond-wrap .condition-object-type').trigger('change', true);

	var init_live_search = function($obj) {
		if (typeof $obj == 'undefined') {
			$obj = $('.searchform');
		}
		$obj.each(function() {
			var $this = $(this),
				appendTo = $this.find('.live-search-list'),
				serviceUrl = ajaxurl + '?action=porto_builder_search_posts&nonce=' + porto_builder_condition.nonce;

			$this.find('input[type="text"]').devbridgeAutocomplete({
				minChars: 3,
				appendTo: appendTo,
				triggerSelectOnValidInput: false,
				serviceUrl: serviceUrl,
				onSearchStart: function (params) {
					params.post_type = porto_query_post_type;
				},
				onSelect: function (item) {
					if (item.id != -1) {
						$this.find('.condition-object-id').val(item.id);
						$this.find('.condition-object-name').val(item.value);
					}
				},
				formatResult: function (item, currentValue) {
					var pattern = '(' + $.Autocomplete.utils.escapeRegExChars(currentValue) + ')',
						html = '<div class="search-name">' + item.value.replace(new RegExp(pattern, 'gi'), '<strong>$1<\/strong>') + '</div>';
					return html;
				}
			});
		});
	}
	init_live_search();
});

jQuery(window).on('load', function() {
	setTimeout(function() {
		if (jQuery('.vcv-ui-navbar-sandwich').length) {
			jQuery('<span id="porto-condition-button" class="vcv-ui-navbar-control" title="Display Condition"><span class="vcv-ui-navbar-control-content">Display Condition</span></span>').insertBefore(jQuery('.vcv-ui-navbar-sandwich .vcv-ui-navbar-control').last());
		}
	}, 200);
});